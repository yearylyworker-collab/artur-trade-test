"""Draw a labeled coordinate grid over a template to read box coordinates."""
import sys
from PIL import Image, ImageDraw, ImageFont

FONT = "/app/assets/fonts/DejaVuSans-Bold.ttf"


def grid(src, dst):
    img = Image.open(src).convert("RGB")
    d = ImageDraw.Draw(img)
    W, H = img.size
    f = ImageFont.truetype(FONT, 16)
    for x in range(0, W, 50):
        col = (255, 80, 80) if x % 100 == 0 else (70, 70, 70)
        d.line([(x, 0), (x, H)], fill=col, width=1)
        if x % 100 == 0:
            d.text((x + 2, 2), str(x), font=f, fill=(255, 255, 0))
            d.text((x + 2, H - 20), str(x), font=f, fill=(255, 255, 0))
    for y in range(0, H, 50):
        col = (255, 80, 80) if y % 100 == 0 else (70, 70, 70)
        d.line([(0, y), (W, y)], fill=col, width=1)
        if y % 100 == 0:
            d.text((2, y + 2), str(y), font=f, fill=(255, 255, 0))
            d.text((W - 46, y + 2), str(y), font=f, fill=(255, 255, 0))
    img.save(dst, "PNG")
    print("saved", dst, img.size)


if __name__ == "__main__":
    grid(sys.argv[1], sys.argv[2])
