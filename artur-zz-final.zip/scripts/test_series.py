"""Offline end-to-end test of one signal series (no real Telegram posting)."""
import asyncio
from app.config import settings
from app.core.models import AnalysisResult
from app.services.state import state
from app.services import engine_control as ctrl
from app.core.enums import Mode
from app.signals.manager import SignalManager
from app.database.session import get_session, init_db
from app.database.repositories.repos import SignalRepository

# compress timings
settings.search_temp_seconds = 1
settings.analysis_temp_seconds = 1
settings.min_signal_lead_seconds = 3
settings.post_result_cooldown_seconds = 0
settings.default_expiry_seconds = 3
settings.entry_second = 30

POSTS = []

class FakeCards:
    def path(self, ct): return f"/app/assets/cards/{ct}"
    async def send(self, chat_id, card_type, caption):
        POSTS.append(("SEND", card_type))
        return len(POSTS)  # fake message_id

class FakePublisher:
    async def delete_message(self, mid):
        POSTS.append(("DELETE", mid)); return True

async def main():
    await init_db()
    settings.__dict__  # noop
    await ctrl.switch_mode(Mode.DEMO)
    state.cards = FakeCards()
    state.publisher = FakePublisher()
    # force expiry small on draft via settings already; build analysis
    a = AnalysisResult(symbol="EUR/USD", direction="SELL", score=88.0, passed=True,
                       reason="test", ha_snapshot={})
    mgr = SignalManager(state)
    await mgr.run(a)
    print("POST ORDER:")
    for p in POSTS: print("  ", p)
    async with get_session() as s:
        repo = SignalRepository(s)
        last = await repo.last_any("DEMO")
        sig = await repo.get(last.id)
        print("DB signal:", sig.id, sig.symbol, sig.direction, "status=", sig.status,
              "final=", sig.final_result, "repeats=", sig.repeats)
        for at in sig.attempts:
            print("  attempt", at.attempt_number, at.result, at.entry_price, at.exit_price)

asyncio.run(main())
