"""Backtest / replay engine: run the SignalEngine over historical candles
without Telegram, to see how many signals the strategy produces and their
actual outcomes.

Usage:
    python -m scripts.replay              # replay mock data
    python -m scripts.replay --live EUR/USD   # replay live history (needs key)
"""
import argparse
import asyncio
from datetime import timedelta

from app.analysis.engine import AnalysisEngine
from app.candles.heikin_ashi import compute_heikin_ashi
from app.config import settings
from app.core.enums import Direction
from app.market.forex.rest import ForexRestClient
from app.market.mock.provider import MockMarketDataProvider
from app.results.resolver import resolve


async def load(symbol: str, live: bool):
    if live:
        c = ForexRestClient(settings.forex_rest_url, settings.forex_api_key)
        candles = await c.candles(symbol, "M1", settings.candle_history_limit)
        await c.close()
        return candles
    prov = MockMarketDataProvider([symbol], seed=settings.demo_random_seed)
    await prov.connect()
    return await prov.get_candles(symbol, "M1", settings.candle_history_limit)


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true")
    ap.add_argument("symbol", nargs="?", default="EUR/USD")
    args = ap.parse_args()

    candles = await load(args.symbol, args.live)
    eng = AnalysisEngine(min_score=settings.min_signal_score)

    signals = wins = losses = draws = 0
    # slide a window; enter at close of window, exit one candle later
    window = 60
    for i in range(window, len(candles) - 1):
        sub = candles[:i]
        ha = compute_heikin_ashi(sub)
        r = eng.analyze_symbol(args.symbol, sub, ha)
        if not r.passed:
            continue
        signals += 1
        entry = candles[i].close
        exit_ = candles[i + 1].close
        res = resolve(r.direction, entry, exit_).value
        if res == "WIN":
            wins += 1
        elif res == "LOSS":
            losses += 1
        else:
            draws += 1

    completed = wins + losses
    wr = (wins / completed * 100) if completed else 0.0
    print(f"=== REPLAY {args.symbol} ({'LIVE' if args.live else 'MOCK'}) ===")
    print(f"candles={len(candles)} signals={signals}")
    print(f"WIN={wins} LOSS={losses} DRAW={draws} win_rate={wr:.1f}%")
    print("NOTE: replay uses candle-close as a proxy; not a promise of live accuracy.")


if __name__ == "__main__":
    asyncio.run(main())
