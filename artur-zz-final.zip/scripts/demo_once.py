"""One-shot DEMO lifecycle: publishes a full signal series to the channel fast."""
import asyncio
from datetime import datetime, timezone

from aiogram import Bot

from app.config import settings
from app.core.enums import Mode
from app.core.logging_config import setup_logging
from app.database.session import init_db
from app.services import engine_control as ctrl
from app.services.state import state
from app.signals.manager import SignalManager


async def main():
    setup_logging()
    await init_db()
    bot = Bot(token=settings.bot_token)
    state.init_telegram(bot)
    state.channel_ok = await state.publisher.check_channel()
    await ctrl.switch_mode(Mode.DEMO)
    state.auto_demo = True

    # Fast entry (~3s ahead) + short expiry so we can watch the whole flow quickly.
    now = datetime.now(timezone.utc)
    settings.entry_second = (now.second + 3) % 60
    settings.min_seconds_before_entry = 1
    settings.default_expiry_seconds = 6

    provider = state.provider
    provider.bias("EUR/USD", "BUY")
    candles = await provider.get_candles("EUR/USD", "M1", 200)
    state.candles.set_history("EUR/USD", candles)
    ha = state.candles.ha("EUR/USD")
    analysis = state.analysis.analyze_symbol("EUR/USD", candles, ha)
    if not analysis.passed:
        analysis.passed = True
        analysis.direction = "BUY"
        analysis.score = 82.0
    print("Analysis:", analysis.symbol, analysis.direction, analysis.score)

    await SignalManager(state).run(analysis)
    await bot.session.close()
    print("DEMO lifecycle complete")


asyncio.run(main())
