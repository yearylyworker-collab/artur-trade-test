"""Crop the lower panel region and draw an absolute-coordinate grid for precise reading."""
import sys
from PIL import Image, ImageDraw, ImageFont

FONT = "/app/assets/fonts/DejaVuSans-Bold.ttf"


def cropgrid(src, dst, y0):
    img = Image.open(src).convert("RGB")
    W, H = img.size
    crop = img.crop((0, y0, W, H))
    cw, ch = crop.size
    scale = 2  # zoom 2x for readability
    crop = crop.resize((cw * scale, ch * scale), Image.LANCZOS)
    d = ImageDraw.Draw(crop)
    f = ImageFont.truetype(FONT, 20)
    for x in range(0, W, 25):
        col = (255, 60, 60) if x % 100 == 0 else ((255, 180, 60) if x % 50 == 0 else (60, 60, 60))
        d.line([(x * scale, 0), (x * scale, ch * scale)], fill=col, width=1)
        if x % 100 == 0:
            d.text((x * scale + 2, 2), str(x), font=f, fill=(255, 255, 0))
    for y in range(y0 - (y0 % 25), H, 25):
        yy = (y - y0) * scale
        col = (255, 60, 60) if y % 100 == 0 else ((255, 180, 60) if y % 50 == 0 else (60, 60, 60))
        d.line([(0, yy), (cw * scale, yy)], fill=col, width=1)
        if y % 50 == 0:
            d.text((2, yy + 1), str(y), font=f, fill=(255, 255, 0))
    crop.save(dst, "PNG")
    print("saved", dst)


if __name__ == "__main__":
    cropgrid(sys.argv[1], sys.argv[2], int(sys.argv[3]))
