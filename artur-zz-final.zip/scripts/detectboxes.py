"""Detect the empty value boxes (cyan rounded outlines) in a master template.

Prints detected box rectangles (x, y, w, h) restricted to a vertical band, and
saves an overlay so the detection can be visually verified.
"""
import sys
import numpy as np
from PIL import Image, ImageDraw


def detect(src, dst, y0, y1):
    img = Image.open(src).convert("RGB")
    arr = np.asarray(img).astype(np.int16)
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    # cyan/green box outline: strong g&b, low r; exclude white labels (high r)
    mask = ((g > 140) & (b > 110) & (r < 120)).astype(np.uint8)
    mask[:y0, :] = 0
    mask[y1:, :] = 0

    H, W = mask.shape
    visited = np.zeros_like(mask, dtype=bool)
    boxes = []
    ys, xs = np.nonzero(mask)
    idx = {}
    for yy, xx in zip(ys, xs):
        idx.setdefault(yy, []).append(xx)

    # simple iterative flood fill (4/8-connectivity)
    from collections import deque
    for sy, sx in zip(ys, xs):
        if visited[sy, sx]:
            continue
        q = deque([(sy, sx)])
        visited[sy, sx] = True
        minx = maxx = sx
        miny = maxy = sy
        count = 0
        while q:
            cy, cx = q.popleft()
            count += 1
            minx = min(minx, cx); maxx = max(maxx, cx)
            miny = min(miny, cy); maxy = max(maxy, cy)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    ny, nx = cy + dy, cx + dx
                    if 0 <= ny < H and 0 <= nx < W and mask[ny, nx] and not visited[ny, nx]:
                        visited[ny, nx] = True
                        q.append((ny, nx))
        w = maxx - minx
        h = maxy - miny
        # value-box outlines: wide, short, hollow (count small vs area)
        if 120 <= w <= 460 and 24 <= h <= 70 and count < w * h * 0.6:
            boxes.append((minx, miny, w, h, count))

    boxes.sort(key=lambda bx: (round(bx[1] / 30), bx[0]))
    draw = ImageDraw.Draw(img)
    for (x, y, w, h, c) in boxes:
        draw.rectangle([x, y, x + w, y + h], outline=(255, 0, 255), width=3)
        print(f"x={x} y={y} w={w} h={h} px={c}")
    img.save(dst, "PNG")
    print("boxes:", len(boxes))


if __name__ == "__main__":
    detect(sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]))
