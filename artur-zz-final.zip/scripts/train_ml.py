"""Train the XGBoost meta-label filter with PURGED time-series cross-validation.

    python -m scripts.train_ml              # LIVE data
    python -m scripts.train_ml --mode DEMO
    (or /ml train in the bot's admin chat)

Data  : closed signals from the bot's own DB (SignalRepository.get_training_data)
        — features captured at signal time, label = WIN(1)/LOSS(0) of the entry.
Rules : fewer than ML_MIN_SAMPLES rows -> exit, nothing is written.

Why purged CV (López de Prado): financial rows are ordered in time and their
labels span an interval [entry, entry+expiry]. Ordinary KFold shuffles the
future into training and leaks. Here:
  * folds are contiguous blocks in time (walk-forward: train always BEFORE test);
  * PURGE  — training rows whose label interval reaches into the test block are
             dropped;
  * EMBARGO — an extra gap (ML_EMBARGO_MINUTES) before each test block is
             dropped too, against serial correlation of neighbouring signals.
Early stopping uses the last 15 % of each (purged) training set, never the test.

The model is saved ONLY if, pooled over all folds, the signals it keeps
(P >= ML_PROB_THRESHOLD) have a higher winrate than all signals, it keeps at
least MIN_KEPT test signals, and it beats the baseline in most folds.
The final model is then refit on all rows with the median best iteration.
Output: runtime/ml/model.json + runtime/ml/features.json
"""
from __future__ import annotations

import argparse
import asyncio
import json
from datetime import timedelta
from statistics import median
from typing import List

from app.config import settings
from app.core.logging_config import get_logger
from app.database.repositories.repos import SignalRepository
from app.database.session import get_session, init_db
from app.ml.features import feature_names, to_row
from app.ml.filter import features_path, model_path

log = get_logger("ml.train")

N_FOLDS = 5
MIN_KEPT = 20
EMBARGO = timedelta(minutes=30)


def _wr(labels: List[int]) -> float:
    return round(100.0 * sum(labels) / len(labels), 1) if labels else 0.0


def purged_folds(rows, n_folds: int = N_FOLDS, embargo: timedelta = EMBARGO):
    """Yield (train_idx, test_idx) for walk-forward purged CV. rows sorted by time."""
    n = len(rows)
    edges = [round(n * k / (n_folds + 1)) for k in range(n_folds + 2)]
    for k in range(1, n_folds + 1):
        test_idx = list(range(edges[k], edges[k + 1]))
        if not test_idx:
            continue
        test_start = rows[test_idx[0]]["entry_time"]
        cutoff = test_start - embargo
        train_idx = [
            i for i in range(edges[k])
            # purge: label interval must end before the test block (minus embargo)
            if rows[i]["entry_time"] + timedelta(seconds=rows[i]["expiry"]) < cutoff
        ]
        yield train_idx, test_idx


def _params(y_train: List[int]) -> dict:
    pos = max(1, sum(y_train))
    neg = max(1, len(y_train) - sum(y_train))
    return {
        "objective": "binary:logistic", "eval_metric": "logloss",
        "max_depth": 4, "learning_rate": 0.1,
        "scale_pos_weight": neg / pos,            # class imbalance
        "subsample": 0.9, "colsample_bytree": 0.9, "seed": 42,
    }


async def train(mode: str = "LIVE") -> str:
    import xgboost as xgb

    await init_db()
    async with get_session() as s:
        rows, y = await SignalRepository(s).get_training_data(mode)
    names = feature_names()
    X = [to_row(r["features"], names) for r in rows]
    n = len(y)
    lines = [f"samples: {n} (need >= {settings.ml_min_samples})"]
    if n < settings.ml_min_samples:
        lines.append("Not enough data — model NOT trained. Bot keeps working by rules.")
        return "\n".join(lines)

    thr = settings.ml_prob_threshold
    all_test, all_kept, best_iters, folds_won, folds_used = [], [], [], 0, 0
    for k, (tr, te) in enumerate(purged_folds(rows), start=1):
        if len(tr) < 40 or len(set(y[i] for i in tr)) < 2:
            lines.append(f"fold {k}: skipped (train too small after purge: {len(tr)})")
            continue
        cut = int(len(tr) * 0.85)
        fit_idx, val_idx = tr[:cut], tr[cut:]
        dfit = xgb.DMatrix([X[i] for i in fit_idx], label=[y[i] for i in fit_idx], feature_names=names)
        dval = xgb.DMatrix([X[i] for i in val_idx], label=[y[i] for i in val_idx], feature_names=names)
        booster = xgb.train(_params([y[i] for i in fit_idx]), dfit, num_boost_round=500,
                            evals=[(dval, "valid")], early_stopping_rounds=10, verbose_eval=False)
        best_iters.append(booster.best_iteration + 1)
        probs = booster.predict(xgb.DMatrix([X[i] for i in te], feature_names=names),
                                iteration_range=(0, booster.best_iteration + 1))
        yt = [y[i] for i in te]
        kept = [lbl for lbl, p in zip(yt, probs) if p >= thr]
        all_test += yt
        all_kept += kept
        folds_used += 1
        won = bool(kept) and _wr(kept) > _wr(yt)
        folds_won += int(won)
        lines.append(f"fold {k}: train {len(tr)} test {len(te)} | all wr {_wr(yt)}% | "
                     f"kept {len(kept)} wr {_wr(kept)}% {'✓' if won else '✗'}")

    base_wr, kept_wr = _wr(all_test), _wr(all_kept)
    kept_share = round(100.0 * len(all_kept) / len(all_test), 1) if all_test else 0.0
    lines.append(f"PURGED CV pooled: all {len(all_test)} wr {base_wr}% | "
                 f"kept(P>={thr}) {len(all_kept)} ({kept_share}%) wr {kept_wr}% | "
                 f"folds won {folds_won}/{folds_used}")

    if (folds_used == 0 or len(all_kept) < MIN_KEPT or kept_wr <= base_wr
            or folds_won * 2 < folds_used):
        lines.append("Filter does NOT reliably beat the baseline on unseen data — model NOT saved.")
        return "\n".join(lines)

    rounds = int(median(best_iters))
    dall = xgb.DMatrix(X, label=y, feature_names=names)
    final = xgb.train(_params(y), dall, num_boost_round=rounds, verbose_eval=False)
    mp = model_path()
    mp.parent.mkdir(parents=True, exist_ok=True)
    final.save_model(str(mp))
    features_path().write_text(json.dumps({
        "features": names, "n_samples": n, "mode": mode, "threshold": thr,
        "rounds": rounds,
        "cv": {"folds": folds_used, "folds_won": folds_won, "base_wr": base_wr,
               "kept_wr": kept_wr, "kept_share": kept_share,
               "embargo_min": int(EMBARGO.total_seconds() // 60)},
    }, indent=2, ensure_ascii=False))
    lines.append(f"Model saved: {mp} (+ features.json). Reload in bot: /ml reload")
    return "\n".join(lines)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="LIVE", choices=["LIVE", "DEMO"])
    print(asyncio.run(train(ap.parse_args().mode)))
