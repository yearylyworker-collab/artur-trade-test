"""One-shot: post a single compressed DEMO series to the real channel."""
import asyncio
from aiogram import Bot
from app.config import settings
from app.core.models import AnalysisResult
from app.core.enums import Mode
from app.database.session import init_db
from app.services.state import AppState
from app.signals.manager import SignalManager

settings.search_temp_seconds = 3
settings.analysis_temp_seconds = 3
settings.min_signal_lead_seconds = 6
settings.post_result_cooldown_seconds = 0
settings.default_expiry_seconds = 5
settings.entry_second = 30

async def main():
    await init_db()
    bot = Bot(token=settings.bot_token)
    st = AppState()
    st.mode = Mode.DEMO
    st.init_telegram(bot)
    st.provider = None
    from app.market.manager import build_provider
    st.provider = build_provider("DEMO")
    await st.provider.connect()
    st.provider_online = True
    a = AnalysisResult(symbol="EUR/USD", direction="BUY", score=91.0, passed=True,
                       reason="demo showcase", ha_snapshot={})
    print("posting series...")
    await SignalManager(st).run(a)
    print("done")
    await bot.session.close()

asyncio.run(main())
