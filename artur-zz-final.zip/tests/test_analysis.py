"""Analysis / filter tests."""
from datetime import datetime, timedelta, timezone

from app.analysis.engine import AnalysisEngine
from app.analysis.filters import noise as noise_f, volatility as vol_f
from app.candles.heikin_ashi import compute_heikin_ashi
from app.candles.models import Candle
from app.core.enums import Direction


def _series(direction, n=60, start=1.0, step=0.001):
    candles = []
    price = start
    for i in range(n):
        o = price
        if direction == "up":
            c = o + step
        elif direction == "down":
            c = o - step
        else:  # flat / chop
            c = o + (step if i % 2 == 0 else -step)
        h = max(o, c) + step / 3
        l = min(o, c) - step / 3
        candles.append(Candle("X", datetime(2024, 1, 1, tzinfo=timezone.utc) + timedelta(minutes=i),
                              o, h, l, c))
        price = c
    return candles


def test_buy_candidate():
    eng = AnalysisEngine(min_score=75)
    c = _series("up")
    ha = compute_heikin_ashi(c)
    r = eng.analyze_symbol("X", c, ha)
    assert r.direction == Direction.BUY.value
    assert r.passed


def test_sell_candidate():
    eng = AnalysisEngine(min_score=75)
    c = _series("down")
    ha = compute_heikin_ashi(c)
    r = eng.analyze_symbol("X", c, ha)
    assert r.direction == Direction.SELL.value
    assert r.passed


def test_no_signal_flat():
    eng = AnalysisEngine(min_score=75)
    c = _series("flat")
    ha = compute_heikin_ashi(c)
    r = eng.analyze_symbol("X", c, ha)
    assert not r.passed
    assert r.direction is None


def test_noise_filter_detects_chop():
    c = _series("flat")
    ha = compute_heikin_ashi(c)
    res = noise_f.evaluate(ha)
    assert not res.passed


def test_volatility_filter_low():
    # near-zero movement -> too low volatility
    c = [Candle("X", datetime(2024, 1, 1, tzinfo=timezone.utc) + timedelta(minutes=i),
                1.0, 1.0000001, 0.9999999, 1.0) for i in range(30)]
    res = vol_f.evaluate(c)
    assert not res.passed


def test_score_threshold_enforced():
    eng = AnalysisEngine(min_score=999)  # impossible
    c = _series("up")
    ha = compute_heikin_ashi(c)
    r = eng.analyze_symbol("X", c, ha)
    assert not r.passed
