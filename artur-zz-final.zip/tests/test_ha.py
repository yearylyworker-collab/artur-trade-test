"""HA calculation & sequence tests."""
from datetime import datetime, timedelta, timezone

from app.candles.models import Candle
from app.candles.heikin_ashi import compute_heikin_ashi
from app.core.enums import HADirection


def _c(o, h, l, c, i=0):
    return Candle(symbol="X", timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc) + timedelta(minutes=i),
                 open=o, high=h, low=l, close=c)


def test_ha_calculation_first_open():
    candles = [_c(10, 12, 9, 11, 0)]
    ha = compute_heikin_ashi(candles)
    assert ha[0].ha_close == (10 + 12 + 9 + 11) / 4
    assert ha[0].ha_open == (10 + 11) / 2
    assert ha[0].ha_high == max(12, ha[0].ha_open, ha[0].ha_close)
    assert ha[0].ha_low == min(9, ha[0].ha_open, ha[0].ha_close)


def test_ha_calculation_subsequent_open():
    candles = [_c(10, 12, 9, 11, 0), _c(11, 13, 10, 12, 1)]
    ha = compute_heikin_ashi(candles)
    expected_open = (ha[0].ha_open + ha[0].ha_close) / 2
    assert abs(ha[1].ha_open - expected_open) < 1e-9


def test_ha_sequence_bullish():
    candles = [_c(10 + i, 11 + i, 9 + i, 11 + i, i) for i in range(6)]
    ha = compute_heikin_ashi(candles)
    assert ha[-1].direction == HADirection.BULLISH
