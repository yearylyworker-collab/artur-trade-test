"""TimingAnalyzer, shadow window stats, runtime params, AdaptiveEngine."""
import asyncio
import random
import types
from datetime import datetime, timedelta, timezone

from app.analytics import shadow
from app.analytics import timing as timing_mod
from app.analytics.timing import TimingAnalyzer
from app.config import settings
from app.engines import adaptive as adaptive_mod
from app.services import runtime


def _analyzer(tmp_path):
    tm = TimingAnalyzer(path=tmp_path / "a.db")
    timing_mod.timing = tm
    shadow.timing = tm
    adaptive_mod.timing = tm
    return tm


def test_best_second_and_draw_ignored(tmp_path):
    tm = _analyzer(tmp_path)
    random.seed(3)
    base = datetime(2026, 9, 23, 1, 0, 30, tzinfo=timezone.utc)
    rows = []
    for i in range(440):
        sec = 25 + i % 11
        win = random.random() < (0.8 if sec == 32 else 0.45)
        rows.append((base + timedelta(minutes=i), sec, "EURUSD_otc", "M1",
                     "WIN" if win else "LOSS", "shadow"))
    asyncio.run(tm.record_many(rows))
    asyncio.run(tm.record(base, 30, "EURUSD_otc", "M1", "DRAW"))
    best = tm.get_best_entry_second(min_samples=30)
    assert best[0] == 32
    assert tm.counts()["shadow"] == 440 and tm.counts()["live"] == 0


def test_window_stats_fixed_stake():
    rows = [("W", None), ("LW", None), ("LLLLL", None), ("LL", None)]  # last one incomplete
    st = shadow.window_stats(rows, 5, 0.85)
    assert st["samples"] == 3
    assert abs(st["ev"] - (0.85 + (0.85 - 1) - 5) / 3) < 1e-9
    st3 = shadow.window_stats(rows, 3, 0.85)       # "LLLLL" truncated to 3 losses
    assert abs(st3["ev"] - (0.85 - 0.15 - 3) / 3) < 1e-9


def test_price_tape_lookup():
    tape = shadow.PriceTape(None, "X")
    now = datetime.now(timezone.utc)
    for i in range(10):
        tape.ts.append((now + timedelta(seconds=i)).timestamp())
        tape.px.append(float(i))
    assert tape.price_at(now + timedelta(seconds=3.4)) == 3.0
    assert tape.price_at(now - timedelta(seconds=1)) is None
    assert tape.price_at(now + timedelta(seconds=20)) is None   # gap


def test_runtime_apply_and_restore(tmp_path, monkeypatch):
    monkeypatch.setattr(runtime, "PARAMS_FILE", tmp_path / "p.json")
    monkeypatch.setattr(settings, "market_provider", "pocket")
    monkeypatch.setattr(settings, "default_timeframe", "M1")
    monkeypatch.setattr(settings, "entry_second", 30)
    monkeypatch.setattr(settings, "max_attempts", 5)
    changed = runtime.apply(timeframe="S30", entry_second=32, window_length=4)
    assert settings.default_expiry_seconds == 30 and "timeframe" in changed
    settings.default_timeframe, settings.entry_second, settings.max_attempts = "M1", 30, 5
    runtime.load()
    assert runtime.current()["timeframe"] == "S30" and settings.max_attempts == 4


def test_adaptive_requires_samples_and_improvement(tmp_path, monkeypatch):
    tm = _analyzer(tmp_path)
    monkeypatch.setattr(settings, "market_provider", "pocket")
    monkeypatch.setattr(settings, "default_timeframe", "M1")
    monkeypatch.setattr(settings, "max_attempts", 3)
    monkeypatch.setattr(settings, "entry_second_auto", False)
    st = types.SimpleNamespace(provider=types.SimpleNamespace(payouts={"a": 85}),
                               engine_on=True, cards=None)
    eng = adaptive_mod.AdaptiveEngine(st)
    eng.analyze()
    assert eng.proposal() is None                       # no data -> stay
    for tf, seq in (("M1", "LLL"), ("S30", "W")):
        for _ in range(35):
            asyncio.run(tm.record_window(tf, "EURUSD_otc", "BUY", 30, seq, None))
    eng.analyze()
    prop = eng.proposal()
    assert prop and prop["timeframe"] == "S30"
    assert not eng.should_switch()                      # 1 h cooldown from boot
    eng.last_switch -= 10_000
    assert eng.should_switch()


def test_duration_auto_choice(tmp_path, monkeypatch):
    tm = _analyzer(tmp_path)
    monkeypatch.setattr(runtime, "PARAMS_FILE", tmp_path / "p.json")
    monkeypatch.setattr(settings, "trade_seconds", 0)
    monkeypatch.setattr(settings, "trade_seconds_auto", True)
    monkeypatch.setattr(settings, "default_timeframe", "M1")
    runtime.AUTO_DURATION.clear()
    now = datetime.now(timezone.utc)
    rows = []
    for d, wins in {5: 60, 15: 50, 30: 50, 60: 45, 120: 50, 180: 50}.items():
        rows += [(now, "M1", "X", d, "WIN" if i < wins else "LOSS", "shadow") for i in range(100)]
    asyncio.run(tm.record_durations(rows))
    assert runtime.choose_duration()[1] == 5
    assert runtime.expiry_for("M1") == 5
    runtime.AUTO_DURATION.clear()
