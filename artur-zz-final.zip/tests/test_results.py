"""Result resolver, entry-time and cooldown tests."""
from datetime import datetime, timezone

from app.core.enums import AttemptResult
from app.core.time_utils import next_entry_time
from app.results.resolver import resolve
from app.signals.cooldown import CooldownManager


def test_buy_win():
    assert resolve("BUY", 1.0, 1.1) == AttemptResult.WIN


def test_buy_loss():
    assert resolve("BUY", 1.1, 1.0) == AttemptResult.LOSS


def test_sell_win():
    assert resolve("SELL", 1.1, 1.0) == AttemptResult.WIN


def test_sell_loss():
    assert resolve("SELL", 1.0, 1.1) == AttemptResult.LOSS


def test_draw():
    assert resolve("BUY", 1.0, 1.0) == AttemptResult.DRAW
    assert resolve("SELL", 1.0, 1.0) == AttemptResult.DRAW


def test_entry_second_rolls_forward_when_too_close():
    now = datetime(2024, 1, 1, 21, 47, 28, tzinfo=timezone.utc)
    entry = next_entry_time(now, entry_second=30, min_lead=8)
    assert entry.minute == 48 and entry.second == 30


def test_entry_second_same_minute_when_enough_lead():
    now = datetime(2024, 1, 1, 21, 47, 17, tzinfo=timezone.utc)
    entry = next_entry_time(now, entry_second=30, min_lead=8)
    assert entry.minute == 47 and entry.second == 30


def test_pair_cooldown():
    cm = CooldownManager()
    assert cm.ready("EUR/USD")
    cm.arm("EUR/USD")
    assert not cm.ready("EUR/USD")
