"""Tests for Engine-2 additions: indicators, EMA/RSI/MACD gate, regime,
Pocket candle parsing, window captions and statistics formatting."""
from datetime import datetime, timedelta, timezone

import math

from app.analysis.filters import ema_rsi_macd
from app.analysis.regime import NEUTRAL, RANGE, MarketRegime
from app.candles.heikin_ashi import compute_heikin_ashi
from app.candles.models import Candle
from app.core.enums import Direction
from app.indicators import ta
from app.market.pocket.provider import parse_candle
from app.publisher import formatter
from app.signals.snapshot import SignalPublicationSnapshot
from app.statistics.formatter import stats_caption

T0 = datetime(2026, 1, 5, 10, 0, tzinfo=timezone.utc)


def _wave(n=120, drift=0.0004, amp=0.0003, start=1.1):
    """Uptrend with noise: realistic enough for MACD/RSI to be non-degenerate."""
    out, price = [], start
    for i in range(n):
        o = price
        c = o + drift + amp * math.sin(i * 0.9)
        h, l = max(o, c) + 0.0001, min(o, c) - 0.0001
        out.append(Candle("EURUSD_otc", T0 + timedelta(minutes=i), o, h, l, c))
        price = c
    return out


# ---------------------------------------------------------------- indicators
def test_ema_seed_and_recursion():
    v = [1, 2, 3, 4, 5]
    e = ta.ema(v, 3)
    assert e[:2] == [None, None]
    assert e[2] == 2.0                       # SMA seed
    assert abs(e[3] - (0.5 * 4 + 0.5 * 2.0)) < 1e-12


def test_rsi_extremes():
    up = [float(i) for i in range(30)]
    assert ta.last(ta.rsi(up, 14)) == 100.0
    down = [float(30 - i) for i in range(30)]
    assert ta.last(ta.rsi(down, 14)) == 0.0


def test_rsi_matches_wilder_reference():
    closes = [c.close for c in _wave(drift=0.0002, amp=0.0006)]  # has down moves
    d = [0.0] + [b - a for a, b in zip(closes, closes[1:])]
    g = [max(x, 0.0) for x in d]
    l = [max(-x, 0.0) for x in d]
    ag, al = sum(g[1:15]) / 14, sum(l[1:15]) / 14      # SMA seed
    for i in range(15, len(closes)):                   # Wilder recursion
        ag = (ag * 13 + g[i]) / 14
        al = (al * 13 + l[i]) / 14
    ref = 100 - 100 / (1 + ag / al)
    assert abs(ta.last(ta.rsi(closes, 14)) - ref) < 1e-9


def test_bollinger_and_atr_shapes():
    c = _wave()
    lo, mid, up = ta.bollinger([x.close for x in c], 20, 2)
    assert lo[18] is None and lo[19] is not None and up[-1] > mid[-1] > lo[-1]
    a = ta.atr([x.high for x in c], [x.low for x in c], [x.close for x in c], 14)
    assert a[12] is None and a[13] is not None and a[-1] > 0


def test_macd_positive_in_accelerating_uptrend():
    closes = [1 + 0.00001 * i * i for i in range(80)]
    _l, _s, h = ta.macd(closes)
    assert h[-1] is not None and h[-1] > 0


# ---------------------------------------------------------------- gate
def test_gate_buy_on_uptrend_and_blocks_sell():
    c = _wave()
    snap = ema_rsi_macd.indicator_snapshot(c)
    buy = ema_rsi_macd.evaluate(c, Direction.BUY, snap)
    sell = ema_rsi_macd.evaluate(c, Direction.SELL, snap)
    assert not sell.passed
    assert snap["rsi"] > 50
    # BUY passes unless MACD momentarily disagrees on the wave; EMA stack must hold
    assert snap["ema_fast"] > snap["ema_slow"]
    assert buy.passed or "macd" in buy.reason or "rsi" in buy.reason


def test_gate_flat_market():
    c = [Candle("X", T0 + timedelta(minutes=i), 1.0, 1.000001, 0.999999, 1.0) for i in range(60)]
    r = ema_rsi_macd.evaluate(c, Direction.BUY)
    assert not r.passed and "flat" in r.reason


def test_gate_insufficient_history():
    r = ema_rsi_macd.evaluate(_wave(n=10), Direction.BUY)
    assert not r.passed and "insufficient" in r.reason


# ---------------------------------------------------------------- regime
def test_regime_chop_is_range():
    out, p = [], 1.1
    for i in range(80):
        o = p
        c = o + (0.0005 if i % 2 == 0 else -0.0005)
        out.append(Candle("X", T0 + timedelta(minutes=i), o, max(o, c) + 1e-4, min(o, c) - 1e-4, c))
        p = c
    assert MarketRegime().check("X", out, compute_heikin_ashi(out)) == RANGE


def test_regime_short_history_is_range():
    c = _wave(n=5)
    assert MarketRegime().check("X", c, compute_heikin_ashi(c)) == RANGE


def test_regime_returns_known_value():
    c = _wave()
    assert MarketRegime().check("X", c, compute_heikin_ashi(c)) in (
        "TREND", "VOLATILE", RANGE, NEUTRAL)


# ---------------------------------------------------------------- pocket
def test_parse_candle_formats():
    base = {"open": "1.1", "high": "1.2", "low": "1.0", "close": "1.15"}
    a = parse_candle("EURUSD_otc", {**base, "time": 1767607200}, "M1")
    b = parse_candle("EURUSD_otc", {**base, "timestamp": 1767607200000}, "M1")
    c = parse_candle("EURUSD_otc", {**base, "time": "2026-01-05T10:00:00Z"}, "M1")
    assert a.timestamp == b.timestamp == c.timestamp
    assert a.close == 1.15 and a.source == "pocketoption"
    assert parse_candle("X", {"time": 1, "open": 1}, "M1") is None          # malformed
    assert parse_candle("X", {**base, "high": "0.9", "time": 1}, "M1") is None  # invalid


# ---------------------------------------------------------------- captions
def _snap(direction="BUY"):
    return SignalPublicationSnapshot(1, "EURUSD_otc", direction, T0 + timedelta(seconds=30),
                                     60, "M1", "OTC")


def test_window_plan_on_same_second():
    plan = formatter.window_plan(T0 + timedelta(seconds=30), 5, 60)
    assert [t.second for t in plan] == [30] * 5
    assert (plan[-1] - plan[0]).total_seconds() == 240


def test_window_start_caption_contract():
    s = _snap("SELL")
    plan = formatter.window_plan(s.entry_time, 5, 60)
    cap = formatter.window_start_caption(s, plan, {"rsi": 42.3, "atr": 0.00043}, 81.0)
    assert "<b>SELL</b>" in cap                # direction guard in SignalManager
    assert "EURUSD OTC" in cap and "#" not in cap
    assert "Вероятность" not in cap            # no fake probability
    assert "81/100" in cap
    assert len(cap) <= 1024                    # Telegram photo caption limit


def test_window_result_caption_shows_entries():
    s = _snap()
    plan = formatter.window_plan(s.entry_time, 5, 60)
    hist = [(1, plan[0], "LOSS"), (2, plan[1], "LOSS"), (3, plan[2], "WIN")]
    cap = formatter.window_result_caption(s, "WIN", hist, plan)
    assert "ПЛЮС" in cap and "(✅ 1 / ❌ 2)" in cap and "tg-spoiler" in cap
    assert len(cap) <= 1024
    lost = [(i + 1, t, "LOSS") for i, t in enumerate(plan)]
    assert "МИНУС" in formatter.window_result_caption(s, "LOSS", lost, plan)


def test_stats_caption_both_views():
    from app.config import settings
    settings.max_attempts = 5
    cap = stats_caption({"mode": "LIVE", "wins": 9, "losses": 1, "attempt_wins": 12,
                         "attempt_losses": 15, "attempt_draws": 0})
    assert "Окон:</b> <code>10</code>" in cap
    assert "Сделок:</b> <code>27</code>" in cap
    assert "44.4%" in cap                      # 12 / 27 per-entry winrate
    assert "55.6%" in cap                      # breakeven at 80% payout
    settings.max_attempts = 1
    assert "Окон" not in stats_caption({"attempt_wins": 3, "attempt_losses": 2})


def test_rolling_winrate_ignores_draws():
    from app.statistics.rolling import _winrate
    assert _winrate(["WIN", "LOSS", "DRAW", "WIN"]) == 200 / 3
    assert _winrate(["DRAW"]) is None


def test_single_entry_captions():
    s = _snap()
    plan = formatter.window_plan(s.entry_time, 1, 60)
    start = formatter.window_start_caption(s, plan, {"rsi": 60.0, "atr": 0.0004}, 84.0)
    assert "НАЙДЕН ТОРГОВЫЙ СИГНАЛ" in start and "Торговое окно" not in start
    assert "<b>BUY</b>" in start and "Вероятность" not in start and "Ставка" not in start
    assert len(start) <= 1024
    res = formatter.window_result_caption(s, "LOSS", [(1, plan[0], "LOSS")], plan)
    assert "LOSS ❌" in res and "окна" not in res.lower() and "tg-spoiler" in res
    win = formatter.window_result_caption(s, "WIN", [(1, plan[0], "WIN")], plan)
    assert "WIN ✅" in win and "Спасибо за доверие" in win and "к депозиту" not in win


def test_purged_folds_no_leakage():
    from scripts.train_ml import purged_folds, EMBARGO
    rows = [{"entry_time": T0 + timedelta(minutes=5 * i), "expiry": 60} for i in range(240)]
    folds = list(purged_folds(rows))
    assert len(folds) == 5
    for tr, te in folds:
        assert max(tr) < min(te)                       # walk-forward: train before test
        gap = rows[te[0]]["entry_time"] - (rows[tr[-1]]["entry_time"] + timedelta(seconds=60))
        assert gap >= EMBARGO                          # purge + embargo respected
