"""Card render, autofit, statistics, duplicate & recovery tests."""
import asyncio
import os

import pytest

from app.cards.renderer import get_renderer
from app.cards.autofit import fit_font, wrap_text
from app.cards.renderer import FONT_BOLD
from PIL import ImageFont


def test_card_render_signal_buy():
    r = get_renderer()
    path = r.render("signal_buy", {
        "pair": "EUR/USD", "market": "FOREX", "timeframe": "M1",
        "trade_time": "21:47:12", "entry_time": "21:47:30",
        "window": "21:47:30–21:48:30",
    })
    assert os.path.exists(path) and os.path.getsize(path) > 1000


def test_card_render_result_win():
    r = get_renderer()
    path = r.render("result_win", {
        "pair": "AUD/USD", "market": "FOREX", "timeframe": "M1",
        "entry_time": "21:47:30", "expiry": "60 сек", "entry_number": "№1",
        "repeats": "0", "total_time": "1м 00с",
    })
    assert os.path.exists(path)


def test_text_autofit_shrinks_long_text():
    max_w = 200
    big = fit_font(FONT_BOLD, "AUD/CHF OTC", max_w, 40, 12)
    assert big.getlength("AUD/CHF OTC") <= max_w + 1


def test_wrap_text():
    font = ImageFont.truetype(FONT_BOLD, 20)
    lines = wrap_text(font, "От анализа к стабильному результату каждый день", 200)
    assert len(lines) >= 2


def test_statistics_win_rate():
    # DRAW must not count as loss.
    wins, losses, draws = 6, 4, 2
    completed = wins + losses
    win_rate = wins / completed * 100
    assert round(win_rate, 1) == 60.0


@pytest.mark.asyncio
async def test_duplicate_protection():
    from app.database.session import init_db, get_session
    from app.database.repositories.repos import PublicationEventRepository
    await init_db()
    import uuid
    eid = f"test-dup-{uuid.uuid4()}"
    async with get_session() as s:
        repo = PublicationEventRepository(s)
        first = await repo.exists(eid)
        await repo.record(eid, None)
        await s.commit()
    async with get_session() as s:
        repo = PublicationEventRepository(s)
        second = await repo.exists(eid)
    assert first is False and second is True
