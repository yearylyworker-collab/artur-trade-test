"""Stale quote & restart recovery tests."""
import pytest

from app.market.mock.provider import MockMarketDataProvider


@pytest.mark.asyncio
async def test_stale_quote_age():
    prov = MockMarketDataProvider(["EUR/USD"], seed=1)
    await prov.connect()
    assert prov.get_quote_age("EUR/USD") is None  # no quote yet
    await prov.get_current_quote("EUR/USD")
    age = prov.get_quote_age("EUR/USD")
    assert age is not None and age < 2.0


@pytest.mark.asyncio
async def test_restart_recovery_marks_orphans():
    from app.database.session import init_db, get_session
    from app.database.repositories.repos import SignalRepository
    from app.services.recovery import recover_active_signals
    from app.core.enums import SignalStatus
    from datetime import datetime, timezone

    await init_db()
    async with get_session() as s:
        repo = SignalRepository(s)
        sig = await repo.create(
            mode="DEMO", symbol="EUR/USD", market="FOREX", direction="BUY",
            score=80.0, timeframe="M1", entry_time=datetime.now(timezone.utc),
            expiry_seconds=60, status=SignalStatus.WAITING_RESULT.value,
            provider="mock", audit={},
        )
        await s.commit()
        sid = sig.id

    await recover_active_signals("DEMO")

    async with get_session() as s:
        sig = await SignalRepository(s).get(sid)
        assert sig.status == SignalStatus.DATA_UNAVAILABLE.value
