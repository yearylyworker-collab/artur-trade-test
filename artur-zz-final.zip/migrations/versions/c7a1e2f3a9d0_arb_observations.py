"""arbitrage observations table

Revision ID: c7a1e2f3a9d0
Revises: bdb5422c9f62
Create Date: 2026-09-23 18:00:00
"""
from alembic import op
import sqlalchemy as sa


revision = 'c7a1e2f3a9d0'
down_revision = 'bdb5422c9f62'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'arb_observations',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('real_symbol', sa.String(length=32), nullable=False),
        sa.Column('otc_symbol', sa.String(length=32), nullable=False),
        sa.Column('real_price', sa.Float(), nullable=False),
        sa.Column('otc_price', sa.Float(), nullable=False),
        sa.Column('gap', sa.Float(), nullable=False),
        sa.Column('direction', sa.String(length=4), nullable=False),
        sa.Column('otc_exit_price', sa.Float(), nullable=True),
        sa.Column('result', sa.String(length=8), nullable=True),
        sa.Column('published', sa.Boolean(), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_arb_observations_created_at', 'arb_observations', ['created_at'])
    op.create_index('ix_arb_observations_otc_symbol', 'arb_observations', ['otc_symbol'])


def downgrade() -> None:
    op.drop_index('ix_arb_observations_otc_symbol', table_name='arb_observations')
    op.drop_index('ix_arb_observations_created_at', table_name='arb_observations')
    op.drop_table('arb_observations')
