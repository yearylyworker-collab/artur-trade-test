"""Admin inline panel."""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.services.state import state


def admin_panel() -> InlineKeyboardMarkup:
    engine_row = [
        InlineKeyboardButton(text="🟢 ENGINE ON", callback_data="engine_on"),
        InlineKeyboardButton(text="🔴 ENGINE OFF", callback_data="engine_off"),
    ]
    mode_row = [
        InlineKeyboardButton(text="📡 LIVE FOREX", callback_data="mode_live"),
        InlineKeyboardButton(text="🧪 DEMO", callback_data="mode_demo"),
    ]
    demo_row = [
        InlineKeyboardButton(text="▶️ AUTO DEMO", callback_data="auto_demo"),
        InlineKeyboardButton(text="⏸ STOP DEMO", callback_data="stop_demo"),
    ]
    action_row = [
        InlineKeyboardButton(text="🔎 ANALYZE NOW", callback_data="analyze_now"),
        InlineKeyboardButton(text="📊 STATISTICS", callback_data="statistics"),
    ]
    info_row = [
        InlineKeyboardButton(text="🖼 TEMPLATES", callback_data="templates"),
        InlineKeyboardButton(text="👁 PREVIEW CARDS", callback_data="preview_cards"),
    ]
    sys_row = [
        InlineKeyboardButton(text="📡 PROVIDER STATUS", callback_data="provider_status"),
        InlineKeyboardButton(text="📝 LAST SIGNALS", callback_data="last_signals"),
    ]
    settings_row = [
        InlineKeyboardButton(text="⚙️ SETTINGS", callback_data="settings"),
    ]
    return InlineKeyboardMarkup(inline_keyboard=[
        engine_row, mode_row, demo_row, action_row, info_row, sys_row, settings_row,
    ])
