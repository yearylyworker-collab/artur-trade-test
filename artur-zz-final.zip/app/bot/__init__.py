"""Bot sub-package."""
