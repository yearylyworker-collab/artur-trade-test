"""Admin statistics panel (ADMIN_IDS only). Every command is logged.

/start       — greeting + buttons (admins); others get the public /start
/stats       — today          /stats_night — 00:00–08:00 (Ukraine)
/stats_week  — 7 days         /timing      — best entry second / hours
/assets      — best / worst   /health      — uptime, windows, SSID, provider
/adaptive    — adaptive engine report
/adaptive_on | /adaptive_off  /set_timeframe S30|M1|M5
/set_second 30                /set_window 3|4|5
/switch_now  — announce the proposed mode now (2-min warning)
/howto       — preview instruction, /howto_post — publish it to the channel
"""
from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.analytics import reports
from app.bot.filters import IsAdmin
from app.config import settings
from app.core.logging_config import get_logger
from app.publisher import formatter
from app.services import runtime
from app.services.state import state

log = get_logger("bot.panel")
router = Router()
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())


def stats_keyboard() -> InlineKeyboardMarkup:
    b = InlineKeyboardButton
    return InlineKeyboardMarkup(inline_keyboard=[
        [b(text="📊 Сегодня", callback_data="p:today"),
         b(text="🌙 Ночь", callback_data="p:night"),
         b(text="📅 Неделя", callback_data="p:week")],
        [b(text="⏱ Лучшее время входа", callback_data="p:timing"),
         b(text="💰 Лучшие активы", callback_data="p:assets")],
        [b(text="❤️ Состояние бота", callback_data="p:health"),
         b(text="🤖 Адаптив", callback_data="p:adaptive")],
        [b(text="🎯 Винрейт входов", callback_data="p:entries")],
        [b(text="📡 Каналы", callback_data="p:channels"),
         b(text="📨 Рассылка", callback_data="p:broadcast")],
        [b(text="❓ Инструкция", callback_data="p:howto"),
         b(text="⚙️ Управление", callback_data="p:panel")],
    ])


def _log(message_or_cb, what: str) -> None:
    user = message_or_cb.from_user
    log.info("ADMIN %s (%s): %s", user.id if user else "?",
             user.username if user else "?", what)


async def _send(message: Message, text: str) -> None:
    # Telegram limit is 4096 chars
    for i in range(0, len(text), 4000):
        await message.answer(text[i:i + 4000], parse_mode="HTML",
                             reply_markup=stats_keyboard() if i + 4000 >= len(text) else None)


async def _render(kind: str) -> str:
    if kind in ("today", "night", "week"):
        return await reports.period_report(kind)
    if kind == "timing":
        return reports.timing_report()
    if kind == "assets":
        return reports.assets_report()
    if kind == "health":
        return reports.health_report()
    if kind == "adaptive":
        return reports.adaptive_report()
    if kind == "howto":
        return formatter.howto_caption()
    if kind == "entries":
        return await reports.entries_report()
    if kind == "broadcast":
        from app.services import broadcast as bc
        st = await bc.period_pnl(settings.broadcast_every_hours)
        return (f"<b>📨 РАССЫЛКА</b> — подписчиков: {bc.count()} · авто раз в "
                f"{settings.broadcast_every_hours:g} ч ({'ON' if settings.broadcast_enabled else 'OFF'})\n"
                "Отправить сейчас: /broadcast_send\n\n<b>Превью:</b>\n\n" + bc.message(st))
    if kind == "channels":
        from app.services import chanmon
        if state.bot:
            await chanmon.check_permissions(state.bot)
        return chanmon.report()
    return "?"


@router.message(Command("start"))
async def cmd_start(message: Message) -> None:
    _log(message, "/start")
    cur = runtime.current()
    await message.answer(
        "👋 <b>ARTUR TRADE — админ-панель</b>\n\n"
        f"Движок: <b>{'ON' if state.engine_on else 'OFF'}</b> · "
        f"{cur['timeframe']} · вход :{cur['entry_second']:02d} · окно {cur['window_length']}\n\n"
        "Выберите отчёт кнопками ниже.\n"
        "Управление движком — /panel · команды: /stats /stats_night /stats_week "
        "/timing /assets /health /adaptive /howto",
        parse_mode="HTML", reply_markup=stats_keyboard())


_CMD = {"stats": "today", "stats_night": "night", "stats_week": "week", "timing": "timing",
        "assets": "assets", "health": "health", "adaptive": "adaptive", "howto": "howto",
        "channels": "channels", "broadcast": "broadcast", "entries": "entries"}


@router.message(Command(*_CMD.keys()))
async def cmd_report(message: Message, command: CommandObject) -> None:
    _log(message, f"/{command.command}")
    try:
        await _send(message, await _render(_CMD[command.command]))
    except Exception as e:  # noqa: BLE001
        log.exception("report failed")
        await message.answer(f"Ошибка отчёта: {e}")


@router.callback_query(F.data.startswith("p:"))
async def cb_report(cb: CallbackQuery) -> None:
    kind = cb.data[2:]
    _log(cb, f"button {kind}")
    await cb.answer()
    if kind == "panel":
        from app.bot.handlers.start import cmd_panel
        await cmd_panel(cb.message)
        return
    try:
        await _send(cb.message, await _render(kind))
    except Exception as e:  # noqa: BLE001
        log.exception("report failed")
        await cb.message.answer(f"Ошибка отчёта: {e}")


@router.message(Command("howto_post"))
async def cmd_howto_post(message: Message) -> None:
    _log(message, "/howto_post")
    if not settings.signal_channel_id:
        await message.answer("SIGNAL_CHANNEL_ID не задан.")
        return
    await state.bot.send_message(settings.signal_channel_id, formatter.howto_caption(),
                                 parse_mode="HTML")
    await message.answer("✅ Инструкция опубликована в канале.")


@router.message(Command("adaptive_on", "adaptive_off"))
async def cmd_adaptive(message: Message, command: CommandObject) -> None:
    _log(message, f"/{command.command}")
    on = command.command == "adaptive_on"
    runtime.apply(adaptive=on)
    cancelled = False
    if not on and state.adaptive:
        cancelled = state.adaptive.cancel_pending()
    await message.answer(
        f"🤖 Адаптивный движок: <b>{'ON' if on else 'OFF'}</b>"
        + (" · запланированная смена отменена" if cancelled else "")
        + ("\nРешение о смене — не чаще раза в час и только при перевесе ≥"
           f"{settings.adaptive_improvement_threshold * 100:.0f}% на "
           f"{settings.adaptive_min_samples}+ окнах." if on else
           "\nРаботаю по статичным параметрам."), parse_mode="HTML")


async def _manual_change(message: Message, **kw) -> None:
    """Manual change goes through the same 2-minute warning when the engine runs."""
    cur = runtime.current()
    prop = {"timeframe": kw.get("timeframe", cur["timeframe"]),
            "entry_second": kw.get("entry_second", cur["entry_second"]),
            "window_length": kw.get("window_length", cur["window_length"]),
            "reason": "ручная настройка администратора"}
    if (prop["timeframe"], prop["entry_second"], prop["window_length"]) == \
            (cur["timeframe"], cur["entry_second"], cur["window_length"]):
        await message.answer("Уже установлено.")
        return
    if state.engine_on and state.adaptive and settings.signal_channel_id:
        if state.adaptive.pending:
            await message.answer("Уже запланирована смена режима — дождитесь её.")
            return
        await state.adaptive.schedule_switch(prop)
        await message.answer(f"⏳ Смена объявлена в канале, вступит через "
                             f"~{settings.adaptive_warning_lead // 60} мин.")
    else:
        runtime.apply(timeframe=prop["timeframe"], entry_second=prop["entry_second"],
                      window_length=prop["window_length"])
        await message.answer(f"✅ Применено: {runtime.current()}")


@router.message(Command("set_timeframe"))
async def cmd_set_tf(message: Message, command: CommandObject) -> None:
    _log(message, f"/set_timeframe {command.args}")
    tf = (command.args or "").strip().upper()
    allowed = runtime.provider_timeframes()
    if tf not in allowed:
        await message.answer(f"Использование: /set_timeframe {'|'.join(allowed)}")
        return
    await _manual_change(message, timeframe=tf)


@router.message(Command("set_second"))
async def cmd_set_second(message: Message, command: CommandObject) -> None:
    _log(message, f"/set_second {command.args}")
    try:
        sec = int((command.args or "").strip().lstrip(":"))
        assert 5 <= sec <= 55
    except (ValueError, AssertionError):
        await message.answer("Использование: /set_second 30 (5…55)")
        return
    await _manual_change(message, entry_second=sec)


@router.message(Command("set_window"))
async def cmd_set_window(message: Message, command: CommandObject) -> None:
    _log(message, f"/set_window {command.args}")
    try:
        n = int((command.args or "").strip())
        assert 1 <= n <= 5
    except (ValueError, AssertionError):
        await message.answer("Использование: /set_window 1…5")
        return
    await _manual_change(message, window_length=n)


@router.message(Command("switch_now"))
async def cmd_switch_now(message: Message) -> None:
    _log(message, "/switch_now")
    ad = state.adaptive
    if not ad:
        await message.answer("Адаптивный движок не запущен.")
        return
    ad.analyze()
    prop = ad.proposal()
    if not prop:
        await message.answer("Нет режима, который заметно лучше текущего.")
        return
    if ad.pending:
        await message.answer("Смена уже запланирована.")
        return
    await ad.schedule_switch(prop)
    await message.answer(f"⏳ Объявлено: {prop['reason']}")


@router.message(Command("set_trade_seconds"))
async def cmd_set_trade_seconds(message: Message, command: CommandObject) -> None:
    """Trade duration per entry: /set_trade_seconds 5 (0 = equal to the timeframe)."""
    _log(message, f"/set_trade_seconds {command.args}")
    try:
        sec = int((command.args or "").strip())
        assert sec == 0 or 5 <= sec <= 300
    except (ValueError, AssertionError):
        await message.answer("Использование: /set_trade_seconds 5 (5…300, 0 = как таймфрейм)")
        return
    runtime.set_trade_seconds(sec)
    await message.answer(f"✅ Время сделки: {settings.default_expiry_seconds} сек "
                         f"(график {settings.default_timeframe}). Действует со следующего сигнала.\n"
                         "Опубликовать новую инструкцию: /howto_post")


@router.message(Command("stats_card"))
async def cmd_stats_card(message: Message, command: CommandObject) -> None:
    """/stats_card — today's card to you; /stats_card yesterday; /stats_card post — to channel."""
    _log(message, f"/stats_card {command.args or ''}")
    from app.services.daily import send_daily
    args = (command.args or "").split()
    kind = "yesterday" if "yesterday" in args or "вчера" in args else "today"
    chats = [settings.signal_channel_id] if "post" in args else [message.chat.id]
    ok = await send_daily(kind, chats)
    if not ok:
        await message.answer("Не удалось отправить карточку статистики.")
    elif "post" in args:
        await message.answer("✅ Статистика опубликована в канале.")


@router.message(Command("main_now"))
async def cmd_main_now(message: Message) -> None:
    """Prepare post now; the next signal goes to the main channel."""
    _log(message, "/main_now")
    from app.services import main_channel
    if not settings.main_channel_id:
        await message.answer("MAIN_CHANNEL_ID не задан в Railway.")
        return
    await main_channel.post_prepare()
    main_channel.force_next()
    await message.answer("✅ «Готовимся к сделкам» опубликовано — следующий сигнал уйдёт в основной канал.")


@router.message(Command("promo_now"))
async def cmd_promo_now(message: Message) -> None:
    _log(message, "/promo_now")
    from app.services import main_channel
    if not settings.main_channel_id or not settings.main_promo_video_text:
        await message.answer("Нужны MAIN_CHANNEL_ID и MAIN_PROMO_VIDEO_TEXT.")
        return
    await main_channel.post_promo()
    await message.answer("✅ Видео опубликовано.")


@router.message(Command("broadcast_send"))
async def cmd_broadcast_send(message: Message) -> None:
    _log(message, "/broadcast_send")
    from app.services import broadcast as bc
    await message.answer(f"⏳ Отправляю {bc.count()} подписчикам…")
    ok, fail = await bc.send_all()
    await message.answer(f"📨 Готово: доставлено {ok}, не доставлено {fail}"
                         + ("" if ok or fail else " (за период нет закрытых сигналов)"))


@router.message(Command("morning_now"))
async def cmd_morning_now(message: Message) -> None:
    _log(message, "/morning_now")
    from app.services import main_channel
    await main_channel.post_morning()
    await message.answer("✅ Утреннее приветствие опубликовано.")
