"""/start and /panel handlers."""
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.bot.filters import IsAdmin
from app.bot.keyboards.admin import admin_panel
from app.services.state import state

router = Router()


@router.message(Command("stop"))
async def cmd_stop(message: Message) -> None:
    from app.services.broadcast import remove_subscriber
    remove_subscriber(message.from_user.id)
    await message.answer("Вы отписались от рассылки. Вернуться: /start")


@router.message(Command("start"))
async def cmd_start(message: Message) -> None:
    from app.services.broadcast import add_subscriber
    if message.from_user:
        add_subscriber(message.from_user.id, message.from_user.username)
    from app.config import settings as _s
    await message.answer(
        "👋 <b>Добро пожаловать в ARTUR TRADE</b> 🤖\n\n"
        "<blockquote><b>Бот торгует по системе Heikin Ashi на OTC 24/7 и публикует "
        "сигналы с честным итогом — плюс и минус.</b></blockquote>\n\n"
        "➡️ <b>Сюда будут приходить итоги приватного канала</b> — сколько сигналов, "
        "сколько в плюс и какой результат был бы на депозите.\n\n"
        + (f"👉 <a href=\"{_s.private_channel_url}\"><b>ПОЛУЧИТЬ ПРИВАТКУ</b></a>\n" if _s.private_channel_url
           else "") +
        f"✍️ Доступ в приватку и вопросы: {_s.main_contact}\n"
        "<i>Отписаться от сообщений: /stop</i>",
        parse_mode="HTML",
    )


@router.message(Command("panel"), IsAdmin())
async def cmd_panel(message: Message) -> None:
    await message.answer(
        f"⚙️ <b>ARTUR TRADE — ПАНЕЛЬ</b>\n\n"
        f"Режим: <b>{state.mode.value}</b>\n"
        f"Движок: <b>{'ACTIVE' if state.engine_on else 'STOPPED'}</b>\n"
        f"Провайдер: <b>{'ONLINE' if state.provider_online else 'OFFLINE'}</b>\n"
        f"Канал: <b>{'CONNECTED' if state.channel_ok else 'NOT CONNECTED'}</b>",
        reply_markup=admin_panel(),
        parse_mode="HTML",
    )


@router.message(Command("panel"))
async def cmd_panel_denied(message: Message) -> None:
    await message.answer("⛔ Только для администратора.")
