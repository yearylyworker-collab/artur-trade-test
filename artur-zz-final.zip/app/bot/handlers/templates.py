"""/templates — list available static card types."""
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.cards.static_registry import CARD_FILES

router = Router()


@router.message(Command("templates"))
async def cmd_templates(message: Message) -> None:
    names = "\n".join(f"• <code>{k}</code> → {v}" for k, v in CARD_FILES.items())
    await message.answer(f"🖼 <b>Статические карточки</b>\n\n{names}", parse_mode="HTML")
