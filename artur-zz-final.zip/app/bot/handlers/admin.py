"""Admin inline-panel callback handlers."""
from __future__ import annotations

import asyncio

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, FSInputFile, Message

from app.bot.filters import IsAdmin
from app.bot.keyboards.admin import admin_panel
from app.config import settings
from app.core.enums import Mode
from app.core.logging_config import get_logger
from app.database.repositories.repos import SignalRepository, StatsRepository
from app.database.session import get_session
from app.services import engine_control as ctrl
from app.services.health import snapshot
from app.services.state import state
from app.statistics.formatter import stats_caption
from app.statistics.service import get_stats
from app.cards.static_registry import CARD_FILES

log = get_logger("bot.admin")
router = Router()


@router.message(Command("cards_status"), IsAdmin())
async def cmd_cards_status(message: Message) -> None:
    st = await state.cards.status() if state.cards else {}
    lines = [f"{'✅' if st.get(ct) else '❌'} <code>{ct}</code>" for ct in CARD_FILES]
    await message.answer("🗂 <b>Кэш статических карточек</b>\n\n" + "\n".join(lines),
                         parse_mode="HTML")


@router.message(Command("register_cards"), IsAdmin())
async def cmd_register_cards(message: Message) -> None:
    if not state.cards:
        await message.answer("Канал не настроен.")
        return
    await message.answer("⏳ Регистрирую карточки (upload + кэш file_id)...")
    res = await state.cards.register_all(message.from_user.id)
    lines = [f"{v} — <code>{k}</code>" for k, v in res.items()]
    await message.answer("🗂 <b>Регистрация</b>\n\n" + "\n".join(lines), parse_mode="HTML")


@router.message(Command("replace_card"), IsAdmin())
async def cmd_replace_card(message: Message) -> None:
    parts = (message.text or "").split()
    if len(parts) < 2:
        await message.answer("Использование: <code>/replace_card BUY</code>", parse_mode="HTML")
        return
    res = await state.cards.replace(message.from_user.id, parts[1])
    await message.answer(res)


@router.message(Command("preview_cards"), IsAdmin())
async def cmd_preview_cards(message: Message) -> None:
    from app.publisher import formatter
    from app.signals.snapshot import SignalPublicationSnapshot
    from app.core.time_utils import utc_now
    from datetime import timedelta
    snap = SignalPublicationSnapshot(
        signal_id=0, pair="EUR/USD", direction="BUY",
        entry_time=utc_now() + timedelta(seconds=45), expiry_seconds=60,
        timeframe="M1", market="FOREX")
    demo = {
        "ENGINE_STARTED": formatter.engine_caption("M1", 6),
        "SEARCH": formatter.search_caption("M1", 6),
        "ANALYSIS": formatter.analysis_caption("EUR/USD", "FOREX", "M1"),
        "BUY": formatter.signal_caption(snap),
        "SELL": formatter.signal_caption(SignalPublicationSnapshot(
            0, "GBP/USD", "SELL", snap.entry_time, 60, "M1", "FOREX")),
        "REENTRY": formatter.reentry_caption(snap, 2),
        "WIN": formatter.result_caption(snap, "WIN", 1, 0),
        "LOSS": formatter.result_caption(snap, "LOSS", 2, 1),
        "SKIPPED": formatter.skipped_caption("EUR/USD", "Низкая волатильность"),
        "STATISTICS": stats_caption(await get_stats(state.mode.value)),
    }
    for ct, cap in demo.items():
        try:
            await message.answer_photo(FSInputFile(state.cards.path(ct)), caption=cap,
                                       parse_mode="HTML")
        except Exception as e:  # noqa: BLE001
            await message.answer(f"{ct}: {e}")


@router.message(Command("arb"), IsAdmin())
async def cmd_arb(message: Message) -> None:
    """Measured hit rate of arbitrage gaps (decide whether ARB_MODE=signal is worth it)."""
    from app.engines.arbitrage import arb_summary
    d = await arb_summary()
    wr = f"{d['win_rate']}%" if d["win_rate"] is not None else "—"
    await message.answer(
        "⚖️ <b>АРБИТРАЖ</b> (режим: <code>{}</code>)\n\n"
        "Гэпов записано: <b>{}</b>\n"
        "WIN {} / LOSS {} / DRAW {} / ждут {}\n"
        "Попадание через {} с: <b>{}</b>\n\n"
        "<i>Безубыточность при пейауте {:.0f}%: {:.1f}%</i>".format(
            settings.arb_mode, d["total"], d["wins"], d["losses"], d["draws"],
            d["pending"], settings.arb_check_seconds, wr, settings.payout_percent,
            100.0 / (1.0 + settings.payout_percent / 100.0)),
        parse_mode="HTML")


@router.message(Command("ml"), IsAdmin())
async def cmd_ml(message: Message) -> None:
    from app.ml.filter import ml_filter
    text = message.text or ""
    if "train" in text:
        await message.answer("🧠 Обучаю модель (purged CV)…")
        report = await ml_filter.train(state.mode.value)
        await message.answer(f"<pre>{report[-3500:]}</pre>", parse_mode="HTML")
    elif "reload" in text:
        ml_filter.load()
    await message.answer(f"🧠 ML-фильтр: {ml_filter.info}\n"
                         f"Порог: {settings.ml_prob_threshold}\n"
                         "Обучить: /ml train · Перезагрузить: /ml reload")


@router.message(Command("diag"), IsAdmin())
async def cmd_diag(message: Message) -> None:
    """Why is there (no) signal right now?"""
    r, c = state.diag.get("refresh", {}), state.diag.get("cycle", {})
    fails = ", ".join(f"{k}: {v}" for k, v in sorted(
        c.get("fails", {}).items(), key=lambda kv: -kv[1])) or "—"
    top = "\n".join(f"• <code>{s}</code> {sc}/100 {d} — {why}"
                    for s, sc, d, why in c.get("top", [])) or "—"
    await message.answer(
        "🩺 <b>ДИАГНОСТИКА</b>\n\n"
        f"Движок: <b>{'ON' if state.engine_on else 'OFF'}</b> · занят сигналом: "
        f"<b>{'да' if state.is_busy else 'нет'}</b>\n"
        f"Свечи: <b>{r.get('ok', '?')}/{r.get('pairs', '?')}</b> пар за "
        f"<b>{r.get('seconds', '?')} с</b>\n\n"
        f"Последний цикл: пар {c.get('symbols', '?')}, проанализировано "
        f"<b>{c.get('analyzed', '?')}</b>\n"
        f"пауза после сигнала: {c.get('cooldown', '?')} · нет данных: {c.get('no_data', '?')} · "
        f"устаревшие: {c.get('stale', '?')}\n"
        f"прошли все правила: <b>{c.get('passed', '?')}</b>\n\n"
        f"<b>Чем отсекается:</b>\n{fails}\n\n"
        f"<b>Лучшие пары сейчас:</b>\n{top}",
        parse_mode="HTML")


@router.message(Command("stats_debug"), IsAdmin())
async def cmd_stats_debug(message: Message) -> None:
    lines = ["🔬 <b>STATS DEBUG</b>"]
    for mode in ("LIVE", "DEMO"):
        async with get_session() as s:
            d = await StatsRepository(s).debug(mode)
        ser, att = d["series"], d["attempts"]
        lines.append(
            f"\n<b>{mode}</b>\n"
            f"Signals: <b>{d['total_signals']}</b> · Attempts: <b>{d['total_attempts']}</b>\n"
            f"SERIES → WIN {ser['wins']} / LOSS {ser['losses']} / DRAW {ser['draws']} "
            f"(rate {ser['win_rate']}%)\n"
            f"ATTEMPTS → WIN {att['attempt_wins']} / LOSS {att['attempt_losses']} / "
            f"DRAW {att['attempt_draws']}\n"
            f"by status: {d['by_status']}\n"
            f"oldest: {d['oldest']}\nnewest: {d['newest']}")
    await message.answer("\n".join(lines), parse_mode="HTML")


@router.message(Command("signal_debug"), IsAdmin())
async def cmd_signal_debug(message: Message) -> None:
    parts = (message.text or "").split()
    async with get_session() as s:
        repo = SignalRepository(s)
        if len(parts) >= 2 and parts[1].isdigit():
            sig = await repo.get(int(parts[1]))
        else:
            sig = await repo.last_any(state.mode.value)
        if not sig:
            await message.answer("Сигнал не найден.")
            return
        atts = sorted(sig.attempts, key=lambda a: a.attempt_number)
    body = [
        f"🔎 <b>SIGNAL #{sig.id}</b>",
        f"pair: <b>{sig.symbol}</b> · dir: <b>{sig.direction}</b> · mode: {sig.mode}",
        f"status: {sig.status} · final: {sig.final_result}",
        f"entry_time: {sig.entry_time} · expiry: {sig.expiry_seconds}s",
        f"provider: {sig.provider}",
        "\n<b>Attempts:</b>",
    ]
    for a in atts:
        body.append(
            f"№{a.attempt_number} {a.result} | entry {a.entry_price} @ {a.entry_provider_ts} "
            f"→ exit {a.exit_price} @ {a.exit_provider_ts}")
    if not atts:
        body.append("— нет попыток —")
    await message.answer("\n".join(body), parse_mode="HTML")


async def _refresh_panel(cb: CallbackQuery, note: str) -> None:
    text = (
        f"⚙️ <b>ARTUR TRADE — ПАНЕЛЬ</b>\n\n"
        f"Режим: <b>{state.mode.value}</b>\n"
        f"Движок: <b>{'ACTIVE' if state.engine_on else 'STOPPED'}</b>\n"
        f"AUTO DEMO: <b>{'ON' if state.auto_demo else 'OFF'}</b>\n"
        f"Провайдер: <b>{'ONLINE' if state.provider_online else 'OFFLINE'}</b>\n"
        f"Канал: <b>{'CONNECTED' if state.channel_ok else 'NOT CONNECTED'}</b>\n\n"
        f"ℹ️ {note}"
    )
    try:
        await cb.message.edit_text(text, reply_markup=admin_panel(), parse_mode="HTML")
    except Exception:  # noqa: BLE001
        await cb.message.answer(text, reply_markup=admin_panel(), parse_mode="HTML")


@router.callback_query(F.data == "engine_on", IsAdmin())
async def cb_engine_on(cb: CallbackQuery) -> None:
    ok = await ctrl.start_engine()
    await cb.answer("Engine ON" if ok else "Не удалось запустить")
    await _refresh_panel(cb, "Движок запущен." if ok else
                         "Не удалось: провайдер offline или канал не проверен.")


@router.callback_query(F.data == "engine_off", IsAdmin())
async def cb_engine_off(cb: CallbackQuery) -> None:
    await ctrl.stop_engine()
    await cb.answer("Engine OFF")
    await _refresh_panel(cb, "Движок остановлен.")


@router.callback_query(F.data == "mode_live", IsAdmin())
async def cb_mode_live(cb: CallbackQuery) -> None:
    await cb.answer("Переключаю на LIVE...")
    ok = await ctrl.switch_mode(Mode.LIVE)
    await _refresh_panel(cb, "LIVE FOREX подключён." if ok else
                         "LIVE провайдер offline (проверьте FOREX_API_KEY).")


@router.callback_query(F.data == "mode_demo", IsAdmin())
async def cb_mode_demo(cb: CallbackQuery) -> None:
    await cb.answer("Переключаю на DEMO...")
    await ctrl.switch_mode(Mode.DEMO)
    await _refresh_panel(cb, "DEMO режим активен (mock provider).")


@router.callback_query(F.data == "auto_demo", IsAdmin())
async def cb_auto_demo(cb: CallbackQuery) -> None:
    await cb.answer("Запускаю AUTO DEMO...")
    ok = await ctrl.start_auto_demo()
    await _refresh_panel(cb, "AUTO DEMO запущен — смотрите канал." if ok else
                         "Не удалось запустить AUTO DEMO.")


@router.callback_query(F.data == "stop_demo", IsAdmin())
async def cb_stop_demo(cb: CallbackQuery) -> None:
    await ctrl.stop_auto_demo()
    await cb.answer("AUTO DEMO остановлен")
    await _refresh_panel(cb, "AUTO DEMO остановлен.")


@router.callback_query(F.data == "analyze_now", IsAdmin())
async def cb_analyze(cb: CallbackQuery) -> None:
    await cb.answer("Анализирую рынок...")
    asyncio.create_task(ctrl.analyze_now())
    await _refresh_panel(cb, "Запущен ручной анализ рынка.")


@router.callback_query(F.data == "statistics", IsAdmin())
async def cb_stats(cb: CallbackQuery) -> None:
    stats = await get_stats(state.mode.value)
    await cb.answer()
    await cb.message.answer(stats_caption(stats), parse_mode="HTML")


@router.callback_query(F.data == "provider_status", IsAdmin())
async def cb_provider(cb: CallbackQuery) -> None:
    snap = await snapshot()
    await cb.answer()
    q = f"{snap['last_quote_age']} сек" if snap["last_quote_age"] is not None else "—"
    await cb.message.answer(
        f"📡 <b>Провайдер</b>\n"
        f"Provider: {snap['provider']}\nWebSocket: {snap['websocket']}\n"
        f"Pairs: {snap['pairs']}\nLast quote: {q}",
        parse_mode="HTML")


@router.callback_query(F.data == "last_signals", IsAdmin())
async def cb_last(cb: CallbackQuery) -> None:
    await cb.answer()
    async with get_session() as s:
        rows = await SignalRepository(s).recent(state.mode.value, 10)
    if not rows:
        await cb.message.answer("Пока нет сигналов.")
        return
    lines = [
        f"#{r.id} {r.symbol} {r.direction} {r.score:.0f} → "
        f"{r.final_result or r.status}" for r in rows
    ]
    await cb.message.answer("📝 <b>Последние сигналы</b>\n" + "\n".join(lines),
                            parse_mode="HTML")


@router.callback_query(F.data == "templates", IsAdmin())
async def cb_templates(cb: CallbackQuery) -> None:
    await cb.answer()
    await cb.message.answer("🖼 " + ", ".join(CARD_FILES.keys()))


@router.callback_query(F.data == "preview_cards", IsAdmin())
async def cb_preview(cb: CallbackQuery) -> None:
    await cb.answer("Отправляю превью карточек...")
    for ct in CARD_FILES:
        try:
            await cb.message.answer_photo(FSInputFile(state.cards.path(ct)), caption=ct)
        except Exception as e:  # noqa: BLE001
            await cb.message.answer(f"{ct}: {e}")


@router.callback_query(F.data == "settings", IsAdmin())
async def cb_settings(cb: CallbackQuery) -> None:
    await cb.answer()
    await cb.message.answer(
        f"⚙️ <b>SETTINGS</b>\n"
        f"MIN_SIGNAL_SCORE: {settings.min_signal_score}\n"
        f"ENTRY_SECOND: {settings.entry_second}\n"
        f"EXPIRY: {settings.default_expiry_seconds}s\n"
        f"REPEAT_MODE: {settings.repeat_mode} (max {settings.max_repeats})\n"
        f"PAIR_COOLDOWN: {settings.pair_cooldown_minutes}m\n"
        f"SYMBOLS: {', '.join(settings.active_symbols)}",
        parse_mode="HTML")


@router.callback_query(IsAdmin())
async def cb_fallback(cb: CallbackQuery) -> None:
    await cb.answer("Неизвестная команда")


@router.callback_query()
async def cb_denied(cb: CallbackQuery) -> None:
    await cb.answer("⛔ Только для администратора", show_alert=True)
