"""/status and /stats handlers."""
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.services.health import snapshot
from app.services.state import state
from app.statistics.formatter import stats_caption
from app.statistics.service import get_stats

router = Router()


@router.message(Command("status"))
async def cmd_status(message: Message) -> None:
    snap = await snapshot()
    q = f"{snap['last_quote_age']} сек назад" if snap["last_quote_age"] is not None else "—"
    await message.answer(
        f"🤖 <b>ARTUR TRADE SYSTEM</b>\n\n"
        f"Mode: <b>{snap['mode']}</b>\n"
        f"Telegram: <b>{snap['telegram']}</b>\n"
        f"Channel: <b>{snap['channel']}</b>\n"
        f"Database: <b>ONLINE</b>\n"
        f"Provider: <b>{snap['provider']}</b>\n"
        f"WebSocket: <b>{snap['websocket']}</b>\n"
        f"Pairs: <b>{snap['pairs']}</b>\n"
        f"Last quote: <b>{q}</b>\n"
        f"Engine: <b>{snap['engine']}</b>\n"
        f"Current Signal: <b>{snap['current_signal']}</b>\n"
        f"Signals Today: <b>{snap['signals_today']}</b>\n"
        f"Server: <b>{snap['server_time']}</b>",
        parse_mode="HTML",
    )


@router.message(Command("stats"))
async def cmd_stats(message: Message) -> None:
    stats = await get_stats(state.mode.value)
    await message.answer(stats_caption(stats), parse_mode="HTML")
