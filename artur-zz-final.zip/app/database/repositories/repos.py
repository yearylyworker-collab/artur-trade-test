"""Data access repositories."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import List, Optional

from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models import (
    Signal, SignalAttempt, TelegramMessage, SystemState,
    ProviderHealth, PublicationEvent, TelegramCardAsset,
)


class SignalRepository:
    def __init__(self, session: AsyncSession):
        self.s = session

    async def create(self, **kwargs) -> Signal:
        sig = Signal(**kwargs)
        self.s.add(sig)
        await self.s.flush()
        return sig

    async def get(self, signal_id: int) -> Optional[Signal]:
        res = await self.s.execute(
            select(Signal).options(selectinload(Signal.attempts)).where(Signal.id == signal_id)
        )
        return res.scalar_one_or_none()

    async def update_status(self, signal_id: int, status: str) -> None:
        sig = await self.get(signal_id)
        if sig:
            sig.status = status

    async def add_attempt(self, signal_id: int, attempt_number: int, **kwargs) -> SignalAttempt:
        att = SignalAttempt(signal_id=signal_id, attempt_number=attempt_number, **kwargs)
        self.s.add(att)
        await self.s.flush()
        return att

    async def update_result(self, signal_id: int, result: str, status: str | None = None) -> None:
        """Fill the final result after the trade closed (WIN/LOSS/DRAW)."""
        sig = await self.get(signal_id)
        if sig:
            sig.final_result = result
            if status:
                sig.status = status

    async def get_training_data(self, mode: str):
        """ML training rows, oldest first.

        Returns (rows, y): rows = [{"entry_time", "expiry", "features"}], y = 1 WIN / 0 LOSS.
        Label = result of the FIRST entry (what the filter decides on). DRAW is dropped,
        arbitrage signals are skipped (they bypass the filter), rows without stored
        features are skipped.
        """
        q = (select(Signal.audit, Signal.entry_time, Signal.expiry_seconds, SignalAttempt.result)
             .join(SignalAttempt, SignalAttempt.signal_id == Signal.id)
             .where(Signal.mode == mode, SignalAttempt.attempt_number == 1,
                    SignalAttempt.result.in_(("WIN", "LOSS")))
             .order_by(Signal.entry_time, Signal.id))
        rows, y = [], []
        for audit, entry_time, expiry, result in (await self.s.execute(q)).all():
            audit = audit or {}
            feats = audit.get("ml_features")
            if not feats or audit.get("engine") == "arbitrage":
                continue
            rows.append({"entry_time": entry_time, "expiry": expiry or 60, "features": feats})
            y.append(1 if result == "WIN" else 0)
        return rows, y

    async def active_signals(self, mode: str) -> List[Signal]:
        from app.core.enums import TERMINAL_STATUSES
        terminal = [x.value for x in TERMINAL_STATUSES]
        res = await self.s.execute(
            select(Signal).options(selectinload(Signal.attempts)).where(
                and_(Signal.mode == mode, Signal.status.notin_(terminal))
            )
        )
        return list(res.scalars().all())

    async def recent(self, mode: str, limit: int = 10) -> List[Signal]:
        res = await self.s.execute(
            select(Signal).where(Signal.mode == mode).order_by(Signal.id.desc()).limit(limit)
        )
        return list(res.scalars().all())

    async def last_for_symbol(self, mode: str, symbol: str) -> Optional[Signal]:
        res = await self.s.execute(
            select(Signal).where(and_(Signal.mode == mode, Signal.symbol == symbol))
            .order_by(Signal.id.desc()).limit(1)
        )
        return res.scalar_one_or_none()

    async def last_any(self, mode: str) -> Optional[Signal]:
        res = await self.s.execute(
            select(Signal).where(Signal.mode == mode).order_by(Signal.id.desc()).limit(1)
        )
        return res.scalar_one_or_none()

    async def count_today(self, mode: str) -> int:
        start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        res = await self.s.execute(
            select(func.count(Signal.id)).where(
                and_(Signal.mode == mode, Signal.created_at >= start)
            )
        )
        return int(res.scalar() or 0)


class StatsRepository:
    def __init__(self, session: AsyncSession):
        self.s = session

    async def summary(self, mode: str) -> dict:
        rows = await self.s.execute(
            select(Signal.final_result, Signal.direction, Signal.repeats).where(
                and_(Signal.mode == mode, Signal.final_result.isnot(None))
            )
        )
        wins = losses = draws = buys = sells = repeats = 0
        total = 0
        for result, direction, rep in rows.all():
            total += 1
            if result == "WIN":
                wins += 1
            elif result == "LOSS":
                losses += 1
            elif result == "DRAW":
                draws += 1
            if direction == "BUY":
                buys += 1
            elif direction == "SELL":
                sells += 1
            repeats += rep or 0
        completed = wins + losses
        win_rate = (wins / completed * 100.0) if completed else 0.0
        return {
            "mode": mode, "signals": total, "wins": wins, "losses": losses,
            "draws": draws, "buys": buys, "sells": sells, "repeats": repeats,
            "completed": completed, "win_rate": round(win_rate, 1),
        }

    async def attempt_summary(self, mode: str) -> dict:
        """WIN/LOSS/DRAW counted per ATTEMPT (not per series)."""
        rows = await self.s.execute(
            select(SignalAttempt.result)
            .join(Signal, Signal.id == SignalAttempt.signal_id)
            .where(Signal.mode == mode)
        )
        wins = losses = draws = total = 0
        for (res,) in rows.all():
            total += 1
            if res == "WIN":
                wins += 1
            elif res == "LOSS":
                losses += 1
            elif res == "DRAW":
                draws += 1
        return {"attempts": total, "attempt_wins": wins,
                "attempt_losses": losses, "attempt_draws": draws}

    async def debug(self, mode: str) -> dict:
        """Full reconciliation straight from signals + signal_attempts."""
        total_signals = int((await self.s.execute(
            select(func.count(Signal.id)).where(Signal.mode == mode))).scalar() or 0)
        total_attempts = int((await self.s.execute(
            select(func.count(SignalAttempt.id))
            .join(Signal, Signal.id == SignalAttempt.signal_id)
            .where(Signal.mode == mode))).scalar() or 0)

        status_rows = await self.s.execute(
            select(Signal.status, func.count(Signal.id))
            .where(Signal.mode == mode).group_by(Signal.status)
        )
        by_status = {st: int(c) for st, c in status_rows.all()}

        oldest = (await self.s.execute(
            select(func.min(Signal.created_at)).where(Signal.mode == mode))).scalar()
        newest = (await self.s.execute(
            select(func.max(Signal.created_at)).where(Signal.mode == mode))).scalar()

        series = await self.summary(mode)
        attempts = await self.attempt_summary(mode)
        return {
            "mode": mode, "total_signals": total_signals,
            "total_attempts": total_attempts, "by_status": by_status,
            "oldest": oldest.isoformat() if oldest else None,
            "newest": newest.isoformat() if newest else None,
            "series": series, "attempts": attempts,
        }



class SystemStateRepository:
    def __init__(self, session: AsyncSession):
        self.s = session

    async def get(self, key: str, default: str | None = None) -> str | None:
        res = await self.s.execute(select(SystemState).where(SystemState.key == key))
        row = res.scalar_one_or_none()
        return row.value if row else default

    async def set(self, key: str, value: str) -> None:
        res = await self.s.execute(select(SystemState).where(SystemState.key == key))
        row = res.scalar_one_or_none()
        if row:
            row.value = value
        else:
            self.s.add(SystemState(key=key, value=value))


class TelegramMessageRepository:
    def __init__(self, session: AsyncSession):
        self.s = session

    async def save(self, signal_id: int | None, chat_id: int, message_id: int, kind: str) -> None:
        self.s.add(TelegramMessage(
            signal_id=signal_id, chat_id=chat_id, message_id=message_id, kind=kind))

    async def latest_for_signal(self, signal_id: int) -> Optional[TelegramMessage]:
        res = await self.s.execute(
            select(TelegramMessage).where(TelegramMessage.signal_id == signal_id)
            .order_by(TelegramMessage.id.desc()).limit(1)
        )
        return res.scalar_one_or_none()


class PublicationEventRepository:
    def __init__(self, session: AsyncSession):
        self.s = session

    async def exists(self, event_id: str) -> bool:
        res = await self.s.execute(
            select(PublicationEvent.id).where(PublicationEvent.event_id == event_id)
        )
        return res.scalar_one_or_none() is not None

    async def record(self, event_id: str, signal_id: int | None, status: str = "sent") -> None:
        self.s.add(PublicationEvent(event_id=event_id, signal_id=signal_id, status=status))


class ProviderHealthRepository:
    def __init__(self, session: AsyncSession):
        self.s = session

    async def record(self, provider: str, online: bool, detail: str | None = None) -> None:
        self.s.add(ProviderHealth(provider=provider, online=online, detail=detail))


class CardAssetRepository:
    def __init__(self, session: AsyncSession):
        self.s = session

    async def get(self, card_type: str) -> Optional[TelegramCardAsset]:
        res = await self.s.execute(
            select(TelegramCardAsset).where(TelegramCardAsset.card_type == card_type))
        return res.scalar_one_or_none()

    async def all(self) -> List[TelegramCardAsset]:
        res = await self.s.execute(select(TelegramCardAsset))
        return list(res.scalars().all())

    async def upsert(self, card_type: str, local_filename: str,
                     file_id: str, unique_id: str | None) -> None:
        row = await self.get(card_type)
        if row:
            row.telegram_file_id = file_id
            row.telegram_file_unique_id = unique_id
            row.local_filename = local_filename
        else:
            self.s.add(TelegramCardAsset(
                card_type=card_type, local_filename=local_filename,
                telegram_file_id=file_id, telegram_file_unique_id=unique_id))
