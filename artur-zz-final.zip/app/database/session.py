"""Async DB engine & session factory."""
from __future__ import annotations

from sqlalchemy.ext.asyncio import (
    AsyncSession, async_sessionmaker, create_async_engine,
)

from app.config import settings
from app.core.logging_config import get_logger
from app.database.models import Base

log = get_logger("database.session")

engine = create_async_engine(settings.database_url, echo=False, pool_pre_ping=True)

if settings.database_url.startswith("sqlite"):
    from pathlib import Path

    from sqlalchemy import event

    # make sure ./runtime exists (Railway volume is mounted there)
    _db_path = settings.database_url.split("///", 1)[-1]
    if _db_path and _db_path != ":memory:":
        Path(_db_path).parent.mkdir(parents=True, exist_ok=True)

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_pragmas(dbapi_conn, _record):  # noqa: ANN001
        """WAL mode: readers don't block the writer; survives crashes better."""
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.execute("PRAGMA busy_timeout=5000")
        cur.close()
SessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    log.info("DB connected & schema ready")


async def close_db() -> None:
    await engine.dispose()


def get_session() -> AsyncSession:
    return SessionLocal()
