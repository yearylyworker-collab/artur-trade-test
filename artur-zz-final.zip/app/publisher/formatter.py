"""Telegram caption formatting — ARTUR TRADE.

House style (from the channel's caption guide):
  * bold heading, <blockquote> with details, <i> explanation, <tg-spoiler>
    for results, technical values in <code>;
  * moderate emoji, no hashtags, short text;
  * a line whose data is missing is dropped entirely.

Honesty rules baked in:
  * no "probability %" — the engine score is an internal 0-100 quality score,
    not a chance to win, and is labelled as such;
  * window results always show the per-entry count next to "+1 / −1";
  * money lines ("% к депозиту") appear only if STAKE_PERCENT is configured.

Photo captions are limited to 1024 characters by Telegram.
"""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional, Sequence, Tuple

from app.config import settings
from app.core.time_utils import fmt_time, utc_now
from app.signals.snapshot import DIRECTION_META, SignalPublicationSnapshot

ATTEMPT_ICON = {"WIN": "✅", "LOSS": "❌", "DRAW": "➖"}
NUM_ICON = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"]


def pair_label(symbol: str) -> str:
    """EURUSD_otc -> EURUSD OTC, EUR/USD stays."""
    if symbol.lower().endswith("_otc"):
        return symbol[:-4] + " OTC"
    return symbol


def _expiry_label(seconds: int) -> str:
    if seconds % 60 == 0:
        return f"{seconds}s" if seconds == 60 else f"{seconds // 60} мин"
    return f"{seconds}s"


def _lead_seconds(snapshot: SignalPublicationSnapshot) -> int:
    return max(0, int((snapshot.entry_time - utc_now()).total_seconds()))


def _dir_word(direction: str) -> str:
    return "CALL ⬆️" if direction == "BUY" else "PUT ⬇️"


def _lines(*items: Optional[str]) -> str:
    """Join non-empty lines (missing data -> line dropped)."""
    return "\n".join(i for i in items if i)


# ---------------------------------------------------------------- service ----
def pair_summary(pairs_count: int) -> dict:
    """{"total", "low", "tradeable", "min_payout"} from the live provider."""
    try:
        from app.services.state import state
        st = dict(getattr(state.provider, "pair_stats", {}) or {})
    except Exception:  # noqa: BLE001
        st = {}
    total = st.get("total") or pairs_count
    low = st.get("low", 0)
    return {"total": total, "low": low, "tradeable": pairs_count,
            "min_payout": st.get("min_payout", 0)}


def _pairs_block(timeframe: str, pairs_count: int) -> str:
    s = pair_summary(pairs_count)
    if not s["low"] or s["total"] <= s["tradeable"]:
        return f"📊 <b>В анализе:</b> <code>{pairs_count} пар · {timeframe}</code>"
    return (f"🌐 <b>Всего пар:</b> <code>{s['total']}</code>\n"
            f"🚫 <b>Невыгодные (выплата &lt; {s['min_payout']}%):</b> <code>{s['low']} ({s['low'] * 100 // max(1, s['total'])}%)</code>\n"
            f"✅ <b>Торгуем:</b> <code>{s['tradeable']} пар · {timeframe}</code>")

def engine_caption(timeframe: str, pairs_count: int) -> str:
    market = "OTC" if settings.is_pocket else "Forex"
    return (
        "<b>🚀 ДВИЖОК ЗАПУЩЕН. СИСТЕМА ON-LINE</b>\n\n"
        "Торговый алгоритм запущен и готов к работе.\n\n"
        "<blockquote>📡 <b>Статус:</b> Активен\n"
        "⚙️ <b>Режим:</b> Поиск сигналов\n"
        f"📊 <b>Рынок:</b> <code>{market}</code>\n"
        f"{_pairs_block(timeframe, pairs_count)}</blockquote>\n\n"
        "<i>Бот сканирует рынок в реальном времени. Следите за обновлениями!</i> 👇"
    )


def counters_block() -> str:
    """"Checking new signal" + real plus/minus counters (cached on state)."""
    try:
        from app.services.state import state
        c = getattr(state, "counters", None) or {}
    except Exception:  # noqa: BLE001
        c = {}
    return (
        "<blockquote><b>🗣 Checking new signal...</b></blockquote>\n"
        f"<blockquote><b>📊 Общая статистика: {c.get('win', 0)}➕ {c.get('loss', 0)}➖\n"
        f"Сегодня: {c.get('win_today', 0)}➕ {c.get('loss_today', 0)}➖</b></blockquote>"
    )


def search_caption(timeframe: str, pairs_count: int) -> str:
    return (
        "<b>🔎 ИЩЕМ СИГНАЛ. МОНИТОРИНГ РЫНКА</b>\n\n"
        "Сейчас находимся в режиме ожидания — бот анализирует рынок.\n\n"
        "<blockquote>👀 <b>Что делаем:</b> Мониторим графики\n"
        f"{_pairs_block(timeframe, pairs_count)}\n"
        "⏳ <b>Статус:</b> <i>Ожидание подтверждения...</i></blockquote>\n\n"
        "<i>Не торгуем ради торговли! Ждём идеальных условий.</i>\n\n"
        + counters_block()
    )


def platform_caption(timeframe: str, expiry_seconds: int) -> str:
    market = "OTC" if settings.is_pocket else "Forex"
    return (
        "<b>⚙️ ПРОВЕРЬТЕ НАСТРОЙКИ ПЛАТФОРМЫ</b>\n\n"
        "Для полной синхронизации с системой перед сигналом:\n\n"
        "<blockquote>📈 <b>График:</b> <code>Heiken Ashi</code>\n"
        f"🌐 <b>Рынок:</b> <code>{market}</code>\n"
        f"⏳ <b>Таймфрейм:</b> <code>{timeframe}</code>\n"
        f"⏱ <b>Время сделки:</b> <b>{trade_tag(expiry_seconds, timeframe)}</b></blockquote>\n\n"
        "<i>Подготовьте платформу заранее — вход строго по времени сигнала!</i> ✅"
    )


def analysis_caption(pair: str, market: str, timeframe: str,
                     expiry_seconds: Optional[int] = None, entry_second: Optional[int] = None,
                     attempts: Optional[int] = None) -> str:
    if expiry_seconds:
        return (
            "<b>🧠 АНАЛИЗ СИГНАЛА. ОТБОР ПО СИСТЕМЕ</b>\n\n"
            f"<blockquote>💱 <b>Пара:</b> <code>{pair_label(pair)}</code>\n"
            "✅ Heikin Ashi и режим рынка\n"
            "✅ EMA 3/8/25, RSI, MACD\n"
            "✅ Волатильность, шум, выплата</blockquote>\n\n"
            f"📋 <b>Параметры входа:</b> график <code>{timeframe}</code> · вход на "
            f"<code>:{entry_second:02d}</code> · время сделки <b>{trade_tag(expiry_seconds, timeframe)}</b>"
            + (f" · до <code>{attempts}</code> входов" if attempts and attempts > 1 else "") + "\n\n"
            "<i>Откройте пару и выставьте время сделки — сигнал с направлением следующим "
            "сообщением ⏳</i>"
        )
    return (
        "<b>🧠 АНАЛИЗ СИГНАЛА. ОТБОР ПО СИСТЕМЕ</b>\n\n"
        f"<blockquote>💱 <b>Пара:</b> <code>{pair_label(pair)}</code> · {timeframe}\n"
        "1️⃣ Heikin Ashi и режим рынка\n"
        "2️⃣ EMA 3/8/25, RSI, MACD\n"
        "3️⃣ Волатильность и шум\n"
        "4️⃣ Подтверждение входа</blockquote>\n\n"
        "<i>Решение ещё не принято — держим на контроле ⏳</i>"
    )


# ---------------------------------------------------------------- signal -----
def _meta_lines(indicators: Optional[dict], score: Optional[float],
                engine: str = "ha") -> List[str]:
    ind = indicators or {}
    out: List[str] = []
    if engine == "arbitrage" and ind.get("gap") is not None:
        out.append(f"⚖️ <b>Арбитраж:</b> гэп <code>{ind['gap']:+.5f}</code>")
    rsi, atr = ind.get("rsi"), ind.get("atr")
    if rsi is not None and atr is not None:
        out.append(f"📈 <b>RSI:</b> <code>{rsi:.1f}</code> | <b>ATR:</b> <code>{atr:.5f}</code>")
    if score is not None and engine != "arbitrage":
        out.append(f"⭐ <b>Оценка системы:</b> <code>{score:.0f}/100</code>")
    return out


def signal_caption(snapshot: SignalPublicationSnapshot) -> str:
    """Single-entry signal (used when WINDOW_MODE=false)."""
    m = DIRECTION_META[snapshot.direction]
    return (
        f"<b>⚡️ НАЙДЕН ТОРГОВЫЙ СИГНАЛ ⚡️</b>\n\n"
        f"<blockquote>{m['emoji']} <b>Пара:</b> <code>{pair_label(snapshot.pair)}</code>\n"
        f"🎯 <b>Сделка:</b> <b>{snapshot.direction}</b> ({_dir_word(snapshot.direction)})\n"
        f"⏱ <b>Вход:</b> <code>{fmt_time(snapshot.entry_time)}</code>\n"
        f"⏳ <b>Экспирация:</b> <code>{_expiry_label(snapshot.expiry_seconds)}</code>\n"
        f"📊 <b>Таймфрейм:</b> <code>{snapshot.timeframe}</code></blockquote>\n\n"
        f"<i>До входа ≈ {_lead_seconds(snapshot)} сек. Сигнал от нашего бота</i> 🤖"
    )


def window_plan(first_entry: datetime, attempts: int, step_seconds: int) -> List[datetime]:
    from datetime import timedelta
    return [first_entry + timedelta(seconds=step_seconds * i) for i in range(attempts)]


def window_start_caption(snapshot: SignalPublicationSnapshot, plan: Sequence[datetime],
                         indicators: Optional[dict] = None, score: Optional[float] = None,
                         engine: str = "ha") -> str:
    m = DIRECTION_META[snapshot.direction]
    from datetime import timedelta as _td
    plan_lines = "\n".join(
        f"{NUM_ICON[i] if i < len(NUM_ICON) else i + 1} вход <code>{fmt_time(t)}</code> → "
        f"закрытие <code>{fmt_time(t + _td(seconds=snapshot.expiry_seconds))}</code>"
        for i, t in enumerate(plan))
    body = _lines(
        f"{m['emoji']} <b>Пара:</b> <code>{pair_label(snapshot.pair)}</code>",
        f"🎯 <b>Сделка:</b> <b>{snapshot.direction}</b> ({_dir_word(snapshot.direction)})",
        f"⏱ <b>Время сделки:</b> <b>{trade_tag(snapshot.expiry_seconds, snapshot.timeframe)}</b>",
        f"📊 <b>График:</b> Heikin Ashi <code>{snapshot.timeframe}</code>",
        *_meta_lines(indicators, score, engine),
    )
    if len(plan) == 1:  # single entry — template "НАЙДЕН ТОРГОВЫЙ СИГНАЛ"
        ind = indicators or {}
        dot = "🟢" if snapshot.is_buy else "🔴"
        lines = _lines(
            f"{dot} <b>Пара:</b> <code>{pair_label(snapshot.pair)}</code>",
            f"{dot} <b>Сделка:</b> <b>{snapshot.direction}</b> ({'Вверх' if snapshot.is_buy else 'Вниз'})",
            f"⏱ <b>Время:</b> <code>{fmt_time(plan[0])}</code>",
            f"⏳ <b>Таймфрейм:</b> <code>{snapshot.timeframe}</code> · время сделки "
            f"<code>{_dur(snapshot.expiry_seconds)}</code>",
            (f"💰 <b>Выплата:</b> <b>{ind['payout']}%</b>" if ind.get("payout") else None),
            (f"💵 <b>Ставка:</b> {settings.stake_percent:g}% от депозита"
             if settings.stake_percent > 0 else None),
            (f"📈 <b>RSI:</b> <code>{ind['rsi']:.1f}</code>" if ind.get("rsi") is not None else None),
            (f"⭐ <b>Оценка системы:</b> <b>{score:.0f}/100</b>"
             if score is not None and engine != "arbitrage" else None),
        )
        return (
            "<b>⚡️ НАЙДЕН ТОРГОВЫЙ СИГНАЛ! ⚡️</b>\n\n"
            f"<blockquote>{lines}</blockquote>\n\n"
            "<i>Сигнал от нашего бота</i> 🤖"
        )
    try:
        from app.services.runtime import DURATION_REASON
        why = DURATION_REASON.get(snapshot.timeframe)
    except Exception:  # noqa: BLE001
        why = None
    params = (f"<i>Экспирация выбрана по статистике: {why}</i>"
              if why and not settings.trade_seconds else "")
    cap = _window_caption(snapshot, plan, body, params, plan_lines)
    if len(cap) > 1024:   # Telegram photo caption limit: drop RSI/ATR/score lines
        body = _lines(*body.split("\n")[:4])
        cap = _window_caption(snapshot, plan, body, params, plan_lines)
    if len(cap) > 1024:
        cap = _window_caption(snapshot, plan, body, "", plan_lines)
    return cap


def _window_caption(snapshot, plan, body, params, plan_lines) -> str:
    return (
        "<b>⚡️ НАЙДЕН ТОРГОВЫЙ СИГНАЛ! ⚡️</b>\n\n"
        f"<blockquote>{body}</blockquote>\n\n"
        + (f"{params}\n\n" if params else "") +
        f"<blockquote>🪟 <b>Торговое окно:</b> <code>{fmt_time(plan[0])} – {fmt_time(plan[-1])}</code>\n"
        f"🎯 <b>План входов (макс {len(plan)}) · {trade_tag(snapshot.expiry_seconds, snapshot.timeframe)}:</b>\n"
        f"{plan_lines}</blockquote>\n\n"
        f"<i>Вход строго на :{plan[0].second:02d} "
        f"{'каждой минуты' if len(plan) < 2 or (plan[1] - plan[0]).total_seconds() <= 60 else 'по плану выше'}. "
        + ("Ставки — с перекрытием, по инструкции.</i>"
           if settings.howto_stake_mode.lower() == "overlap" else
           "Каждый вход — отдельная ставка, сумму не увеличиваем.</i>")
    )


def window_result_caption(snapshot: SignalPublicationSnapshot, final: str,
                          history: Sequence[Tuple[int, datetime, str]],
                          plan: Sequence[datetime]) -> str:
    """history: [(attempt_number, entry_time, 'WIN'|'LOSS'|'DRAW'), ...]"""
    n = len(history)
    wins = sum(1 for _, _, r in history if r == "WIN")
    losses = sum(1 for _, _, r in history if r == "LOSS")
    steps = "\n".join(f"{ATTEMPT_ICON.get(r, '•')} Вход {i}: <code>{fmt_time(t)}</code>"
                      for i, t, r in history)
    if final == "WIN":
        head = f"<b>✅ ИТОГ ОКНА: ПЛЮС</b> (на входе {n})"
        spoiler = "<b>+1 ПЛЮС ✅</b>"
    elif final == "DRAW":
        head = "<b>➖ ИТОГ ОКНА: БЕЗ ИЗМЕНЕНИЙ</b>"
        spoiler = "<b>DRAW ➖</b>"
    else:
        head = "<b>❌ ИТОГ ОКНА: МИНУС</b> (все входы в минус)"
        spoiler = "<b>−1 МИНУС ❌</b>"
    money = ""
    if settings.stake_percent > 0:
        res = settings.stake_percent * (wins * settings.payout_percent / 100.0 - losses)
        money = f"\n💰 <b>Итог по входам:</b> <code>{res:+.2f}%</code> к депозиту"
    if len(plan) == 1 and history:  # single entry — templates "РЕЗУЛЬТАТ WIN/LOSS"
        _, t, r = history[0]
        pair = pair_label(snapshot.pair)
        if r == "WIN":
            profit = (f"💰 <b>Результат:</b> <code>+{settings.stake_percent * settings.payout_percent / 100:.2f}%</code>"
                      " к депозиту\n" if settings.stake_percent > 0 else "")
            return (
                "<b>✅ РЕЗУЛЬТАТ СИГНАЛА</b>\n\n"
                f"📈 <b>Пара:</b> <code>{pair}</code>\n{profit}\n"
                f"<blockquote>🔥 <b>Сделка:</b> <b>{snapshot.direction}</b> · "
                f"вход <code>{fmt_time(t)}</code></blockquote>\n\n"
                "<b>Итог:</b> <tg-spoiler><b>WIN ✅</b></tg-spoiler>\n\n"
                "<i>Спасибо за доверие, работаем дальше!</i> 🚀"
            )
        if r == "LOSS":
            return (
                "<b>❌ РЕЗУЛЬТАТ СИГНАЛА</b>\n\n"
                f"📉 <b>Пара:</b> <code>{pair}</code>\n"
                f"📉 <b>Причина:</b> рынок пошёл против входа "
                f"(<b>{snapshot.direction}</b>, <code>{fmt_time(t)}</code>)\n\n"
                "<blockquote>⚠️ <b>Важно:</b> Убыток — это часть торговли. "
                "Главное — не отыгрываться!</blockquote>\n\n"
                "<b>Итог:</b> <tg-spoiler><b>LOSS ❌</b></tg-spoiler>"
            )
        return (
            "<b>➖ РЕЗУЛЬТАТ СИГНАЛА</b>\n\n"
            f"📊 <b>Пара:</b> <code>{pair}</code>\n\n"
            "<blockquote>⚖️ Цена закрылась на уровне входа — ставка возвращается.</blockquote>\n\n"
            "<b>Итог:</b> <tg-spoiler><b>DRAW ➖</b></tg-spoiler>"
        )
    arrow = "⬆️" if snapshot.direction == "BUY" else "⬇️"
    steps = "\n".join(
        f"{ATTEMPT_ICON.get(r, '•')} <b>Вход {i}</b> — <code>{fmt_time(t)}</code>"
        + {"WIN": " <i>плюс</i>", "LOSS": " <i>минус</i>", "DRAW": " <i>возврат</i>"}.get(r, "")
        for i, t, r in history)
    return (
        f"💱 <b>{pair_label(snapshot.pair)}</b> · <i>{snapshot.direction} {arrow}</i>\n\n"
        f"<blockquote>🪟 <b>Торговое окно:</b> <code>{fmt_time(plan[0])} – {fmt_time(plan[-1])}</code>\n"
        f"{steps}</blockquote>\n\n"
        f"<blockquote>🎯 <b>Входов сделано:</b> <code>{n}</code> · <i>✅ {wins} / ❌ {losses}</i>"
        f"{money}\n"
        f"🏁 <b>Итог:</b> <tg-spoiler>{spoiler}</tg-spoiler></blockquote>"
        + {"WIN": "\n\n<i>Плюс взят — останавливаемся и ждём следующий сигнал</i> ✅",
           "LOSS": "\n\n<i>Окно закрыто. Не отыгрываемся — ждём следующий сигнал.</i>"}
        .get(final, "")
    )


def reentry_caption(snapshot: SignalPublicationSnapshot, repeat_number: int) -> str:
    return (
        "<b>🔄 ПОВТОР СИГНАЛА. ПОВТОРНЫЙ ВХОД</b>\n\n"
        f"<blockquote>🎯 <b>Действие:</b> Вход №{repeat_number}\n"
        f"📉 <b>Направление:</b> <b>{snapshot.direction}</b>\n"
        f"⏱ <b>Вход:</b> <code>{fmt_time(snapshot.entry_time)}</code>\n"
        f"⏳ <b>Экспирация:</b> <code>{_expiry_label(snapshot.expiry_seconds)}</code></blockquote>\n\n"
        "<i>Совет: следите за риском, не увеличивайте ставку сверх нормы!</i>"
    )


# ---------------------------------------------------------------- result -----
def result_caption(snapshot: SignalPublicationSnapshot, result: str,
                   attempt_number: int, repeats: int) -> str:
    pair = pair_label(snapshot.pair)
    if result == "WIN":
        return (
            "<b>✅ РЕЗУЛЬТАТ СИГНАЛА</b>\n\n"
            f"📈 <b>Пара:</b> <code>{pair}</code>\n"
            f"<blockquote>🔥 <b>Сделка:</b> <b>{snapshot.direction}</b> · вход №{attempt_number}</blockquote>\n\n"
            "<b>Итог:</b> <tg-spoiler><b>WIN ✅</b></tg-spoiler>\n\n"
            "<i>Работаем дальше!</i> 🚀"
        )
    if result == "LOSS":
        return (
            "<b>❌ РЕЗУЛЬТАТ СИГНАЛА</b>\n\n"
            f"📉 <b>Пара:</b> <code>{pair}</code> · <b>{snapshot.direction}</b>\n"
            "<blockquote>⚠️ <b>Важно:</b> Убыток — это часть торговли. "
            "Главное — не отыгрываться!</blockquote>\n\n"
            "<b>Итог:</b> <tg-spoiler><b>LOSS ❌</b></tg-spoiler>"
        )
    if result == "DRAW":
        return (
            "<b>➖ РЕЗУЛЬТАТ СИГНАЛА</b>\n\n"
            f"📊 <b>Пара:</b> <code>{pair}</code> · <b>{snapshot.direction}</b>\n"
            "<blockquote>⚖️ Цена закрылась на уровне входа</blockquote>\n\n"
            "<b>Итог:</b> <tg-spoiler><b>DRAW ➖</b></tg-spoiler>"
        )
    return (
        "<b>⚠️ РЕЗУЛЬТАТ НЕДОСТУПЕН</b>\n\n"
        f"<blockquote>💱 <b>Пара:</b> <code>{pair}</code> · <b>{snapshot.direction}</b>\n"
        "Не удалось получить точную котировку</blockquote>\n\n"
        "<i>Сигнал не засчитан ни в плюс, ни в минус. Продолжаем анализ.</i>"
    )


def skipped_caption(pair: str, reason: str) -> str:
    return (
        "<b>⏸ СИГНАЛ ПРОПУЩЕН. ТОЧКА ВХОДА НЕ ПОДОШЛА</b>\n\n"
        f"<blockquote>💱 <b>Пара:</b> <code>{pair_label(pair)}</code>\n"
        f"⚠️ <b>Причина:</b> {reason}\n"
        "🚫 <b>Действие:</b> Пропускаем сделку.</blockquote>\n\n"
        "<i>Дисциплина важнее количества сделок! Не гоняемся за рынком.</i>"
    )


# ---------------------------------------------------------------- modes ------
def _zones() -> List[Tuple[str, str]]:
    """[(label, tz_name)] from DISPLAY_ZONES ("🇺🇦 Украина:Europe/Kyiv")."""
    out = []
    for item in settings.display_zones:
        if ":" in item:
            label, tz = item.rsplit(":", 1)
            out.append((label.strip(), tz.strip()))
    return out or [("🕐", settings.timezone)]


def _in_zone(dt: datetime, tz: str, fmt: str = "%H:%M:%S") -> str:
    from zoneinfo import ZoneInfo
    try:
        return dt.astimezone(ZoneInfo(tz)).strftime(fmt)
    except Exception:  # noqa: BLE001
        return fmt_time(dt)


def expiry_human(seconds: int) -> str:
    return f"{seconds} сек" if seconds < 60 else (
        "1 мин" if seconds == 60 else f"{seconds // 60} мин")


def trade_tag(seconds: int, timeframe: str) -> str:
    """Pocket Option style: '5 SEC • M1', '1 MIN • M1', '15 SEC • S30'."""
    t = f"{seconds} SEC" if seconds < 60 else f"{seconds // 60} MIN"
    return f"{t} • {timeframe}"


def _dur(seconds: int) -> str:
    """5 -> '5 сек', 60 -> '1 мин (60 сек)', 300 -> '5 мин (300 сек)'."""
    return expiry_human(seconds) + (f" ({seconds} сек)" if seconds >= 60 else "")


def mode_switch_caption(old: dict, new: dict, effective_at: datetime, reason: str) -> str:
    """Warning posted ADAPTIVE_WARNING_LEAD seconds before new parameters apply."""
    rows = []
    if old["timeframe"] != new["timeframe"]:
        rows.append(f"📊 <b>Таймфрейм:</b> <code>{old['timeframe']}</code> → "
                    f"<code>{new['timeframe']}</code>")
        rows.append(f"⏱ <b>Время сделки:</b> <b>{trade_tag(old['expiry'], old['timeframe'])}</b> → "
                    f"<b>{trade_tag(new['expiry'], new['timeframe'])}</b>")
    if old["entry_second"] != new["entry_second"]:
        rows.append(f"🎯 <b>Секунда входа:</b> <code>:{old['entry_second']:02d}</code> → "
                    f"<code>:{new['entry_second']:02d}</code>")
    if old["window_length"] != new["window_length"]:
        rows.append(f"🪟 <b>Длина окна:</b> <code>{old['window_length']}</code> → "
                    f"<code>{new['window_length']}</code> входов")
    when = "\n".join(f"{label} <code>{_in_zone(effective_at, tz)}</code>"
                     for label, tz in _zones())
    lead = max(1, round((effective_at - utc_now()).total_seconds() / 60))
    return (
        "<b>⚠️ СМЕНА РЕЖИМА</b>\n\n"
        "<blockquote>" + "\n".join(rows) + "</blockquote>\n\n"
        f"🕐 <b>Вступает в силу:</b>\n{when}\n"
        f"⏳ У вас ≈{lead} мин, чтобы переключить настройки в Pocket Option\n\n"
        f"📈 <i>Причина: {reason}</i>"
    )


def duration_switch_caption(old: int, new: int, timeframe: str, effective_at: datetime,
                            reason: str) -> str:
    when = "\n".join(f"{label} <code>{_in_zone(effective_at, tz)}</code>"
                     for label, tz in _zones())
    lead = max(1, round((effective_at - utc_now()).total_seconds() / 60))
    return (
        "<b>⏱ СМЕНА ВРЕМЕНИ СДЕЛКИ</b>\n\n"
        f"<blockquote>⏱ <b>Время сделки:</b> <b>{trade_tag(old, timeframe)}</b> → <b>{trade_tag(new, timeframe)}</b>\n"
        f"📊 <b>Таймфрейм:</b> <code>{timeframe}</code> <i>без изменений</i></blockquote>\n\n"
        f"🕐 <b>Вступает в силу:</b>\n{when}\n"
        f"⏳ У вас ≈{lead} мин, чтобы выставить новое время сделки в Pocket Option\n\n"
        f"📈 <i>Причина: {reason}</i>"
    )


def overlap_ladder(base: float, payout: float, n: int) -> List[float]:
    """Stakes so that a win on entry k covers all previous losses + base*payout profit."""
    out: List[float] = []
    for _ in range(n):
        s = (sum(out) + base * payout) / payout if out else base
        out.append(round(s, 2))
    return out


def _money(x: float) -> str:
    return f"{x:.2f}".rstrip("0").rstrip(".") + "$"


def howto_caption(example_start: Optional[datetime] = None) -> str:
    """"❓ Как торгуем по сигналам" — the owner's text, adapted to the CURRENT mode.

    Stakes are FIXED per entry (no doubling): with ~85% payout a 5-step
    doubling ladder risks ~300 stakes to win ~0.9 of one, and a single full
    loss wipes out dozens of wins — subscribers drain deposits fast.
    """
    from datetime import timedelta
    tf = settings.default_timeframe
    exp = settings.default_expiry_seconds
    sec = settings.entry_second
    n = max(1, settings.max_attempts)
    step = 60 * max(1, -(-exp // 60))
    stake_pct = settings.howto_stake_percent
    stake = f"{stake_pct * 1:g}$"          # example: deposit 100$ -> stake_pct $
    first = example_start or (utc_now().replace(second=sec, microsecond=0) + timedelta(minutes=2))
    plan = [first + timedelta(seconds=step * i) for i in range(n)]
    label, tz = _zones()[0]
    t = [_in_zone(x, tz) for x in plan]
    candle = {"S30": "30-секундной", "M1": "минутной", "M5": "5-минутной"}.get(tf, tf)
    ordinals = ["первая", "вторая", "третья", "четвёртая", "пятая"]
    nxt = ["вторую", "третью", "четвёртую", "пятую"]
    step_txt = "следующую минуту" if step == 60 else f"следующий вход через {step // 60} мин"
    payout = settings.otc_min_payout or int(settings.payout_percent)
    overlap = settings.howto_stake_mode.lower() == "overlap" and n > 1
    stakes = (overlap_ladder(stake_pct, payout / 100, n) if overlap else [stake_pct] * n)
    lines = []
    for i in range(n):
        num = NUM_ICON[i]
        st = _money(stakes[i])
        if i < n - 1:
            lines.append(f"{num}Не зашла {ordinals[i]}🚫 Ставили {st}, вход был {t[i]} — "
                         f"идём на {nxt[i] if step == 60 else step_txt}.")
        else:
            lines.append(f"{num}{'Последний' if n > 1 else 'Единственный'} вход {t[i]}, "
                         f"ставили {st}. Забрали ➕ ☑️")
    window = (f"Каждый сигнал содержит торговое окно, например: <code>{t[0]} – {t[-1]}</code>"
              if n > 1 else f"Каждый сигнал — один вход, например: <code>{t[0]}</code>")
    total = sum(stakes)
    if overlap:
        stake_head = f"депозит 100$ → первая ставка {_money(stakes[0])}, дальше с перекрытием"
        money = (
            "💰 <b>Перекрытие:</b> каждая следующая ставка перекрывает все прошлые минусы "
            f"и даёт тот же плюс ≈ <b>{_money(stakes[0] * payout / 100)}</b>, на каком бы "
            "входе ни зашло.\n"
            f"⚠️ <b>Риск:</b> если не зайдут все {n} входов — минус <b>{_money(total)}</b> "
            f"(≈{total:.0f}% депозита). Ставки считайте от своего депозита, первая — "
            f"{stake_pct:g}%, не больше.\n"
            "🛑 Одно окно полностью в минус — на сегодня стоп, не отыгрываемся."
        )
    else:
        stake_head = f"депозит 100$ → ставка {_money(stakes[0])} на КАЖДЫЙ вход"
        money = (
            f"💰 Ставка всегда одна и та же — {stake_pct:g}% от депозита. После минуса сумму "
            "<b>не увеличиваем</b>.\n"
            f"🛑 {settings.howto_daily_stop_windows} минусовых окна за день — на сегодня стоп."
        )
    return (
        "<b>❓Как торгуем по сигналам</b> 👇\n\n"
        "<b>📊 Система сигналов / Настройки</b>\n"
        f"<blockquote>Свечи Heikin Ashi (Тайм Фрейм <b>{tf}</b>)\n"
        f"• Время сделки: <b>{trade_tag(exp, tf)}</b>\n"
        f"• Вход на <b>{sec}-й секунде</b></blockquote>\n\n"
        f"{window}\n"
        f"Вход выполняется не в начале минуты, а ровно на {sec}-й секунде {candle} свечи "
        f"(время — {label}).\n\n"
        f"<b>Пример входов</b> ({stake_head}): 👇\n"
        "<blockquote>" + "\n".join(lines) + "</blockquote>\n\n"
        "❗️Как только любая сделка закрывается в плюс — сразу останавливаемся и ждём "
        "следующий сигнал в канале.\n\n"
        f"{money}\n"
        f"<i>При выплате {payout}% гарантий нет — торгуйте только суммой, которую готовы потерять.</i>"
    )
