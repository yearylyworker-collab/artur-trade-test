"""Publication queue with idempotency + retry + duplicate protection."""
from __future__ import annotations

import asyncio
from typing import Optional

from app.core.logging_config import get_logger
from app.database.repositories.repos import PublicationEventRepository
from app.database.session import get_session
from app.publisher.telegram import TelegramPublisher

log = get_logger("publisher.queue")


class TelegramPublicationQueue:
    """Serializes publications; guarantees each event_id is sent at most once."""

    def __init__(self, publisher: TelegramPublisher):
        self.publisher = publisher
        self._lock = asyncio.Lock()

    async def _already_sent(self, event_id: str) -> bool:
        async with get_session() as s:
            return await PublicationEventRepository(s).exists(event_id)

    async def _record(self, event_id: str, signal_id: Optional[int]) -> None:
        async with get_session() as s:
            await PublicationEventRepository(s).record(event_id, signal_id)
            await s.commit()

    async def send_card(self, event_id: str, signal_id: Optional[int],
                        image_path: str, caption: str, retries: int = 3) -> Optional[int]:
        async with self._lock:
            if await self._already_sent(event_id):
                log.info("duplicate suppressed: %s", event_id)
                return None
            for attempt in range(1, retries + 1):
                try:
                    message_id = await self.publisher.send_card(image_path, caption)
                    await self._record(event_id, signal_id)
                    return message_id
                except Exception as e:  # noqa: BLE001
                    log.warning("send attempt %d failed: %s", attempt, e)
                    await asyncio.sleep(attempt * 2)
            log.error("send failed after retries: %s", event_id)
            return None

    async def edit_card(self, message_id: int, image_path: str, caption: str,
                       retries: int = 3) -> bool:
        async with self._lock:
            for attempt in range(1, retries + 1):
                try:
                    ok = await self.publisher.edit_card(message_id, image_path, caption)
                    return ok
                except Exception as e:  # noqa: BLE001
                    log.warning("edit attempt %d failed: %s", attempt, e)
                    await asyncio.sleep(attempt * 2)
            return False
