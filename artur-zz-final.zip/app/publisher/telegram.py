"""Thin wrapper over aiogram bot for sending / editing channel media."""
from __future__ import annotations

from typing import Optional

from aiogram import Bot
from aiogram.types import FSInputFile, InputMediaPhoto

from app.core.logging_config import get_logger

log = get_logger("publisher.telegram")


class TelegramPublisher:
    def __init__(self, bot: Bot, channel_id: int):
        self.bot = bot
        self.channel_id = channel_id

    async def send_card(self, image_path: str, caption: str) -> int:
        msg = await self.bot.send_photo(
            chat_id=self.channel_id,
            photo=FSInputFile(image_path),
            caption=caption,
            parse_mode="HTML",
        )
        return msg.message_id

    async def edit_card(self, message_id: int, image_path: str, caption: str) -> bool:
        try:
            await self.bot.edit_message_media(
                chat_id=self.channel_id,
                message_id=message_id,
                media=InputMediaPhoto(
                    media=FSInputFile(image_path), caption=caption, parse_mode="HTML"
                ),
            )
            return True
        except Exception as e:  # noqa: BLE001
            log.warning("edit_message_media failed (%s); sending new card", e)
            return False

    async def delete_message(self, message_id: int) -> bool:
        try:
            await self.bot.delete_message(self.channel_id, message_id)
            return True
        except Exception as e:  # noqa: BLE001
            log.warning("delete_message failed: %s", e)
            return False

    async def check_channel(self) -> bool:
        """Verify the bot can access and post to the channel."""
        try:
            me = await self.bot.get_me()
            member = await self.bot.get_chat_member(self.channel_id, me.id)
            status = getattr(member, "status", "")
            can_post = getattr(member, "can_post_messages", None)
            ok = status in ("administrator", "creator") and (can_post is None or can_post)
            log.info("Channel check: status=%s can_post=%s -> %s", status, can_post, ok)
            return ok
        except Exception as e:  # noqa: BLE001
            log.error("Channel permission check failed: %s", e)
            return False
