"""CardRenderer — draws dynamic values into the empty boxes of master PNG templates.

Rules honoured:
- Master template is used at its native resolution; the image is NEVER resized
  after text is drawn (source == the file sent to Telegram / shown in preview).
- Only VALUE text is drawn. Labels/icons/panels are part of the master.
- Every field has an internal safe-area padding; text is auto-fit (width & height)
  and centred inside its box. No black debug plates unless a field explicitly
  requests `cover` (legacy templates that ship with baked placeholder text).
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict

from PIL import Image, ImageDraw

from app.cards.autofit import fit_font, wrap_text
from app.cards.manifest import Field, Template, load_manifest
from app.cards.registry import CARD_MAP
from app.core.logging_config import get_logger

log = get_logger("cards.renderer")

FONT_BOLD = str(Path(__file__).resolve().parents[2] / "assets" / "fonts" / "DejaVuSans-Bold.ttf")
OUTPUT_DIR = Path(__file__).resolve().parents[2] / "runtime" / "generated"

PAD_X = 12   # horizontal safe-area padding inside each value box
PAD_Y = 6    # vertical safe-area padding


class CardRenderer:
    def __init__(self):
        self.templates: Dict[str, Template] = load_manifest()
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # --- legacy: sample the box background to cover baked placeholder text ---
    def _sample_bg(self, img: Image.Image, f: Field):
        from collections import Counter
        counts: Counter = Counter()
        step_x = max(2, f.w // 24)
        step_y = max(2, f.h // 10)
        for px in range(f.x + 2, f.x + f.w - 2, step_x):
            for py in range(f.y + 2, f.y + f.h - 2, step_y):
                if 0 <= px < img.width and 0 <= py < img.height:
                    r, g, b = img.getpixel((px, py))[:3]
                    if r + g + b < 24:
                        continue
                    counts[(r // 6 * 6, g // 6 * 6, b // 6 * 6)] += 1
        if not counts:
            return (10, 18, 20)
        return counts.most_common(1)[0][0]

    def _draw_field(self, img: Image.Image, draw: ImageDraw.ImageDraw, f: Field, value: str):
        if f.cover:
            bg = self._sample_bg(img, f)
            draw.rectangle([f.x - 6, f.y - 4, f.x + f.w + 10, f.y + f.h + 6], fill=bg)

        usable_w = max(10, f.w - 2 * PAD_X)
        usable_h = max(10, f.h - 2 * PAD_Y)

        if f.wrap:
            font = fit_font(FONT_BOLD, "M" * 14, usable_w, f.size, f.min)
            lines = wrap_text(font, value, usable_w)
            line_h = f.size + 6
            ty = f.y + PAD_Y
            for line in lines[:4]:
                draw.text((f.x + PAD_X, ty), line, font=font, fill=f.color)
                ty += line_h
            return

        font = fit_font(FONT_BOLD, value, usable_w, f.size, f.min, usable_h)
        cy = f.y + f.h / 2
        if f.align == "center":
            draw.text((f.x + f.w / 2, cy), value, font=font, fill=f.color, anchor="mm")
        else:
            draw.text((f.x + PAD_X, cy), value, font=font, fill=f.color, anchor="lm")

    def render(self, card: str, data: Dict[str, object]) -> str:
        template_key = CARD_MAP.get(card, card)
        tpl = self.templates.get(template_key)
        if not tpl:
            raise KeyError(f"Unknown card/template: {card}")

        img = Image.open(tpl.path).convert("RGB")
        draw = ImageDraw.Draw(img)

        for f in tpl.fields:
            if f.name in data and data[f.name] is not None:
                self._draw_field(img, draw, f, str(data[f.name]))

        out = OUTPUT_DIR / f"{card}_{abs(hash(str(sorted(data.items())))) % 10_000_000}.png"
        img.save(out, "PNG")   # native resolution, no downscale
        return str(out)


_renderer: CardRenderer | None = None


def get_renderer() -> CardRenderer:
    global _renderer
    if _renderer is None:
        _renderer = CardRenderer()
    return _renderer
