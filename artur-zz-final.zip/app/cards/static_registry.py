"""StaticCardRegistry — send ready-made PNG cards to Telegram, cache file_id.

- Never renders text into images (static assets only).
- First send uploads the PNG once; the returned file_id is cached in the DB and
  reused on every subsequent send (survives restarts).
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

from aiogram import Bot
from aiogram.types import FSInputFile, Message

from app.core.logging_config import get_logger
from app.database.repositories.repos import CardAssetRepository
from app.database.session import get_session

log = get_logger("cards.static")

CARDS_DIR = Path(__file__).resolve().parents[2] / "assets" / "cards"

# card_type -> filename
CARD_FILES: Dict[str, str] = {
    "ENGINE_STARTED": "01_engine_started.png",
    "SEARCH": "02_search_signal_v2.png",
    "ANALYSIS": "03_analysis_signal.png",
    "BUY": "04_signal_buy.png",
    "SELL": "05_signal_sell.png",
    "REENTRY": "06_reentry.png",
    "WIN": "07_result_win.png",
    "LOSS": "08_result_loss.png",
    "SKIPPED": "09_signal_skipped.png",
    "STATISTICS": "10_statistics.png",
    "PLATFORM": "11_platform_settings.png",
    "MODE_SWITCH": "12_mode_switch.png",
    "TIME_SWITCH": "13_time_switch.png",
    "PREPARE": "14_prepare_trading.png",
}


class StaticCardRegistry:
    def __init__(self, bot: Bot, channel_id: int):
        self.bot = bot
        self.channel_id = channel_id

    def path(self, card_type: str) -> Path:
        return CARDS_DIR / CARD_FILES[card_type]

    async def _cached_file_id(self, card_type: str) -> Optional[str]:
        async with get_session() as s:
            row = await CardAssetRepository(s).get(card_type)
            # a replaced PNG (new filename) invalidates the cached Telegram file_id
            if row and row.local_filename == CARD_FILES[card_type]:
                return row.telegram_file_id
            return None

    async def _save_file_id(self, card_type: str, msg: Message) -> None:
        photo = msg.photo[-1]
        async with get_session() as s:
            await CardAssetRepository(s).upsert(
                card_type, CARD_FILES[card_type], photo.file_id, photo.file_unique_id)
            await s.commit()

    async def send(self, chat_id: int, card_type: str, caption: str) -> Optional[int]:
        """Send a card to `chat_id` (cached file_id if available, else upload)."""
        fid = await self._cached_file_id(card_type)
        if fid:
            try:
                msg = await self.bot.send_photo(chat_id, fid, caption=caption,
                                                parse_mode="HTML")
                return msg.message_id
            except Exception as e:  # noqa: BLE001
                log.warning("cached file_id failed for %s (%s); re-uploading", card_type, e)
        # upload from disk and cache
        msg = await self.bot.send_photo(
            chat_id, FSInputFile(self.path(card_type)), caption=caption, parse_mode="HTML")
        await self._save_file_id(card_type, msg)
        return msg.message_id

    async def register_all(self, storage_chat_id: int) -> dict:
        """Populate file_id cache by uploading each missing card to a private
        chat, then deleting the temp message. Leaves no channel post."""
        result = {}
        for card_type in CARD_FILES:
            if await self._cached_file_id(card_type):
                result[card_type] = "cached"
                continue
            try:
                msg = await self.bot.send_photo(
                    storage_chat_id, FSInputFile(self.path(card_type)))
                await self._save_file_id(card_type, msg)
                try:
                    await self.bot.delete_message(storage_chat_id, msg.message_id)
                except Exception:  # noqa: BLE001
                    pass
                result[card_type] = "registered"
            except Exception as e:  # noqa: BLE001
                result[card_type] = f"error: {e}"
        return result

    async def replace(self, storage_chat_id: int, card_type: str) -> str:
        """Force re-upload of one card (after replacing the local PNG)."""
        card_type = card_type.upper()
        if card_type not in CARD_FILES:
            return f"unknown card_type: {card_type}"
        msg = await self.bot.send_photo(storage_chat_id, FSInputFile(self.path(card_type)))
        await self._save_file_id(card_type, msg)
        try:
            await self.bot.delete_message(storage_chat_id, msg.message_id)
        except Exception:  # noqa: BLE001
            pass
        return f"{card_type} re-registered"

    async def status(self) -> Dict[str, bool]:
        async with get_session() as s:
            rows = {r.card_type: bool(r.telegram_file_id)
                    for r in await CardAssetRepository(s).all()}
        return {ct: rows.get(ct, False) for ct in CARD_FILES}
