"""Maps logical card states to template names (each state = its own master)."""
from __future__ import annotations

CARD_MAP = {
    "engine_started": "search_signal",
    "search_signal": "search_signal",
    "analysis": "search_signal",
    "wait_confirmation": "wait_confirmation",
    "entry_countdown": "entry_countdown",
    "reentry": "reentry",
    "stats": "stats",
    "market_offline": "signal_skipped",
    "signal_skipped": "signal_skipped",
    "signal_cancelled": "signal_skipped",
    "signal_buy": "signal_buy",
    "signal_sell": "signal_sell",
    "result_win": "result_win",
    "result_loss": "result_loss",
    "draw": "result_draw",
}
