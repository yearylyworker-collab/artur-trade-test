"""Text auto-fit helpers (fit by width AND height with safe padding)."""
from __future__ import annotations

from typing import List

from PIL import ImageFont


def fit_font(font_path: str, text: str, max_w: int, size: int, min_size: int,
             max_h: int | None = None):
    """Shrink font until `text` fits max_w (and max_h if given) or min_size reached."""
    s = size
    while s > min_size:
        font = ImageFont.truetype(font_path, s)
        bbox = font.getbbox(text)
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]
        if w <= max_w and (max_h is None or h <= max_h):
            return font
        s -= 1
    return ImageFont.truetype(font_path, min_size)


def wrap_text(font, text: str, max_w: int) -> List[str]:
    words = text.split()
    lines: List[str] = []
    cur = ""
    for w in words:
        trial = f"{cur} {w}".strip()
        if font.getlength(trial) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines
