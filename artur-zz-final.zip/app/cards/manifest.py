"""Template manifest loader."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import yaml

MANIFEST_PATH = Path(__file__).resolve().parents[2] / "config" / "templates.yaml"
TEMPLATES_DIR = Path(__file__).resolve().parents[2] / "assets" / "templates"


@dataclass
class Field:
    name: str
    x: int
    y: int
    w: int
    h: int
    size: int
    min: int
    color: str
    align: str = "left"
    cover: bool = False
    wrap: bool = False


@dataclass
class Template:
    name: str
    file: str
    fields: List[Field]
    action_overlay: str | None = None
    result_overlay: str | None = None

    @property
    def path(self) -> Path:
        return TEMPLATES_DIR / self.file


def load_manifest() -> Dict[str, Template]:
    data = yaml.safe_load(MANIFEST_PATH.read_text(encoding="utf-8"))
    out: Dict[str, Template] = {}
    for name, spec in data["templates"].items():
        fields = [
            Field(name=fname, **fspec) for fname, fspec in spec.get("fields", {}).items()
        ]
        out[name] = Template(
            name=name,
            file=spec["file"],
            fields=fields,
            action_overlay=spec.get("action_overlay"),
            result_overlay=spec.get("result_overlay"),
        )
    return out
