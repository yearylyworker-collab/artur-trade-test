"""Feature vector for the ML meta-label filter.

Features are computed at SIGNAL TIME only and stored in ``signals.audit``
(key ``ml_features``), so training uses exactly what the filter saw — no
look-ahead.

Differences from the original spec, on purpose:
* "attempt inside the window (1-5)" is NOT a feature: at decision time it is
  always 1, so it carries no information and would only leak outcome data
  collected later in the window.
* ATR is normalised by price (ATR %) so different assets are comparable.
"""
from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from app.analysis.regime import REGIME_CODE
from app.config import settings
from app.core.models import AnalysisResult


def feature_names() -> List[str]:
    base = ["ha_color", "body_atr", "upper_wick_pct", "lower_wick_pct", "rsi",
            "atr_pct", "ema_slope_atr", "regime", "hour", "rolling_wr"]
    if settings.otc_auto:  # dynamic asset list -> no one-hot (would change the feature set)
        return base
    return base + [f"asset_{a}" for a in settings.otc_assets]


def build_features(a: AnalysisResult, rolling_wr: Optional[float],
                   now: datetime) -> Dict[str, float]:
    ind = a.indicators or {}
    ha = a.ha_snapshot or {}
    atr = ind.get("atr") or 0.0
    body = float(ha.get("body_size") or 0.0)
    up = float(ha.get("upper_wick") or 0.0)
    lo = float(ha.get("lower_wick") or 0.0)

    def pct(x: float) -> float:
        return (x / body * 100.0) if body > 0 else 0.0

    slope = 0.0
    if atr and ind.get("ema_medium") is not None and ind.get("ema_slow") is not None:
        slope = (ind["ema_medium"] - ind["ema_slow"]) / atr
    feats = {
        "ha_color": 1.0 if ha.get("ha_direction") == "BULLISH" else 0.0,
        "body_atr": (body / atr) if atr else 0.0,
        "upper_wick_pct": pct(up),
        "lower_wick_pct": pct(lo),
        "rsi": float(ind.get("rsi") or 50.0),
        "atr_pct": float(ind.get("atr_pct") or 0.0) * 100.0,
        "ema_slope_atr": slope,
        "regime": float(REGIME_CODE.get(a.regime or "", 2)),
        "hour": float(now.hour),
        "rolling_wr": float(rolling_wr if rolling_wr is not None else 50.0),
    }
    if not settings.otc_auto:
        for asset in settings.otc_assets:
            feats[f"asset_{asset}"] = 1.0 if a.symbol == asset else 0.0
    return feats


def to_row(feats: Dict[str, float], names: List[str]) -> List[float]:
    return [float(feats.get(n, 0.0)) for n in names]
