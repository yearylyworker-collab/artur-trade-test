"""XGBoost meta-labeling filter.

It does NOT predict direction. Given a signal that already passed every HA /
EMA / RSI / MACD rule, it estimates P(WIN of the entry) and the signal is sent
only if P > ML_PROB_THRESHOLD (0.65).

Files (written by scripts/train_ml.py, stored on the Railway volume):
    runtime/ml/model.json     — native XGBoost format (safe to load, unlike pickle)
    runtime/ml/features.json  — ordered feature list + training report

Safety rules — in every case below predict() returns None and the bot works
by rules only:
    * no model / features file, or xgboost not installed;
    * model trained on fewer than ML_MIN_SAMPLES rows;
    * a feature the model expects is missing from the input;
    * any exception while predicting.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional

from app.config import settings
from app.core.logging_config import get_logger

log = get_logger("ml.filter")


def model_path() -> Path:
    return Path(settings.ml_model_path)


def features_path() -> Path:
    return model_path().with_name("features.json")


class MLFilter:
    def __init__(self):
        self._booster = None
        self.features: List[str] = []
        self.meta: dict = {}
        self.active = False
        self.info = "not loaded"

    # ------------------------------------------------------------------ load --
    def load(self) -> None:
        self._booster, self.active, self.features, self.meta = None, False, [], {}
        if not settings.ml_enabled:
            self.info = "disabled (ML_ENABLED=false)"
            return
        mp, fp = model_path(), features_path()
        if not mp.exists() or not fp.exists():
            self.info = "no model yet — rules only"
            log.info("ML filter: %s", self.info)
            return
        try:
            meta = json.loads(fp.read_text())
            n = int(meta.get("n_samples", 0))
            if n < settings.ml_min_samples:
                self.info = f"model trained on {n} < {settings.ml_min_samples} samples — rules only"
                log.warning("ML filter: %s", self.info)
                return
            import xgboost as xgb
            booster = xgb.Booster()
            booster.load_model(str(mp))
            self._booster = booster
            self.features = list(meta["features"])
            self.meta = meta
            self.active = True
            cv = meta.get("cv", {})
            self.info = (f"active: {n} samples, purged CV winrate "
                         f"{cv.get('base_wr')}% -> {cv.get('kept_wr')}% (kept {cv.get('kept_share')}%)")
            log.info("ML filter %s", self.info)
        except Exception as e:  # noqa: BLE001
            self.info = f"load failed: {e} — rules only"
            log.error("ML filter %s", self.info)

    # --------------------------------------------------------------- predict --
    def predict(self, feats: Dict[str, float]) -> Optional[float]:
        """Probability of WIN, or None when the filter cannot decide."""
        if not self.active or self._booster is None:
            return None
        missing = [f for f in self.features if f not in feats]
        if missing:
            log.error("ML: %d features missing (%s…) — passing by rules",
                      len(missing), ", ".join(missing[:3]))
            return None
        try:
            import xgboost as xgb
            row = [[float(feats[f]) for f in self.features]]
            dm = xgb.DMatrix(row, feature_names=self.features)
            return float(self._booster.predict(dm)[0])
        except Exception as e:  # noqa: BLE001
            log.error("ML predict failed, passing by rules: %s", e)
            return None

    def allows(self, prob: Optional[float]) -> bool:
        return prob is None or prob >= settings.ml_prob_threshold

    # ----------------------------------------------------------------- train --
    async def train(self, mode: str) -> str:
        """Train from the bot's DB (same as `python -m scripts.train_ml`), then reload."""
        from scripts.train_ml import train
        report = await train(mode)
        self.load()
        return report


ml_filter = MLFilter()
