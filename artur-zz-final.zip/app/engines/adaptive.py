"""AdaptiveEngine — picks timeframe (S30/M1/M5), entry second and window length.

Data: shadow windows (app.analytics.shadow) — the same HA/EMA/RSI analysis,
played on real quotes for every timeframe but never published — plus
TimingAnalyzer rows for entry seconds. HA/EMA/RSI logic is not touched.

Ranking uses the honest expected result per window with a FIXED stake on every
entry (WIN on entry k = payout − (k−1) stakes, full loss = −L stakes), so a
longer window is chosen only if it really pays, not just because "+1" becomes
more frequent. The winrate shown in the channel is the window winrate.

Switch rules (ТЗ):
  * the new mode is better by ADAPTIVE_IMPROVEMENT_THRESHOLD (5 pp winrate
    or 0.05 stake EV per window);
  * not more often than ADAPTIVE_SWITCH_COOLDOWN (1 h), counted from start-up;
  * the new mode has ADAPTIVE_MIN_SAMPLES (30) windows.
Warning card "СМЕНА РЕЖИМА" goes out ADAPTIVE_WARNING_LEAD seconds before.
"""
from __future__ import annotations

import asyncio
import time
from datetime import timedelta
from typing import Dict, Optional

from app.analytics.shadow import window_stats
from app.analytics.timing import timing
from app.config import settings
from app.core.logging_config import get_logger
from app.core.time_utils import utc_now
from app.services import runtime

log = get_logger("engines.adaptive")


async def _to_main(card: str, caption: str) -> None:
    """Same warning in the main channel, but only during its active hours."""
    from app.services import main_channel
    from app.services.state import state as st
    if not (main_channel.enabled() and main_channel.in_hours() and st.cards):
        return
    try:
        await st.cards.send(settings.main_channel_id, card, caption)
    except Exception as e:  # noqa: BLE001
        log.warning("main channel switch card failed: %s", e)


class AdaptiveEngine:
    def __init__(self, state):
        self.state = state
        self.last_switch = time.monotonic()   # cooldown starts at boot
        self.last_report: Dict = {}
        self.pending: Optional[dict] = None
        self.duration_pending: Optional[dict] = None
        self._task: Optional[asyncio.Task] = None

    # ------------------------------------------------------------ analysis --
    def _payout(self) -> float:
        pays = [p for p in (getattr(self.state.provider, "payouts", {}) or {}).values() if p]
        if pays:
            pays = sorted(pays, reverse=True)[:20]
            return sum(pays) / len(pays) / 100
        return settings.payout_percent / 100

    def analyze(self) -> dict:
        payout = self._payout()
        lengths = [n for n in settings.window_lengths if 1 <= n <= 5] or [settings.max_attempts]
        per_tf = {}
        for tf in runtime.provider_timeframes():
            rows = timing.windows(tf, settings.adaptive_lookback)
            by_len = {n: window_stats(rows, n, payout) for n in lengths}
            best_n = max(by_len, key=lambda n: (by_len[n]["ev"], -n))
            last20 = window_stats(rows[:20], best_n, payout)
            per_tf[tf] = {"by_len": by_len, "best_len": best_n, **by_len[best_n],
                          "winrate_20": last20["winrate"]}
        report = {"payout": payout, "timeframes": per_tf, "at": utc_now().isoformat()}
        report["best_second"] = timing.get_best_entry_second() if settings.entry_second_auto else None
        self.last_report = report
        return report

    def get_best_timeframe(self) -> str:
        tfs = {k: v for k, v in self.last_report.get("timeframes", {}).items()
               if v["samples"] >= settings.adaptive_min_samples}
        if not tfs:
            return settings.default_timeframe
        return max(tfs, key=lambda k: tfs[k]["ev"])

    def get_optimal_window_length(self, tf: Optional[str] = None) -> int:
        info = self.last_report.get("timeframes", {}).get(tf or self.get_best_timeframe())
        return info["best_len"] if info and info["samples"] >= settings.adaptive_min_samples \
            else settings.max_attempts

    def get_best_entry_second(self) -> int:
        best = self.last_report.get("best_second")
        if not settings.entry_second_auto or not best:
            return settings.entry_second
        second, wr, _n = best
        cur = next((r for r in timing.stats("entry_second", source=None)
                    if r[0] == settings.entry_second), None)
        if cur is None or wr - cur[1] >= settings.adaptive_improvement_threshold:
            return int(second)
        return settings.entry_second

    def _current_stats(self) -> Optional[dict]:
        info = self.last_report.get("timeframes", {}).get(settings.default_timeframe)
        if not info:
            return None
        return info["by_len"].get(settings.max_attempts) or info

    def proposal(self) -> Optional[dict]:
        """New parameters + reason, or None when nothing is clearly better."""
        if not self.last_report:
            return None
        tf = self.get_best_timeframe()
        info = self.last_report["timeframes"].get(tf)
        if not info or info["samples"] < settings.adaptive_min_samples:
            return None
        n = self.get_optimal_window_length(tf)
        sec = self.get_best_entry_second()
        cur = runtime.current()
        if tf == cur["timeframe"] and n == cur["window_length"] and sec == cur["entry_second"]:
            return None
        new_stats = info["by_len"][n]
        old_stats = self._current_stats()
        thr = settings.adaptive_improvement_threshold
        if old_stats and old_stats["samples"] >= 5:
            better_wr = new_stats["winrate"] - old_stats["winrate"] >= thr
            better_ev = new_stats["ev"] - old_stats["ev"] >= thr
            if (tf, n) != (cur["timeframe"], cur["window_length"]) and not (better_wr or better_ev):
                if sec == cur["entry_second"]:
                    return None
                tf, n = cur["timeframe"], cur["window_length"]   # only the second changes
            old_txt = (f"{old_stats['winrate'] * 100:.0f}% на {cur['timeframe']} "
                       f"({cur['window_length']} вх.); итог {new_stats['ev']:+.2f} против "
                       f"{old_stats['ev']:+.2f} ставки на окно")
        else:
            old_txt = f"мало данных по {cur['timeframe']}"
        reason = (f"{tf} ({n} вх.) показывает winrate окон {new_stats['winrate'] * 100:.0f}% "
                  f"против {old_txt}; выборка {new_stats['samples']} окон")
        if sec != cur["entry_second"] and tf == cur["timeframe"] and n == cur["window_length"]:
            b = self.last_report.get("best_second")
            reason = (f"вход на :{sec:02d} даёт {b[1] * 100:.0f}% прибыльных сделок "
                      f"({b[2]} замеров)") if b else "лучшая секунда входа по статистике"
        return {"timeframe": tf, "entry_second": sec, "window_length": n, "reason": reason}

    def should_switch(self) -> bool:
        if not settings.adaptive_enabled or self.pending:
            return False
        if time.monotonic() - self.last_switch < settings.adaptive_switch_cooldown:
            return False
        return self.proposal() is not None

    # ------------------------------------------------------------ switching --
    async def schedule_switch(self, prop: dict, lead: Optional[int] = None) -> None:
        from app.publisher import formatter
        lead = settings.adaptive_warning_lead if lead is None else lead
        at = (utc_now() + timedelta(seconds=lead)).replace(microsecond=0)
        at = at.replace(second=0) + timedelta(minutes=1) if at.second else at
        old = runtime.current()
        old["expiry"] = runtime.expiry_for(old["timeframe"])
        new = {"timeframe": prop["timeframe"], "entry_second": prop["entry_second"],
               "window_length": prop["window_length"],
               "expiry": runtime.expiry_for(prop["timeframe"])}
        self.pending = {**prop, "at": at}
        log.info("MODE SWITCH scheduled at %s: %s -> %s (%s)", at.isoformat(), old, new,
                 prop["reason"])
        caption = formatter.mode_switch_caption(old, new, at, prop["reason"])
        st = self.state
        if st.cards and settings.signal_channel_id:
            try:
                await st.cards.send(settings.signal_channel_id, "MODE_SWITCH", caption)
            except Exception as e:  # noqa: BLE001
                log.warning("mode switch card failed: %s", e)
        await _to_main("MODE_SWITCH", caption)
        from app.scheduler.engine_loop import _notify_admins
        await _notify_admins(f"⚠️ Смена режима в {at:%H:%M:%S} UTC: {prop['reason']}")
        self._task = asyncio.create_task(self._apply_at(at))

    async def _apply_at(self, at) -> None:
        try:
            await asyncio.sleep(max(0.0, (at - utc_now()).total_seconds()))
            p = self.pending
            if not p:
                return
            runtime.apply(timeframe=p["timeframe"], entry_second=p["entry_second"],
                          window_length=p["window_length"])
            self.last_switch = time.monotonic()
            log.info("MODE SWITCH applied: %s", runtime.current())
            st = self.state
            if st.cards and settings.signal_channel_id:
                from app.publisher import formatter
                await st.cards.send(settings.signal_channel_id, "PLATFORM",
                                    formatter.platform_caption(settings.default_timeframe,
                                                               settings.default_expiry_seconds))
                from app.services.engine_control import post_howto
                await post_howto(force=True)
        except asyncio.CancelledError:
            pass
        except Exception as e:  # noqa: BLE001
            log.warning("mode switch apply failed: %s", e)
        finally:
            self.pending = None

    async def schedule_duration(self, old: int, new: int, reason: str) -> None:
        """Trade-length change: card in the channel, apply after the warning lead,
        then the updated instruction. Running windows keep their own length."""
        from app.publisher import formatter
        from app.scheduler.engine_loop import _notify_admins
        tf = settings.default_timeframe
        at = (utc_now() + timedelta(seconds=settings.adaptive_warning_lead)).replace(microsecond=0)
        at = at.replace(second=0) + timedelta(minutes=1) if at.second else at
        self.duration_pending = {"old": old, "new": new, "at": at}
        st = self.state
        if st.cards and settings.signal_channel_id:
            try:
                await st.cards.send(settings.signal_channel_id, "TIME_SWITCH",
                                    formatter.duration_switch_caption(old, new, tf, at, reason))
            except Exception as e:  # noqa: BLE001
                log.warning("duration card failed: %s", e)
        await _to_main("TIME_SWITCH", formatter.duration_switch_caption(old, new, tf, at, reason))
        await _notify_admins(f"⏱ Время сделки {old} → {new} сек в {at:%H:%M} UTC. {reason}")
        log.info("DURATION SWITCH scheduled %s -> %s at %s", old, new, at.isoformat())

        async def _apply():
            try:
                await asyncio.sleep(max(0.0, (at - utc_now()).total_seconds()))
                runtime.apply_duration(tf, new, reason)
                from app.services.engine_control import post_howto
                await post_howto(force=True)
            except Exception as e:  # noqa: BLE001
                log.warning("duration apply failed: %s", e)
            finally:
                self.duration_pending = None
        asyncio.create_task(_apply())

    def cancel_pending(self) -> bool:
        if self._task and not self._task.done():
            self._task.cancel()
            self.pending = None
            return True
        return False

    async def tick(self) -> None:
        if not self.state.engine_on:
            return
        if not self.pending and not self.duration_pending:
            prop = await asyncio.to_thread(runtime.choose_duration, None, False)
            if prop:
                await self.schedule_duration(*prop)
        if not settings.adaptive_enabled:
            return
        await asyncio.to_thread(self.analyze)
        if self.should_switch():
            await self.schedule_switch(self.proposal())


async def adaptive_loop(state) -> None:
    engine = AdaptiveEngine(state)
    state.adaptive = engine
    log.info("adaptive loop started (enabled=%s)", settings.adaptive_enabled)
    while True:
        await asyncio.sleep(max(30, settings.adaptive_check_seconds))
        try:
            await engine.tick()
        except Exception as e:  # noqa: BLE001
            log.warning("adaptive tick error: %s", e)
