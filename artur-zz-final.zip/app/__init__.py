"""ARTUR TRADE — Heikin Ashi Signal Engine."""

__version__ = "1.0.0"
