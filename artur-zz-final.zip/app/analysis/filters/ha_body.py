"""HA body strength filter (folded into confirmation / audit)."""
from __future__ import annotations

from typing import List

from app.analysis.filters.common import avg_body
from app.candles.models import HACandle
from app.core.enums import Direction, HADirection
from app.core.models import FilterResult

MAX = 10.0


def evaluate(ha: List[HACandle], direction: Direction) -> FilterResult:
    if not ha:
        return FilterResult("ha_body", False, 0.0, MAX, "no data")
    last = ha[-1]
    avg = avg_body(ha, 10) or 1e-9
    ratio = last.body_size / avg
    want = HADirection.BULLISH if direction == Direction.BUY else HADirection.BEARISH
    strong = last.direction == want and ratio >= 0.8
    score = min(ratio, 1.5) / 1.5 * MAX if last.direction == want else 0.0
    reason = f"body ratio={ratio:.2f} dir={last.direction.value}"
    return FilterResult("ha_body", strong, round(score, 1), MAX, reason)
