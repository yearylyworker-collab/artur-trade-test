"""HA wick rejection filter (folded into confirmation / audit)."""
from __future__ import annotations

from typing import List

from app.candles.models import HACandle
from app.core.enums import Direction
from app.core.models import FilterResult

MAX = 10.0


def evaluate(ha: List[HACandle], direction: Direction) -> FilterResult:
    if not ha:
        return FilterResult("ha_wicks", False, 0.0, MAX, "no data")
    last = ha[-1]
    rng = last.range or 1e-9
    if direction == Direction.BUY:
        adverse = last.upper_wick / rng   # big upper wick = rejection of highs
    else:
        adverse = last.lower_wick / rng
    score = max(0.0, (1.0 - adverse * 2.0)) * MAX
    passed = adverse < 0.45
    reason = f"adverse wick ratio={adverse:.2f}"
    return FilterResult("ha_wicks", passed, round(score, 1), MAX, reason)
