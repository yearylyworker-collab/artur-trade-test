"""Market structure filter (category weight 20) — HH/HL or LH/LL."""
from __future__ import annotations

from typing import List

from app.candles.models import HACandle
from app.core.enums import Direction
from app.core.models import FilterResult

MAX = 20.0


def _swings(ha: List[HACandle], n: int = 12):
    window = ha[-n:] if len(ha) >= n else ha[:]
    highs = [c.ha_high for c in window]
    lows = [c.ha_low for c in window]
    return highs, lows


def evaluate(ha: List[HACandle], direction: Direction) -> FilterResult:
    if len(ha) < 6:
        return FilterResult("structure", False, 0.0, MAX, "insufficient data")
    highs, lows = _swings(ha)
    mid = len(highs) // 2
    recent_high = max(highs[mid:])
    prior_high = max(highs[:mid])
    recent_low = min(lows[mid:])
    prior_low = min(lows[:mid])

    if direction == Direction.BUY:
        hh = recent_high > prior_high
        hl = recent_low > prior_low
        passed = hh and hl
        score = (10.0 if hh else 0.0) + (10.0 if hl else 0.0)
        reason = f"HH={hh} HL={hl}"
    else:
        lh = recent_high < prior_high
        ll = recent_low < prior_low
        passed = lh and ll
        score = (10.0 if lh else 0.0) + (10.0 if ll else 0.0)
        reason = f"LH={lh} LL={ll}"
    return FilterResult("structure", passed, round(score, 1), MAX, reason)
