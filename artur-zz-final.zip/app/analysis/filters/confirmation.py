"""Final confirmation filter (category weight 10)."""
from __future__ import annotations

from typing import Dict

from app.core.models import FilterResult

MAX = 10.0
REQUIRED = ("ha_trend", "momentum", "structure", "volatility", "noise")


def evaluate(results: Dict[str, FilterResult]) -> FilterResult:
    passed_count = sum(1 for k in REQUIRED if results.get(k) and results[k].passed)
    all_pass = passed_count == len(REQUIRED)
    score = (passed_count / len(REQUIRED)) * MAX
    reason = f"{passed_count}/{len(REQUIRED)} core filters passed"
    return FilterResult("confirmation", all_pass, round(score, 1), MAX, reason)
