"""Volatility filter (category weight 15) — ATR-like on raw candles."""
from __future__ import annotations

from typing import List

from app.candles.models import Candle
from app.core.models import FilterResult

MAX = 15.0
MIN_RATIO = 0.15   # too quiet
MAX_RATIO = 3.0    # abnormally volatile (relative to median range)


def evaluate(candles: List[Candle]) -> FilterResult:
    if len(candles) < 15:
        return FilterResult("volatility", False, 0.0, MAX, "insufficient data")
    ranges = [c.high - c.low for c in candles[-20:]]
    ranges_sorted = sorted(ranges)
    median = ranges_sorted[len(ranges_sorted) // 2] or 1e-9
    current = ranges[-1]
    ratio = current / median

    # Dead market: absolute range negligible vs price -> too low.
    price = candles[-1].close or 1.0
    rel = median / price
    if rel < 5e-6:
        return FilterResult("volatility", False, 1.0, MAX, f"dead market rel={rel:.2e}")

    if ratio < MIN_RATIO:
        return FilterResult("volatility", False, 2.0, MAX, f"too low ratio={ratio:.2f}")
    if ratio > MAX_RATIO:
        return FilterResult("volatility", False, 3.0, MAX, f"too high ratio={ratio:.2f}")
    # sweet spot around 0.7-1.6
    score = MAX * (1.0 - min(abs(ratio - 1.1), 1.0))
    return FilterResult("volatility", True, round(max(score, 6.0), 1), MAX, f"ok ratio={ratio:.2f}")
