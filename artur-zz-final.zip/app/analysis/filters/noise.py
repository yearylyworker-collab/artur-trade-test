"""Noise / chop filter (category weight 10)."""
from __future__ import annotations

from typing import List

from app.analysis.filters.common import avg_body, recent
from app.candles.models import HACandle
from app.core.enums import HADirection
from app.core.models import FilterResult

MAX = 10.0


def evaluate(ha: List[HACandle]) -> FilterResult:
    window = recent(ha, 8)
    if len(window) < 5:
        return FilterResult("noise", False, 0.0, MAX, "insufficient data")

    # direction flips = chop
    flips = 0
    for a, b in zip(window, window[1:]):
        if a.direction != b.direction and HADirection.NEUTRAL not in (a.direction, b.direction):
            flips += 1
    neutrals = sum(1 for c in window if c.direction == HADirection.NEUTRAL)

    avg = avg_body(ha, 10) or 1e-9
    small_bodies = sum(1 for c in window if c.body_size < avg * 0.4)

    noise_level = flips + neutrals + small_bodies * 0.5
    passed = flips <= 2 and neutrals <= 2
    score = max(0.0, MAX - noise_level * 1.5)
    reason = f"flips={flips} neutrals={neutrals} small={small_bodies}"
    return FilterResult("noise", passed, round(min(score, MAX), 1), MAX, reason)
