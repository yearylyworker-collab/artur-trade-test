"""Direction gate: triple EMA stack + RSI + MACD, plus ATR flat guard.

This is a HARD filter added on top of the existing Heikin Ashi filters
(it does not replace them and does not change their score):

* CALL (BUY):  EMA_fast > EMA_medium > EMA_slow, RSI > RSI_CALL,
               MACD line > 0 and not below its signal line
* PUT  (SELL): EMA_fast < EMA_medium < EMA_slow, RSI < RSI_PUT,
               MACD line < 0 and not above its signal line
* ATR / price below ATR_MIN_PCT -> flat market, no signal.

All thresholds come from settings (env). Computed on raw (not HA) closes.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from app.candles.models import Candle
from app.config import settings
from app.core.enums import Direction
from app.core.models import FilterResult
from app.indicators import ta


def indicator_snapshot(candles: List[Candle]) -> Dict[str, Optional[float]]:
    """Latest indicator values (None where history is too short)."""
    closes = [c.close for c in candles]
    highs = [c.high for c in candles]
    lows = [c.low for c in candles]
    ef = ta.last(ta.ema(closes, settings.ema_fast))
    em = ta.last(ta.ema(closes, settings.ema_medium))
    es = ta.last(ta.ema(closes, settings.ema_slow))
    r = ta.last(ta.rsi(closes, settings.rsi_period))
    line, _sig, hist = ta.macd(closes, settings.macd_fast, settings.macd_slow,
                                settings.macd_signal)
    a = ta.last(ta.atr(highs, lows, closes, settings.atr_period))
    price = closes[-1] if closes else None
    return {
        "ema_fast": ef, "ema_medium": em, "ema_slow": es,
        "rsi": r, "macd": ta.last(line), "macd_hist": ta.last(hist), "atr": a, "price": price,
        "atr_pct": (a / price) if (a is not None and price) else None,
    }


def evaluate(candles: List[Candle], direction: Direction,
             snap: Optional[Dict[str, Optional[float]]] = None) -> FilterResult:
    snap = snap or indicator_snapshot(candles)
    needed = ("ema_fast", "ema_medium", "ema_slow", "rsi", "macd", "macd_hist", "atr_pct")
    if any(snap.get(k) is None for k in needed):
        return FilterResult("ema_rsi_macd", False, 0.0, 1.0, "insufficient history")

    if snap["atr_pct"] < settings.atr_min_pct:
        return FilterResult("ema_rsi_macd", False, 0.0, 1.0,
                            f"flat: atr_pct={snap['atr_pct']:.6f}")

    ef, em, es = snap["ema_fast"], snap["ema_medium"], snap["ema_slow"]
    r, m, h = snap["rsi"], snap["macd"], snap["macd_hist"]
    eps = 1e-12  # float noise around a flat histogram
    if direction == Direction.BUY:
        checks = {"ema": ef > em > es, "rsi": r > settings.rsi_call, "macd": m > 0 and h >= -eps}
    else:
        checks = {"ema": ef < em < es, "rsi": r < settings.rsi_put, "macd": m < 0 and h <= eps}

    passed = all(checks.values())
    failed = [k for k, ok in checks.items() if not ok]
    reason = "ok" if passed else "fail: " + ",".join(failed)
    return FilterResult("ema_rsi_macd", passed, 1.0 if passed else 0.0, 1.0,
                        f"{reason} rsi={r:.1f}")
