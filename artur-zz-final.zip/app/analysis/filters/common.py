"""Shared statistics helpers for filters."""
from __future__ import annotations

from statistics import mean
from typing import List

from app.candles.models import HACandle
from app.core.enums import HADirection


def recent(ha: List[HACandle], n: int) -> List[HACandle]:
    return ha[-n:] if len(ha) >= n else ha[:]


def consecutive_dir(ha: List[HACandle], direction: HADirection) -> int:
    """Count trailing consecutive HA candles of a direction."""
    count = 0
    for c in reversed(ha):
        if c.direction == direction:
            count += 1
        else:
            break
    return count


def dominant_direction(ha: List[HACandle], n: int = 5):
    window = recent(ha, n)
    bulls = sum(1 for c in window if c.direction == HADirection.BULLISH)
    bears = sum(1 for c in window if c.direction == HADirection.BEARISH)
    if bulls > bears and bulls >= max(2, len(window) // 2):
        return HADirection.BULLISH
    if bears > bulls and bears >= max(2, len(window) // 2):
        return HADirection.BEARISH
    return HADirection.NEUTRAL


def avg_body(ha: List[HACandle], n: int = 10) -> float:
    window = recent(ha, n)
    return mean([c.body_size for c in window]) if window else 0.0
