"""HA trend / sequence filter (category weight 25)."""
from __future__ import annotations

from typing import List

from app.analysis.filters.common import consecutive_dir, dominant_direction, recent
from app.candles.models import HACandle
from app.core.enums import Direction, HADirection
from app.core.models import FilterResult

MAX = 25.0


def evaluate(ha: List[HACandle], direction: Direction) -> FilterResult:
    want = HADirection.BULLISH if direction == Direction.BUY else HADirection.BEARISH
    consec = consecutive_dir(ha, want)
    window = recent(ha, 5)
    aligned = sum(1 for c in window if c.direction == want)

    # sequence quality: need >=2 consecutive, reward up to 4
    seq_score = min(consec, 4) / 4 * 16.0
    align_score = (aligned / max(1, len(window))) * 9.0
    score = seq_score + align_score
    passed = consec >= 2 and dominant_direction(ha, 5) == want
    reason = f"HA {want.value.lower()} seq={consec} aligned={aligned}/{len(window)}"
    return FilterResult("ha_trend", passed, round(score, 1), MAX, reason)
