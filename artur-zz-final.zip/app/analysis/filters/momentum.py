"""Momentum filter (category weight 20)."""
from __future__ import annotations

from typing import List

from app.analysis.filters.common import recent
from app.candles.models import HACandle
from app.core.enums import Direction
from app.core.models import FilterResult

MAX = 20.0


def evaluate(ha: List[HACandle], direction: Direction) -> FilterResult:
    window = recent(ha, 6)
    if len(window) < 3:
        return FilterResult("momentum", False, 0.0, MAX, "insufficient data")

    # price delta over the window (ha_close)
    delta = window[-1].ha_close - window[0].ha_close
    # body momentum: are recent bodies growing?
    first_half = window[: len(window) // 2]
    second_half = window[len(window) // 2:]
    body_growth = (
        (sum(c.body_size for c in second_half) / len(second_half))
        - (sum(c.body_size for c in first_half) / len(first_half))
    )
    span = sum(c.range for c in window) / len(window) or 1e-9
    dir_ok = (delta > 0) if direction == Direction.BUY else (delta < 0)

    delta_score = min(abs(delta) / (span * 3), 1.0) * 12.0 if dir_ok else 0.0
    growth_score = 8.0 if body_growth >= 0 else 3.0
    score = delta_score + (growth_score if dir_ok else 0.0)
    passed = dir_ok and score >= 8.0
    reason = f"delta={delta:.5f} growth={body_growth:.5f} dir_ok={dir_ok}"
    return FilterResult("momentum", passed, round(score, 1), MAX, reason)
