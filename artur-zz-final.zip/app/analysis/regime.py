"""Market regime detector: TREND / RANGE / VOLATILE.

Rules (thresholds in settings):

* RANGE    — HA colour changed >= 2 times within the last 3 candles, OR
             Bollinger width < ATR * REGIME_BB_SQUEEZE_ATR (squeeze).
             Signals are FORBIDDEN in RANGE.
* VOLATILE — ATR > mean ATR of the last 50 candles * 1.3, OR
             last HA body > ATR * ATR_MULTIPLIER.
* TREND    — EMA(20) slope over 3 candles >= ATR * REGIME_TREND_SLOPE_ATR AND
             the last 2 HA candles are one colour without the opposite wick.
* Nothing matched -> NEUTRAL (not blocked; the other filters decide).
"""
from __future__ import annotations

from statistics import mean
from typing import List

from app.candles.models import Candle, HACandle
from app.config import settings
from app.core.enums import HADirection
from app.indicators import ta

TREND = "TREND"
RANGE = "RANGE"
VOLATILE = "VOLATILE"
NEUTRAL = "NEUTRAL"

# numeric encoding for the ML feature "market regime"
REGIME_CODE = {TREND: 0, VOLATILE: 1, RANGE: 2, NEUTRAL: 3}


def _color_flips(ha: List[HACandle], n: int = 3) -> int:
    window = ha[-n:]
    return sum(1 for a, b in zip(window, window[1:]) if a.direction != b.direction)


def _clean_ha_run(ha: List[HACandle], n: int = 2) -> bool:
    """Last n HA candles same colour, no wick against the move."""
    window = ha[-n:]
    if len(window) < n:
        return False
    d = window[0].direction
    if d == HADirection.NEUTRAL or any(c.direction != d for c in window):
        return False
    eps = 1e-12
    if d == HADirection.BULLISH:
        return all(c.lower_wick <= eps for c in window)
    return all(c.upper_wick <= eps for c in window)


class MarketRegime:
    def check(self, asset: str, candles: List[Candle], ha: List[HACandle]) -> str:
        closes = [c.close for c in candles]
        highs = [c.high for c in candles]
        lows = [c.low for c in candles]
        atr_s = ta.atr(highs, lows, closes, settings.atr_period)
        atr_now = ta.last(atr_s)
        if atr_now is None or len(ha) < 3:
            return RANGE

        # --- RANGE ---
        lo, _mid, up = ta.bollinger(closes, settings.bb_period, settings.bb_std)
        bb_width = (up[-1] - lo[-1]) if (up and up[-1] is not None) else None
        squeeze = bb_width is not None and bb_width < atr_now * settings.regime_bb_squeeze_atr
        if _color_flips(ha, 3) >= 2 or squeeze:
            return RANGE

        # --- VOLATILE ---
        hist = [a for a in atr_s[-settings.regime_volatile_lookback:] if a is not None]
        atr_avg = mean(hist) if hist else atr_now
        if atr_now > atr_avg * settings.regime_volatile_atr_ratio \
                or ha[-1].body_size > atr_now * settings.atr_multiplier:
            return VOLATILE

        # --- TREND ---
        e20 = ta.ema(closes, settings.regime_trend_ema)
        if len(e20) >= 4 and e20[-1] is not None and e20[-4] is not None:
            slope = abs(e20[-1] - e20[-4])
            if slope >= atr_now * settings.regime_trend_slope_atr and _clean_ha_run(ha, 2):
                return TREND

        return NEUTRAL
