"""SignalEngine analysis: evaluate a symbol and pick the best candidate."""
from __future__ import annotations

from typing import Dict, List, Optional

from app.analysis.filters import (
    confirmation, ha_body, ha_trend, ha_wicks, momentum, noise, structure,
)
from app.analysis.filters.common import dominant_direction
from app.analysis.scoring import total_score
from app.analysis.filters import volatility as volatility_f
from app.analysis.filters import ema_rsi_macd
from app.analysis.regime import RANGE, MarketRegime
from app.config import settings
from app.candles.models import Candle, HACandle
from app.core.enums import Direction, HADirection
from app.core.logging_config import get_logger
from app.core.models import AnalysisResult, FilterResult

log = get_logger("analysis.engine")


class AnalysisEngine:
    def __init__(self, min_score: float = 75.0):
        self.min_score = min_score
        self.regime = MarketRegime()

    def analyze_symbol(self, symbol: str, candles: List[Candle], ha: List[HACandle]) -> AnalysisResult:
        if len(ha) < 20:
            return AnalysisResult(symbol, None, 0.0, False, [], "insufficient history")

        dom = dominant_direction(ha, 5)
        if dom == HADirection.NEUTRAL:
            return AnalysisResult(symbol, None, 0.0, False, [], "flat / no dominant trend",
                                  candle_timestamp=candles[-1].timestamp if candles else None)

        direction = Direction.BUY if dom == HADirection.BULLISH else Direction.SELL

        results: Dict[str, FilterResult] = {}
        results["ha_trend"] = ha_trend.evaluate(ha, direction)
        results["ha_body"] = ha_body.evaluate(ha, direction)
        results["ha_wicks"] = ha_wicks.evaluate(ha, direction)
        results["momentum"] = momentum.evaluate(ha, direction)
        results["volatility"] = volatility_f.evaluate(candles)
        results["structure"] = structure.evaluate(ha, direction)
        results["noise"] = noise.evaluate(ha)
        results["confirmation"] = confirmation.evaluate(results)

        score = total_score(results)
        # A valid signal needs confirmation + hard filters (volatility, noise) to pass.
        passed = (
            score >= self.min_score
            and results["confirmation"].passed
            and results["volatility"].passed
            and results["noise"].passed
        )

        # Engine 2 additions (do not alter the HA score): EMA/RSI/MACD gate + regime.
        snap = ema_rsi_macd.indicator_snapshot(candles)
        emr = ema_rsi_macd.evaluate(candles, direction, snap)
        results["ema_rsi_macd"] = emr
        if settings.ema_rsi_required and not emr.passed:
            passed = False
        regime = self.regime.check(symbol, candles, ha) if settings.regime_enabled else None
        if regime == RANGE:
            passed = False
        last = ha[-1]
        snapshot = {
            "ha_direction": last.direction.value,
            "ha_close": last.ha_close,
            "body_size": last.body_size,
            "upper_wick": last.upper_wick,
            "lower_wick": last.lower_wick,
        }
        reason = "; ".join(f"{r.name}={r.score}" for r in results.values())
        return AnalysisResult(
            symbol=symbol,
            direction=direction.value if passed else None,
            score=score,
            passed=passed,
            filters=list(results.values()),
            reason=reason,
            ha_snapshot=snapshot,
            candle_timestamp=candles[-1].timestamp if candles else None,
            regime=regime,
            indicators=snap,
        )

    def best_candidate(self, analyses: List[AnalysisResult]) -> Optional[AnalysisResult]:
        valid = [a for a in analyses if a.passed and a.direction]
        if not valid:
            return None
        return max(valid, key=lambda a: a.score)
