"""Score aggregation. Total is an INTERNAL QUALITY SCORE (0-100), NOT a probability."""
from __future__ import annotations

from typing import Dict

from app.core.models import FilterResult

# Category weights per spec (already reflected in each filter's MAX).
CATEGORY_MAX = {
    "ha_trend": 25.0,
    "momentum": 20.0,
    "structure": 20.0,
    "volatility": 15.0,
    "noise": 10.0,
    "confirmation": 10.0,
}


def total_score(results: Dict[str, FilterResult]) -> float:
    total = 0.0
    for name, cap in CATEGORY_MAX.items():
        r = results.get(name)
        if r:
            total += min(r.score, cap)
    return round(total, 1)
