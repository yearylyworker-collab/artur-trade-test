"""Abstract MarketDataProvider interface."""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional

from app.candles.models import Candle
from app.core.models import Quote


class MarketDataProvider(ABC):
    name: str = "base"

    @abstractmethod
    async def connect(self) -> None: ...

    @abstractmethod
    async def disconnect(self) -> None: ...

    @abstractmethod
    async def get_symbols(self) -> List[str]: ...

    @abstractmethod
    async def get_candles(self, symbol: str, timeframe: str, limit: int) -> List[Candle]: ...

    @abstractmethod
    async def get_current_quote(self, symbol: str) -> Optional[Quote]: ...

    @abstractmethod
    async def subscribe_quotes(self, symbols: List[str]) -> None: ...

    @abstractmethod
    async def health_check(self) -> bool: ...

    @abstractmethod
    def get_quote_age(self, symbol: str) -> Optional[float]:
        """Seconds since last quote for symbol, or None."""
        ...
