"""Pocket Option OTC market data provider (read-only).

Uses the unofficial BinaryOptionsToolsV2 library (Rust core, WebSocket).
Authorisation is the ``ssid`` cookie of a Pocket Option session.

This provider NEVER trades: only candles and ticks are read. ``buy``/``sell``
of the library are intentionally not referenced anywhere in the project.

Design notes
------------
* No long-lived ``subscribe_*`` streams are used, so the library limit of
  4 simultaneous subscriptions does not apply. Instead history/ticks are
  polled, and ``POCKET_MAX_PARALLEL`` (default 4) bounds concurrent requests.
* Quotes are cached for ``POCKET_QUOTE_TTL_SECONDS`` so the result-waiting
  loop (1 request / second) does not flood the socket.
* The same provider also serves the *real* (non-OTC) pairs used by the
  arbitrage engine, e.g. ``EURUSD`` next to ``EURUSD_otc``.
"""
from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from app.candles.models import Candle
from app.config import settings
from app.core.exceptions import ProviderError
from app.core.logging_config import get_logger
from app.core.models import Quote
from app.market.base import MarketDataProvider

log = get_logger("market.pocket")

_PERIOD = {"S30": 30, "M1": 60, "M5": 300, "M15": 900}


def _to_dt(raw: Any) -> datetime:
    """Parse a timestamp that may be unix seconds, unix ms or an ISO string."""
    if isinstance(raw, (int, float)):
        ts = float(raw)
        if ts > 1e12:  # milliseconds
            ts /= 1000.0
        return datetime.fromtimestamp(ts, tz=timezone.utc)
    if isinstance(raw, str):
        s = raw.strip()
        try:
            return _to_dt(float(s))
        except ValueError:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    raise ValueError(f"unsupported timestamp: {raw!r}")


def _allowed_seconds(asset: Dict[str, Any]) -> set:
    """allowed_candles may be ints or {"time": 60}; empty -> assume M1 allowed."""
    out = set()
    for c in asset.get("allowed_candles") or []:
        if isinstance(c, dict):
            c = c.get("time", c.get("duration"))
        try:
            out.add(int(c))
        except (TypeError, ValueError):
            continue
    return out or {60}


def parse_candle(symbol: str, raw: Dict[str, Any], timeframe: str) -> Optional[Candle]:
    """Convert one library candle dict into our Candle (None if malformed)."""
    try:
        ts_raw = raw.get("timestamp", raw.get("time"))
        c = Candle(
            symbol=symbol,
            timestamp=_to_dt(ts_raw),
            open=float(raw["open"]),
            high=float(raw["high"]),
            low=float(raw["low"]),
            close=float(raw["close"]),
            timeframe=timeframe,
            source="pocketoption",
        )
        return c if c.is_valid() else None
    except (KeyError, TypeError, ValueError):
        return None


class PocketOptionProvider(MarketDataProvider):
    name = "pocketoption"

    def __init__(self, symbols: List[str], ssid: str, extra_symbols: Optional[List[str]] = None):
        # symbols == ["auto"] -> discover all active OTC assets from the server
        self.auto = [x.lower() for x in symbols] == ["auto"]
        self.symbols: List[str] = [] if self.auto else list(symbols)
        self._assets_loaded_at = 0.0
        self.pair_stats: Dict[str, int] = {}  # total active OTC / low payout
        self.payouts: Dict[str, int] = {}   # symbol -> current payout %, live
        # real pairs for arbitrage (quotes only, not analysed)
        self.extra_symbols = extra_symbols or []
        self._ssid = ssid
        self._api = None
        # ONE request at a time: the library's candle/tick module answers all
        # callers through one shared channel, so parallel requests steal each
        # other's responses and hang forever (seen in production: 0/21 pairs).
        self._sem = asyncio.Semaphore(1)
        self._swap_candle_args = True
        # live tick streams (updateStream) for symbols being traded right now
        self._live: Dict[str, Tuple[float, float, datetime]] = {}  # sym -> (recv_mono, price, ts)
        self._watch: Dict[str, asyncio.Task] = {}
        self._watch_refs: Dict[str, int] = {}
        self._quotes: Dict[str, Quote] = {}
        self._quote_fetched_at: Dict[str, float] = {}
        self._connected = False

    # ------------------------------------------------------------ lifecycle --
    async def connect(self) -> None:
        if not self._ssid.strip():
            raise ConnectionError("POCKET_SSID is empty")
        try:
            from BinaryOptionsToolsV2.pocketoption import PocketOptionAsync
        except ImportError as e:  # pragma: no cover - depends on install
            raise ConnectionError(
                "BinaryOptionsToolsV2 is not installed (pip install BinaryOptionsToolsV2)"
            ) from e

        if self._api is None:
            self._api = PocketOptionAsync(self._ssid)
        else:
            try:
                await self._api.reconnect()
            except Exception as e:  # noqa: BLE001
                log.warning("pocket reconnect call failed: %s", e)
        await asyncio.wait_for(self._api.wait_for_assets(settings.pocket_connect_timeout),
                               timeout=settings.pocket_connect_timeout + 5)
        if not self._api.is_connected():
            raise ConnectionError("Pocket Option websocket is not connected")
        self._connected = True
        if self.auto:
            await self.refresh_assets(force=True)
        log.info("Pocket Option connected (%d OTC assets, demo=%s)",
                 len(self.symbols), self._safe_is_demo())

    def _safe_is_demo(self) -> Optional[bool]:
        try:
            return self._api.is_demo()
        except Exception:  # noqa: BLE001
            return None

    async def disconnect(self) -> None:
        if self._api is not None:
            try:
                await self._api.shutdown()
            except Exception as e:  # noqa: BLE001
                log.warning("pocket shutdown error: %s", e)
        self._api = None
        self._connected = False

    async def health_check(self) -> bool:
        try:
            return bool(self._api is not None and self._api.is_connected())
        except Exception:  # noqa: BLE001
            return False

    # ----------------------------------------------------------------- data --
    async def refresh_assets(self, force: bool = False) -> None:
        """Auto mode: every active OTC asset of the allowed types (and payout)."""
        if not self.auto:
            return
        if not force and time.monotonic() - self._assets_loaded_at < \
                settings.otc_assets_refresh_minutes * 60:
            return
        try:
            assets = await self._call(self._require_api().active_assets())
        except Exception as e:  # noqa: BLE001
            log.warning("active_assets failed: %s (keeping %d)", e, len(self.symbols))
            return
        for a in assets:
            if a.get("symbol") and a.get("payout") is not None:
                try:
                    self.payouts[a["symbol"]] = int(a["payout"])
                except (TypeError, ValueError):
                    pass
        types = {t.lower() for t in settings.otc_asset_types}
        pool = [a for a in assets
                if a.get("is_otc") and a.get("is_active")
                and str(a.get("asset_type", "")).lower() in types]
        low = [a for a in pool if int(a.get("payout") or 0) < settings.otc_min_payout]
        self.pair_stats = {"total": len(pool), "low": len(low),
                           "min_payout": settings.otc_min_payout}
        found = sorted(
            a["symbol"] for a in assets
            if a.get("is_otc") and a.get("is_active")
            and str(a.get("asset_type", "")).lower() in types
            and int(a.get("payout") or 0) >= settings.otc_min_payout
            and _PERIOD.get(settings.default_timeframe, 60) in _allowed_seconds(a) | {60}
        )
        self._assets_loaded_at = time.monotonic()
        if found:
            if set(found) != set(self.symbols):
                log.info("OTC assets: %d active (%s…)", len(found), ", ".join(found[:6]))
            self.symbols = found

    async def get_symbols(self) -> List[str]:
        await self.refresh_assets()
        return list(self.symbols)

    async def current_payout(self, symbol: str) -> Optional[int]:
        """Fresh payout % right before publishing (one active_assets call)."""
        try:
            for a in await self._call(self._require_api().active_assets(), 10):
                if a.get("symbol") == symbol:
                    self.payouts[symbol] = int(a.get("payout") or 0)
                    if not a.get("is_active"):
                        return 0
                    break
        except Exception as e:  # noqa: BLE001
            log.debug("payout refresh failed %s: %s", symbol, e)
        return self.payouts.get(symbol)

    @staticmethod
    async def _call(coro, timeout: float = 20.0):
        """Library calls can hang forever on a dead socket — always bound them."""
        try:
            return await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError as e:
            raise ProviderError(f"Pocket Option call timed out after {timeout:.0f}s") from e

    def _require_api(self):
        if self._api is None:
            raise ProviderError("Pocket Option is not connected")
        return self._api

    async def get_candles(self, symbol: str, timeframe: str, limit: int) -> List[Candle]:
        """Closed candles, oldest first."""
        api = self._require_api()
        period = _PERIOD.get(timeframe, 60)
        now_ts = int(time.time())
        span = limit * period
        raw = []
        # BinaryOptionsToolsV2 0.2.15 bug: the Python wrapper forwards (time, offset)
        # into the Rust core whose order is (offset, time) -> swapped by default.
        # Try the order that worked last time first, then the other one.
        orders = [self._swap_candle_args, not self._swap_candle_args]
        for swap in orders:
            args = (span, now_ts) if swap else (now_ts, span)
            async with self._sem:
                raw = await self._call(api.get_candles_advanced(symbol, period, *args), 15)
            if raw:
                if swap != self._swap_candle_args:
                    log.info("candle arg order: swap=%s works", swap)
                self._swap_candle_args = swap
                break
        if not raw:
            async with self._sem:   # last resort: history endpoint
                try:
                    raw = await self._call(api.history(symbol, period), 15)
                except Exception as e:  # noqa: BLE001
                    log.debug("history failed %s: %s", symbol, e)
        out: List[Candle] = []
        seen = set()
        for item in raw or []:
            c = parse_candle(symbol, item, timeframe)
            if c and c.timestamp not in seen:
                seen.add(c.timestamp)
                out.append(c)
        if raw and not out:
            log.warning("candles for %s not parsed, sample: %s", symbol, str(raw[:1])[:300])
        out.sort(key=lambda c: c.timestamp)
        return out[-limit:]

    async def _fetch_last_tick(self, symbol: str) -> Optional[Tuple[datetime, float]]:
        api = self._require_api()
        for lookback in (5, 30):
            async with self._sem:
                ticks = await self._call(api.get_ticks(symbol, lookback), 8)
            if ticks:
                ts, price = ticks[-1][0], ticks[-1][1]
                return _to_dt(ts), float(price)
        return None

    # ------------------------------------------------------------ live stream --
    async def watch(self, symbol: str) -> bool:
        """Subscribe to the live tick stream of a symbol (the price trades settle on).
        Reference-counted; max 4 subscriptions in the library, we use at most 3."""
        self._watch_refs[symbol] = self._watch_refs.get(symbol, 0) + 1
        if symbol in self._watch and not self._watch[symbol].done():
            return True
        if len([t for t in self._watch.values() if not t.done()]) >= 3:
            return False
        self._watch[symbol] = asyncio.create_task(self._stream(symbol))
        return True

    async def unwatch(self, symbol: str) -> None:
        n = self._watch_refs.get(symbol, 0) - 1
        self._watch_refs[symbol] = max(0, n)
        if n > 0:
            return
        task = self._watch.pop(symbol, None)
        self._live.pop(symbol, None)
        if task:
            task.cancel()
        try:
            await self._call(self._require_api().unsubscribe(symbol), 5)
        except Exception:  # noqa: BLE001
            pass

    async def _stream(self, symbol: str) -> None:
        logged = False
        while True:
            try:
                sub = await self._call(self._require_api().subscribe_symbol(symbol), 15)
                async for item in sub:
                    if not isinstance(item, dict):
                        continue
                    price = item.get("close", item.get("price", item.get("value")))
                    ts_raw = item.get("timestamp", item.get("time"))
                    if price is None:
                        continue
                    try:
                        ts = _to_dt(ts_raw) if ts_raw is not None else datetime.now(timezone.utc)
                    except ValueError:
                        ts = datetime.now(timezone.utc)
                    self._live[symbol] = (time.monotonic(), float(price), ts)
                    if not logged:
                        logged = True
                        log.info("live stream %s: first tick %s @ %s", symbol, price, ts_raw)
            except asyncio.CancelledError:
                return
            except Exception as e:  # noqa: BLE001
                log.warning("live stream %s failed: %s (retry in 2s)", symbol, e)
                await asyncio.sleep(2)

    def live_price(self, symbol: str, max_age: float = 3.0) -> Optional[Tuple[float, datetime]]:
        v = self._live.get(symbol)
        if v and time.monotonic() - v[0] <= max_age:
            return v[1], v[2]
        return None

    async def get_current_quote(self, symbol: str) -> Optional[Quote]:
        live = self.live_price(symbol)
        if live:
            q = Quote(symbol=symbol, price=live[0], provider_timestamp=datetime.now(timezone.utc),
                      received_at=datetime.now(timezone.utc), source="pocketoption-live")
            self._quotes[symbol] = q
            return q
        now = time.monotonic()
        cached = self._quotes.get(symbol)
        if cached and now - self._quote_fetched_at.get(symbol, 0) < settings.pocket_quote_ttl_seconds:
            return cached
        try:
            tick = await self._fetch_last_tick(symbol)
        except Exception as e:  # noqa: BLE001
            log.warning("quote fetch failed %s: %s", symbol, e)
            return cached
        if tick is None:
            return cached
        pts, price = tick
        q = Quote(symbol=symbol, price=price, provider_timestamp=pts,
                  received_at=datetime.now(timezone.utc), source="pocketoption")
        self._quotes[symbol] = q
        self._quote_fetched_at[symbol] = now
        return q

    async def subscribe_quotes(self, symbols: List[str]) -> None:
        """Polling provider: nothing to subscribe."""
        return None

    def get_quote_age(self, symbol: str) -> Optional[float]:
        """Age of the last price by the PROVIDER timestamp (catches frozen feeds)."""
        q = self._quotes.get(symbol)
        if not q:
            return None
        return (datetime.now(timezone.utc) - q.provider_timestamp).total_seconds()
