"""Deterministic mock market data provider for DEMO mode."""
from __future__ import annotations

import math
import random
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

from app.candles.models import Candle
from app.core.logging_config import get_logger
from app.core.models import Quote
from app.market.base import MarketDataProvider

log = get_logger("market.mock")

BASE_PRICES = {
    "EUR/USD": 1.0850, "GBP/USD": 1.2650, "USD/JPY": 149.50,
    "AUD/USD": 0.6580, "USD/CAD": 1.3620, "EUR/GBP": 0.8570,
}


class MockMarketDataProvider(MarketDataProvider):
    name = "mock"

    def __init__(self, symbols: List[str], seed: int = 42):
        self.symbols = symbols
        self._rng = random.Random(seed)
        self._connected = False
        self._last_quote_at: Dict[str, datetime] = {}
        self._price: Dict[str, float] = {}
        self._trend: Dict[str, float] = {}
        for s in symbols:
            self._price[s] = BASE_PRICES.get(s, 1.0 + self._rng.random())
            self._trend[s] = self._rng.uniform(-1, 1)

    async def connect(self) -> None:
        self._connected = True
        log.info("Mock provider connected (%d symbols)", len(self.symbols))

    async def disconnect(self) -> None:
        self._connected = False

    async def get_symbols(self) -> List[str]:
        return list(self.symbols)

    def _pip(self, symbol: str) -> float:
        return 0.01 if symbol.endswith("JPY") else 0.0001

    async def get_candles(self, symbol: str, timeframe: str, limit: int) -> List[Candle]:
        """Generate `limit` M1 candles ending at the current minute."""
        now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        pip = self._pip(symbol)
        price = BASE_PRICES.get(symbol, self._price[symbol])
        candles: List[Candle] = []
        trend = self._trend[symbol]
        for i in range(limit, 0, -1):
            ts = now - timedelta(minutes=i)
            drift = trend * pip * self._rng.uniform(0.5, 2.0)
            noise = pip * self._rng.uniform(-3, 3)
            o = price
            c = max(pip, o + drift + noise)
            hi = max(o, c) + pip * self._rng.uniform(0, 2)
            lo = min(o, c) - pip * self._rng.uniform(0, 2)
            candles.append(Candle(
                symbol=symbol, timestamp=ts, open=round(o, 5), high=round(hi, 5),
                low=round(lo, 5), close=round(c, 5), timeframe=timeframe, source=self.name,
            ))
            price = c
            if self._rng.random() < 0.1:
                trend = self._rng.uniform(-1, 1)
        self._price[symbol] = price
        return candles

    async def get_current_quote(self, symbol: str) -> Optional[Quote]:
        pip = self._pip(symbol)
        # Skew ~70% of ticks along the (biased) trend so DEMO shows more WINs
        # than LOSSes while still producing honest occasional losses.
        direction = 1 if self._trend[symbol] >= 0 else -1
        step = pip * self._rng.uniform(0.4, 1.8)
        if self._rng.random() < 0.70:
            self._price[symbol] += direction * step
        else:
            self._price[symbol] -= direction * step
        now = datetime.now(timezone.utc)
        self._last_quote_at[symbol] = now
        return Quote(symbol=symbol, price=round(self._price[symbol], 5),
                     provider_timestamp=now, received_at=now, source=self.name)

    async def subscribe_quotes(self, symbols: List[str]) -> None:
        for s in symbols:
            self._last_quote_at[s] = datetime.now(timezone.utc)

    async def health_check(self) -> bool:
        return self._connected

    def get_quote_age(self, symbol: str) -> Optional[float]:
        last = self._last_quote_at.get(symbol)
        if not last:
            return None
        return (datetime.now(timezone.utc) - last).total_seconds()

    def bias(self, symbol: str, direction: str) -> None:
        """DEMO helper: bias a symbol strongly to guarantee a setup."""
        self._trend[symbol] = 1.5 if direction == "BUY" else -1.5
