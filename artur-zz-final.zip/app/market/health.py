"""Provider health helper."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ProviderStatus:
    online: bool
    ws_connected: bool
    detail: str = ""
