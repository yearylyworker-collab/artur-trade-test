"""Market provider factory & manager."""
from __future__ import annotations

from app.config import settings
from app.core.logging_config import get_logger
from app.market.base import MarketDataProvider
from app.market.mock.provider import MockMarketDataProvider

log = get_logger("market.manager")


def build_provider(mode: str, override: str | None = None) -> MarketDataProvider:
    """DEMO -> mock.  LIVE -> MARKET_PROVIDER (pocket | forex), mock if forced.
    ``override`` forces a provider (used by the Forex fallback)."""
    provider = (override or settings.market_provider).lower()
    if mode.upper() == "LIVE" and provider == "pocket":
        from app.market.pocket.provider import PocketOptionProvider
        extra = [real for real, _otc in settings.arb_pair_map] \
            if settings.arb_mode.lower() != "off" else []
        log.info("Building LIVE Pocket Option OTC provider (%d assets)",
                 len(settings.otc_assets))
        return PocketOptionProvider(settings.otc_assets, settings.pocket_ssid,
                                    extra_symbols=extra)
    if mode.upper() == "LIVE" and provider == "forex":
        from app.market.forex.provider import ForexMarketDataProvider
        log.info("Building LIVE forex provider (twelvedata)")
        return ForexMarketDataProvider(
            symbols=settings.forex_symbols,
            api_key=settings.forex_api_key,
            rest_url=settings.forex_rest_url,
            ws_url=settings.forex_ws_url,
        )
    log.info("Building MOCK provider (demo)")
    symbols = settings.forex_symbols if settings.otc_auto else settings.active_symbols
    return MockMarketDataProvider(symbols, seed=settings.demo_random_seed)
