"""Twelve Data WebSocket live-quote client."""
from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Callable, Dict, List, Optional

import websockets

from app.core.logging_config import get_logger
from app.core.models import Quote
from app.market.forex.symbol_mapper import from_provider, to_provider

log = get_logger("market.forex.ws")


class ForexWebSocket:
    def __init__(self, ws_url: str, api_key: str, on_quote: Callable[[Quote], None]):
        self.ws_url = ws_url
        self.api_key = api_key
        self.on_quote = on_quote
        self._ws = None
        self._task: Optional[asyncio.Task] = None
        self._symbols: List[str] = []
        self._connected = False
        self._stop = False

    @property
    def connected(self) -> bool:
        return self._connected

    async def connect(self, symbols: List[str]) -> None:
        self._symbols = symbols
        self._stop = False
        self._task = asyncio.create_task(self._run())

    async def _run(self) -> None:
        url = f"{self.ws_url}?apikey={self.api_key}"
        while not self._stop:
            try:
                async with websockets.connect(url, ping_interval=10) as ws:
                    self._ws = ws
                    self._connected = True
                    await ws.send(json.dumps({
                        "action": "subscribe",
                        "params": {"symbols": ",".join(to_provider(s) for s in self._symbols)},
                    }))
                    log.info("WS connected, subscribed %d symbols", len(self._symbols))
                    async for raw in ws:
                        self._handle(raw)
            except Exception as e:  # noqa: BLE001
                self._connected = False
                if self._stop:
                    break
                log.warning("WS error: %s; reconnecting in 5s", e)
                await asyncio.sleep(5)
        self._connected = False

    def _handle(self, raw: str) -> None:
        try:
            msg = json.loads(raw)
        except Exception:  # noqa: BLE001
            return
        if msg.get("event") != "price":
            return
        symbol = from_provider(msg.get("symbol", ""))
        price = msg.get("price")
        if symbol and price is not None:
            ts = msg.get("timestamp")
            now = datetime.now(timezone.utc)
            pts = datetime.fromtimestamp(int(ts), tz=timezone.utc) if ts else now
            self.on_quote(Quote(symbol=symbol, price=float(price),
                                provider_timestamp=pts, received_at=now, source="twelvedata"))

    async def disconnect(self) -> None:
        self._stop = True
        if self._ws:
            await self._ws.close()
        if self._task:
            self._task.cancel()
        self._connected = False
