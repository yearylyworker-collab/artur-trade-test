"""Twelve Data REST client."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

import httpx

from app.candles.models import Candle
from app.config import settings
from app.core.exceptions import ProviderError
from app.core.logging_config import get_logger
from app.core.models import Quote
from app.market.forex.symbol_mapper import to_provider

log = get_logger("market.forex.rest")

_INTERVAL = {"M1": "1min", "M5": "5min", "M15": "15min", "H1": "1h"}


class ForexRestClient:
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._client: Optional[httpx.AsyncClient] = None
        self._credit_day = None
        self.credits_used = 0

    def _spend_credit(self) -> None:
        """Daily budget guard (Twelve Data resets at 00:00 UTC)."""
        today = datetime.now(timezone.utc).date()
        if self._credit_day != today:
            self._credit_day, self.credits_used = today, 0
        if self.credits_used >= settings.forex_daily_credit_limit:
            raise ProviderError(f"daily API budget reached ({self.credits_used})")
        self.credits_used += 1

    @property
    def budget_exhausted(self) -> bool:
        today = datetime.now(timezone.utc).date()
        return self._credit_day == today and self.credits_used >= settings.forex_daily_credit_limit

    async def _get(self, path: str, params: dict) -> dict:
        self._spend_credit()
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=15.0)
        params = {**params, "apikey": self.api_key}
        r = await self._client.get(f"{self.base_url}/{path}", params=params)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and data.get("status") == "error":
            raise ProviderError(data.get("message", "twelvedata error"))
        return data

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    async def health(self) -> bool:
        try:
            await self._get("time_series", {
                "symbol": "EUR/USD", "interval": "1min", "outputsize": 1,
                "format": "JSON", "timezone": "UTC",
            })
            return True
        except Exception as e:  # noqa: BLE001
            log.warning("REST health failed: %s", e)
            return False

    async def candles(self, symbol: str, timeframe: str, limit: int) -> List[Candle]:
        interval = _INTERVAL.get(timeframe, "1min")
        data = await self._get("time_series", {
            "symbol": to_provider(symbol), "interval": interval,
            "outputsize": limit, "format": "JSON", "timezone": "UTC",
        })
        values = data.get("values", []) or []
        out: List[Candle] = []
        for v in reversed(values):  # API returns newest-first
            ts = datetime.strptime(v["datetime"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            out.append(Candle(
                symbol=symbol, timestamp=ts, open=float(v["open"]), high=float(v["high"]),
                low=float(v["low"]), close=float(v["close"]),
                volume=float(v["volume"]) if v.get("volume") else None,
                timeframe=timeframe, source="twelvedata",
            ))
        return out

    async def quote(self, symbol: str) -> Optional[Quote]:
        """Latest real-time price.

        Uses /price (1 credit). The old /quote endpoint returns the DAILY bar
        by default: its "close" lags and its timestamp is the day start, which
        made entry and exit prices identical -> fake DRAW results.
        """
        data = await self._get("price", {"symbol": to_provider(symbol)})
        price = data.get("price")
        if price is None:
            return None
        now = datetime.now(timezone.utc)
        return Quote(symbol=symbol, price=float(price), provider_timestamp=now,
                     received_at=now, source="twelvedata")
