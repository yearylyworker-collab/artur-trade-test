"""Twelve Data forex provider (REST + WebSocket)."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Dict, List, Optional

from app.candles.models import Candle
from app.core.logging_config import get_logger
from app.core.models import Quote
from app.market.base import MarketDataProvider
from app.market.forex.rest import ForexRestClient
from app.market.forex.websocket import ForexWebSocket

log = get_logger("market.forex")


class ForexMarketDataProvider(MarketDataProvider):
    name = "twelvedata"

    def __init__(self, symbols: List[str], api_key: str, rest_url: str, ws_url: str):
        self.symbols = symbols
        self.rest = ForexRestClient(rest_url, api_key)
        self.ws = ForexWebSocket(ws_url, api_key, self._on_ws_quote)
        self._quotes: Dict[str, Quote] = {}
        self._connected = False

    def _on_ws_quote(self, quote: Quote) -> None:
        self._quotes[quote.symbol] = quote

    async def connect(self) -> None:
        ok = await self.rest.health()
        if not ok:
            raise ConnectionError("Twelve Data REST health check failed")
        self._connected = True
        log.info("Forex provider REST OK")

    async def disconnect(self) -> None:
        await self.ws.disconnect()
        await self.rest.close()
        self._connected = False

    async def get_symbols(self) -> List[str]:
        return list(self.symbols)

    async def get_candles(self, symbol: str, timeframe: str, limit: int) -> List[Candle]:
        return await self.rest.candles(symbol, timeframe, limit)

    async def get_current_quote(self, symbol: str) -> Optional[Quote]:
        q = self._quotes.get(symbol)
        if q is not None:
            return q
        q = await self.rest.quote(symbol)  # REST fallback
        if q:
            self._quotes[symbol] = q
        return q

    async def subscribe_quotes(self, symbols: List[str]) -> None:
        await self.ws.connect(symbols)

    async def health_check(self) -> bool:
        # No API call here: on the free plan every request costs a credit.
        return self._connected and not self.rest.budget_exhausted

    @property
    def ws_connected(self) -> bool:
        return self.ws.connected

    def get_quote_age(self, symbol: str) -> Optional[float]:
        q = self._quotes.get(symbol)
        if not q:
            return None
        return (datetime.now(timezone.utc) - q.received_at).total_seconds()
