"""Symbol mapping between internal notation (EUR/USD) and provider notation."""
from __future__ import annotations


def to_provider(symbol: str) -> str:
    # Twelve Data uses "EUR/USD" already.
    return symbol


def from_provider(symbol: str) -> str:
    return symbol
