"""ARTUR TRADE — application entrypoint."""
from __future__ import annotations

import asyncio
import signal as os_signal

from aiogram import Bot, Dispatcher

from app.bot.handlers import admin, panel, start, status, templates
from app.config import settings
from app.core.enums import Mode
from app.core.logging_config import get_logger, setup_logging
from app.database.session import close_db, init_db
from app.scheduler.engine_loop import market_analysis_loop
from app.scheduler.tasks import (
    cleanup_loop, heartbeat_loop, health_monitor_loop, provider_reconnect_loop,
)
from app.analytics.shadow import shadow_loop
from app.engines.adaptive import adaptive_loop
from app.services import engine_control as ctrl
from app.services.daily import daily_stats_loop
from app.services.main_channel import main_channel_loop
from app.services.chanmon import monitor_loop as chanmon_loop
from app.services.broadcast import broadcast_loop
from app.services.fallback import fallback_loop
from app.services.recovery import recover_active_signals
from app.services.state import state

log = get_logger("main")


async def on_startup(bot: Bot) -> None:
    log.info("=== ARTUR TRADE starting ===")
    await init_db()
    from app.services import runtime
    runtime.load()
    from app.ml.filter import ml_filter
    ml_filter.load()

    me = await bot.get_me()
    log.info("Telegram connected as @%s", me.username)
    state.init_telegram(bot)

    # channel permission check
    if state.publisher:
        state.channel_ok = await state.publisher.check_channel()
        log.info("channel verified: %s", state.channel_ok)

    # restart recovery
    await recover_active_signals(state.mode.value)


async def bring_up(bot: Bot) -> None:
    """Market connection + engine start. Runs AFTER Telegram polling started,
    so the admin panel answers even if the broker is slow or hangs."""

    # connect provider (bounded: a hung broker must not freeze start-up)
    try:
        ok = await asyncio.wait_for(ctrl.switch_mode(state.mode), timeout=180)
    except asyncio.TimeoutError:
        ok = False
        state.provider_error = "подключение к провайдеру не завершилось за 180 с"
        log.error("provider connect timed out")
    log.info("provider connected: %s (mode=%s)", ok, state.mode.value)

    if settings.engine_auto_start:
        try:
            started = await asyncio.wait_for(ctrl.start_engine(), timeout=240)
        except asyncio.TimeoutError:
            started = False
        log.info("engine auto-start: %s", started)

    if settings.startup_report:
        from app.analytics.reports import startup_report
        from app.scheduler.engine_loop import _notify_admins
        try:
            text = startup_report(ok)
            for admin_id in settings.admin_ids:
                await bot.send_message(admin_id, text, parse_mode="HTML")
        except Exception as e:  # noqa: BLE001
            log.warning("startup report failed: %s", e)
            await _notify_admins("ARTUR TRADE запущен (отчёт не сформирован)")


async def start_background_tasks() -> list[asyncio.Task]:
    tasks = [
        asyncio.create_task(market_analysis_loop(), name="analysis"),
        asyncio.create_task(health_monitor_loop(), name="health"),
        asyncio.create_task(provider_reconnect_loop(), name="reconnect"),
        asyncio.create_task(heartbeat_loop(), name="heartbeat"),
        asyncio.create_task(cleanup_loop(), name="cleanup"),
        asyncio.create_task(shadow_loop(state), name="shadow"),
        asyncio.create_task(adaptive_loop(state), name="adaptive"),
        asyncio.create_task(fallback_loop(), name="fallback"),
        asyncio.create_task(daily_stats_loop(), name="daily_stats"),
        asyncio.create_task(main_channel_loop(), name="main_channel"),
        asyncio.create_task(chanmon_loop(state.bot), name="chanmon"),
        asyncio.create_task(broadcast_loop(), name="broadcast"),
    ]
    log.info("background tasks started: %d", len(tasks))
    return tasks


async def main() -> None:
    setup_logging()
    if not settings.bot_token:
        raise RuntimeError("BOT_TOKEN is not set")
    settings.validate_runtime()

    bot = Bot(token=settings.bot_token)
    from app.services.chanmon import ChannelMonitorMiddleware
    bot.session.middleware(ChannelMonitorMiddleware())
    dp = Dispatcher()
    dp.include_router(panel.router)   # admin-only; must be first (/start, /stats)
    dp.include_router(start.router)
    dp.include_router(status.router)
    dp.include_router(templates.router)
    dp.include_router(admin.router)

    await on_startup(bot)
    tasks = await start_background_tasks()

    stop_event = asyncio.Event()

    def _graceful(*_):
        log.info("shutdown signal received")
        stop_event.set()

    loop = asyncio.get_event_loop()
    for sig in (os_signal.SIGINT, os_signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _graceful)
        except NotImplementedError:
            pass

    polling = asyncio.create_task(dp.start_polling(bot, handle_signals=False),
                                  name="polling")
    log.info("=== ARTUR TRADE ready (Telegram polling) ===")
    asyncio.create_task(bring_up(bot), name="bring_up")

    await stop_event.wait()

    # graceful shutdown
    polling.cancel()
    for t in tasks:
        t.cancel()
    if state.provider:
        await state.provider.disconnect()
    await bot.session.close()
    await close_db()
    log.info("=== ARTUR TRADE stopped ===")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
