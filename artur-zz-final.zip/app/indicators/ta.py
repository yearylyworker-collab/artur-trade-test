"""Technical indicators as pure functions over lists of floats.

Every function returns a list aligned with its input: element ``i`` is the
indicator value computed using data up to and including index ``i`` only
(no look-ahead). Positions without enough history are ``None``.

Smoothing conventions (the common ones used by trading terminals):
* EMA seeded with the SMA of the first ``period`` values, alpha = 2/(n+1).
* RSI and ATR use Wilder's smoothing (alpha = 1/n).
"""
from __future__ import annotations

from math import sqrt
from typing import List, Optional, Sequence, Tuple

Series = List[Optional[float]]


def sma(values: Sequence[float], period: int) -> Series:
    out: Series = [None] * len(values)
    if period <= 0:
        return out
    acc = 0.0
    for i, v in enumerate(values):
        acc += v
        if i >= period:
            acc -= values[i - period]
        if i >= period - 1:
            out[i] = acc / period
    return out


def ema(values: Sequence[float], period: int) -> Series:
    out: Series = [None] * len(values)
    if period <= 0 or len(values) < period:
        return out
    alpha = 2.0 / (period + 1)
    prev = sum(values[:period]) / period
    out[period - 1] = prev
    for i in range(period, len(values)):
        prev = alpha * values[i] + (1 - alpha) * prev
        out[i] = prev
    return out


def _wilder(values: Sequence[float], period: int, start: int) -> Series:
    """Wilder smoothing of ``values`` beginning at index ``start``."""
    out: Series = [None] * len(values)
    if len(values) - start < period:
        return out
    prev = sum(values[start:start + period]) / period
    out[start + period - 1] = prev
    for i in range(start + period, len(values)):
        prev = (prev * (period - 1) + values[i]) / period
        out[i] = prev
    return out


def rsi(closes: Sequence[float], period: int = 14) -> Series:
    n = len(closes)
    out: Series = [None] * n
    if n <= period:
        return out
    gains = [0.0] * n
    losses = [0.0] * n
    for i in range(1, n):
        d = closes[i] - closes[i - 1]
        gains[i] = max(d, 0.0)
        losses[i] = max(-d, 0.0)
    avg_g = _wilder(gains, period, 1)
    avg_l = _wilder(losses, period, 1)
    for i in range(n):
        g, l = avg_g[i], avg_l[i]
        if g is None or l is None:
            continue
        if l == 0:
            out[i] = 100.0 if g > 0 else 50.0
        else:
            out[i] = 100.0 - 100.0 / (1.0 + g / l)
    return out


def macd(closes: Sequence[float], fast: int = 12, slow: int = 26,
         signal: int = 9) -> Tuple[Series, Series, Series]:
    """Returns (macd_line, signal_line, histogram)."""
    n = len(closes)
    ef, es = ema(closes, fast), ema(closes, slow)
    line: Series = [None] * n
    for i in range(n):
        if ef[i] is not None and es[i] is not None:
            line[i] = ef[i] - es[i]
    first = next((i for i, v in enumerate(line) if v is not None), None)
    sig: Series = [None] * n
    hist: Series = [None] * n
    if first is None:
        return line, sig, hist
    sig_part = ema([v for v in line[first:]], signal)  # type: ignore[misc]
    for j, v in enumerate(sig_part):
        sig[first + j] = v
    for i in range(n):
        if line[i] is not None and sig[i] is not None:
            hist[i] = line[i] - sig[i]
    return line, sig, hist


def true_range(highs: Sequence[float], lows: Sequence[float],
               closes: Sequence[float]) -> List[float]:
    tr = []
    for i in range(len(closes)):
        if i == 0:
            tr.append(highs[0] - lows[0])
        else:
            pc = closes[i - 1]
            tr.append(max(highs[i] - lows[i], abs(highs[i] - pc), abs(lows[i] - pc)))
    return tr


def atr(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float],
        period: int = 14) -> Series:
    return _wilder(true_range(highs, lows, closes), period, 0)


def bollinger(closes: Sequence[float], period: int = 20,
              num_std: float = 2.0) -> Tuple[Series, Series, Series]:
    """Returns (lower, middle, upper) with population std-dev."""
    n = len(closes)
    mid = sma(closes, period)
    lo: Series = [None] * n
    up: Series = [None] * n
    for i in range(period - 1, n):
        window = closes[i - period + 1:i + 1]
        m = mid[i]
        sd = sqrt(sum((x - m) ** 2 for x in window) / period)
        lo[i] = m - num_std * sd
        up[i] = m + num_std * sd
    return lo, mid, up


def last(series: Series) -> Optional[float]:
    return series[-1] if series else None
