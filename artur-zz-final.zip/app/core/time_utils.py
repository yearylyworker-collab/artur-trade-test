"""Time helpers. All internal timestamps are UTC; display in configured tz."""
from __future__ import annotations

from datetime import datetime, timezone, timedelta

import pytz

from app.config import settings

_LOCAL_TZ = pytz.timezone(settings.timezone)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def to_local(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(_LOCAL_TZ)


def fmt_time(dt: datetime) -> str:
    """HH:MM:SS in local tz."""
    return to_local(dt).strftime("%H:%M:%S")


def fmt_hm(dt: datetime) -> str:
    return to_local(dt).strftime("%H:%M")


def next_entry_time(now: datetime, entry_second: int, min_lead: int) -> datetime:
    """Compute exact entry time aligned to entry_second of a minute.

    If not enough lead time remains before this minute's entry second,
    roll to the next minute.
    """
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    candidate = now.replace(second=entry_second, microsecond=0)
    while (candidate - now).total_seconds() < min_lead:
        candidate = candidate + timedelta(minutes=1)
    return candidate


def in_trading_session(now: datetime | None = None, skip_weekends: bool = False) -> bool:
    """True if local time is inside TRADING_SESSION_START..END (empty = always)."""
    local = to_local(now or utc_now())
    if skip_weekends and local.weekday() >= 5:
        return False
    start, end = settings.trading_session_start.strip(), settings.trading_session_end.strip()
    if not start or not end:
        return True
    hm = local.strftime("%H:%M")
    if start <= end:
        return start <= hm < end
    return hm >= start or hm < end  # overnight session
