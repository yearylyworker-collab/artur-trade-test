"""Custom exceptions."""
from __future__ import annotations


class ArturError(Exception):
    """Base exception."""


class ProviderError(ArturError):
    """Market data provider failure."""


class ProviderOfflineError(ProviderError):
    """Provider unreachable / offline."""


class StaleDataError(ProviderError):
    """Quote or candle data is stale."""


class ChannelPermissionError(ArturError):
    """Bot lacks required channel permissions."""


class DataUnavailableError(ArturError):
    """Result cannot be resolved from provider data."""
