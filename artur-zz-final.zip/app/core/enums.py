"""Core enumerations for ARTUR TRADE."""
from __future__ import annotations

from enum import Enum


class Mode(str, Enum):
    DEMO = "DEMO"
    LIVE = "LIVE"


class MarketType(str, Enum):
    FOREX = "FOREX"
    OTC = "OTC"


class Direction(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class HADirection(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


class Trend(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    FLAT = "FLAT"


class SignalStatus(str, Enum):
    SEARCHING = "SEARCHING"
    CANDIDATE = "CANDIDATE"
    CONFIRMING = "CONFIRMING"
    FOUND = "FOUND"
    PUBLISHED = "PUBLISHED"
    WAITING_ENTRY = "WAITING_ENTRY"
    ENTERED = "ENTERED"
    WAITING_RESULT = "WAITING_RESULT"
    REENTRY_PENDING = "REENTRY_PENDING"
    WIN = "WIN"
    LOSS = "LOSS"
    DRAW = "DRAW"
    CANCELLED = "CANCELLED"
    DATA_UNAVAILABLE = "DATA_UNAVAILABLE"
    ERROR = "ERROR"


class AttemptResult(str, Enum):
    WIN = "WIN"
    LOSS = "LOSS"
    DRAW = "DRAW"
    PENDING = "PENDING"


TERMINAL_STATUSES = {
    SignalStatus.WIN,
    SignalStatus.LOSS,
    SignalStatus.DRAW,
    SignalStatus.CANCELLED,
    SignalStatus.DATA_UNAVAILABLE,
    SignalStatus.ERROR,
}
