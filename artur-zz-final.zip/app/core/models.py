"""In-memory domain dataclasses (not ORM)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from app.core.enums import HADirection


@dataclass
class Quote:
    symbol: str
    price: float
    provider_timestamp: datetime  # UTC
    received_at: datetime         # UTC (local receive time)
    source: str


@dataclass
class FilterResult:
    name: str
    passed: bool
    score: float
    max_score: float
    reason: str


@dataclass
class AnalysisResult:
    symbol: str
    direction: Optional[str]  # BUY / SELL / None
    score: float
    passed: bool
    filters: List[FilterResult] = field(default_factory=list)
    reason: str = ""
    ha_snapshot: dict = field(default_factory=dict)
    candle_timestamp: Optional[datetime] = None
    regime: Optional[str] = None           # TREND / RANGE / VOLATILE
    indicators: dict = field(default_factory=dict)  # rsi, atr, ema..., for captions & ML
    engine: str = "ha"                      # ha | arbitrage
    ml_prob: Optional[float] = None
    ml_features: dict = field(default_factory=dict)
