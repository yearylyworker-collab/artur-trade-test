"""In-flight signal dataclass."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class SignalDraft:
    mode: str
    symbol: str
    market: str
    direction: str
    score: float
    timeframe: str
    entry_time: datetime
    expiry_seconds: int
    provider: str
    audit: dict = field(default_factory=dict)
