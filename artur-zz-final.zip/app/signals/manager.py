"""SignalManager — one strictly-sequential signal series per Telegram channel.

Flow (each stage is a NEW post; nothing is edited into another card):
  SEARCH (temp) -> ANALYSIS (temp) -> delete temps ->
  BUY/SELL (permanent) -> [REENTRY (permanent)] -> RESULT (permanent) -> cooldown

Direction is taken ONLY from an immutable SignalPublicationSnapshot.
Cards are static PNGs (StaticCardRegistry / cached file_id); all dynamic data
lives in the caption. The engine is never blocked by presentation timing.
"""
from __future__ import annotations

import asyncio
from datetime import timedelta
from typing import Optional

from app.config import settings
from app.core.enums import AttemptResult, Direction, SignalStatus
from app.core.exceptions import DataUnavailableError
from app.core.logging_config import get_logger
from app.core.models import AnalysisResult
from app.core.time_utils import next_entry_time, utc_now
from app.database.repositories.repos import SignalRepository, TelegramMessageRepository
from app.database.session import get_session
from app.publisher import formatter
from app.results.checker import capture_price, wait_until
from app.results.resolver import resolve
from app.signals.generator import build_draft
from app.signals.models import SignalDraft
from app.signals.snapshot import SignalPublicationSnapshot, card_type_for


def pairs_count() -> int:
    from app.services.engine_control import pairs_count as _pc
    return _pc()

log = get_logger("signals.manager")


class SignalManager:
    def __init__(self, state):
        self.state = state
        self.mirror = False   # this window is also shown in the main channel

    # ---- main channel: one full window every MAIN_CHANNEL_EVERY_HOURS ----
    _MAIN_MARK = "./runtime/main_channel_last"

    @classmethod
    def _main_due(cls) -> bool:
        import time
        if not settings.main_channel_id:
            return False
        try:
            last = float(open(cls._MAIN_MARK).read().strip())
        except (OSError, ValueError):
            last = 0.0
        return time.time() - last >= settings.main_channel_every_hours * 3600

    @classmethod
    def _main_mark(cls) -> None:
        import os, time
        try:
            os.makedirs(os.path.dirname(cls._MAIN_MARK), exist_ok=True)
            with open(cls._MAIN_MARK, "w") as f:
                f.write(str(time.time()))
        except OSError as e:
            log.warning("main channel mark failed: %s", e)

    async def _mirror_card(self, card_type: str, caption: str) -> None:
        if not self.mirror:
            return
        try:
            await self.state.cards.send(settings.main_channel_id, card_type, caption)
        except Exception as e:  # noqa: BLE001
            log.warning("main channel post failed: %s", e)

    async def _mirror_text(self, text: str) -> None:
        if not self.mirror:
            return
        try:
            await self.state.bot.send_message(settings.main_channel_id, text, parse_mode="HTML")
        except Exception as e:  # noqa: BLE001
            log.warning("main channel text failed: %s", e)

    # ---- low-level publish helpers ----
    async def _post(self, chat_id: int, card_type: str, caption: str) -> Optional[int]:
        return await self.state.cards.send(chat_id, card_type, caption)

    async def _post_channel(self, card_type: str, caption: str,
                            signal_id: int, kind: str) -> Optional[int]:
        mid = await self._post(settings.signal_channel_id, card_type, caption)
        if mid is not None:
            await self._save_message(signal_id, mid, kind)
            await self._mirror_card(card_type, caption)
        return mid

    async def _post_text_channel(self, text: str, signal_id: int, kind: str) -> Optional[int]:
        """Text-only post (used for DRAW, which has no card image)."""
        try:
            msg = await self.state.bot.send_message(settings.signal_channel_id, text,
                                                    parse_mode="HTML")
        except Exception as e:  # noqa: BLE001
            log.error("text post failed: %s", e)
            return None
        await self._save_message(signal_id, msg.message_id, kind)
        await self._mirror_text(text)
        return msg.message_id

    async def _delete(self, message_id: Optional[int]) -> None:
        if message_id is not None and self.state.publisher:
            await self.state.publisher.delete_message(message_id)

    # ---- lifecycle ----
    async def run(self, analysis: AnalysisResult) -> None:
        st = self.state
        provider = st.provider
        supports_short = getattr(provider, "ws_connected", False)

        draft = build_draft(analysis, st.mode, provider.name, supports_short)

        # Schedule entry with enough lead for the presentation + human prep.
        service_posts = not (settings.window_mode and settings.window_skip_service_posts)
        required_lead = settings.min_signal_lead_seconds + (
            settings.search_temp_seconds + settings.analysis_temp_seconds if service_posts else 0)
        if settings.window_mode and settings.window_analysis_card and not service_posts:
            required_lead += settings.analysis_temp_seconds
        draft.entry_time = next_entry_time(utc_now(), settings.entry_second, required_lead)

        async with get_session() as s:
            sig = await SignalRepository(s).create(
                mode=draft.mode, symbol=draft.symbol, market=draft.market,
                direction=draft.direction, score=draft.score, timeframe=draft.timeframe,
                entry_time=draft.entry_time, expiry_seconds=draft.expiry_seconds,
                status=SignalStatus.FOUND.value, provider=draft.provider, audit=draft.audit,
            )
            await s.commit()
            signal_id = sig.id

        snapshot = SignalPublicationSnapshot(
            signal_id=signal_id, pair=draft.symbol, direction=draft.direction,
            entry_time=draft.entry_time, expiry_seconds=draft.expiry_seconds,
            timeframe=draft.timeframe, market=draft.market,
        )
        st.active_signal_id = signal_id
        st.signals_today += 1
        log.info("series start id=%s %s %s score=%.0f", signal_id, snapshot.pair,
                 snapshot.direction, draft.score)

        try:
            await self._lifecycle(snapshot, draft, analysis)
        except Exception as e:  # noqa: BLE001
            log.exception("lifecycle error: %s", e)
            await self._set_status(signal_id, SignalStatus.ERROR)
        finally:
            st.cooldown.arm(draft.symbol)
            await asyncio.sleep(settings.post_result_cooldown_seconds)
            st.active_signal_id = None
            if st.engine_on:
                from app.services.engine_control import post_search_card
                await post_search_card()

    async def _lifecycle(self, snapshot: SignalPublicationSnapshot,
                        draft: SignalDraft, analysis: AnalysisResult) -> None:
        st = self.state
        sid = snapshot.signal_id
        n_pairs = pairs_count()

        if settings.window_mode:
            await self._window_lifecycle(snapshot, draft, analysis)
            return

        # 1. SEARCH (temporary service post)
        search_mid = await self._post(
            settings.signal_channel_id, "SEARCH",
            formatter.search_caption(snapshot.timeframe, n_pairs))
        await asyncio.sleep(settings.search_temp_seconds)

        # 2. ANALYSIS (temporary service post — real candidate exists)
        analysis_mid = await self._post(
            settings.signal_channel_id, "ANALYSIS",
            formatter.analysis_caption(snapshot.pair, snapshot.market, snapshot.timeframe))
        await self._set_status(sid, SignalStatus.CONFIRMING)
        await asyncio.sleep(settings.analysis_temp_seconds)

        # delete temporary posts before the permanent signal
        await self._delete(search_mid)
        await self._delete(analysis_mid)

        # 3. CONFIRMED SIGNAL (permanent). Direction strictly from snapshot.
        card_type = card_type_for(snapshot)
        expected = Direction.BUY.value if snapshot.is_buy else Direction.SELL.value
        caption = formatter.signal_caption(snapshot)
        if card_type != ("BUY" if snapshot.is_buy else "SELL") or snapshot.direction != expected \
                or f"<b>{expected}</b>" not in caption:
            log.critical("CRITICAL_DIRECTION_MISMATCH id=%s dir=%s card=%s — NOT sending",
                         sid, snapshot.direction, card_type)
            await self._set_status(sid, SignalStatus.ERROR)
            return
        signal_mid = await self._post_channel(card_type, caption, sid, "signal")
        if signal_mid is None:
            log.error("failed to publish signal id=%s; aborting", sid)
            await self._set_status(sid, SignalStatus.ERROR)
            return
        await self._set_status(sid, SignalStatus.PUBLISHED)
        log.info("SIGNAL published id=%s %s lead=%ss", sid, card_type,
                 int((snapshot.entry_time - utc_now()).total_seconds()))

        # 4. attempts loop (reentry = NEW permanent post)
        attempt_number = 0
        final = AttemptResult.LOSS
        series_start = utc_now()
        entry_time = snapshot.entry_time
        max_attempts = (settings.max_repeats + 1) if settings.repeat_mode else 1

        while attempt_number < max_attempts:
            attempt_number += 1
            try:
                final = await self._run_attempt(snapshot, draft, entry_time, attempt_number)
            except DataUnavailableError as e:
                log.warning("DATA_UNAVAILABLE id=%s: %s", sid, e)
                await self._finalize_unavailable(snapshot, attempt_number)
                return
            if final in (AttemptResult.WIN, AttemptResult.DRAW):
                break
            if attempt_number < max_attempts:
                await self._set_status(sid, SignalStatus.REENTRY_PENDING)
                required_lead = settings.min_signal_lead_seconds
                entry_time = next_entry_time(utc_now(), settings.entry_second, required_lead)
                re_snap = SignalPublicationSnapshot(
                    signal_id=sid, pair=snapshot.pair, direction=snapshot.direction,
                    entry_time=entry_time, expiry_seconds=snapshot.expiry_seconds,
                    timeframe=snapshot.timeframe, market=snapshot.market)
                await self._post_channel(
                    "REENTRY", formatter.reentry_caption(re_snap, attempt_number + 1),
                    sid, "reentry")

        repeats = attempt_number - 1
        await self._finalize(snapshot, final, attempt_number, repeats)

    # ---- trading window: up to MAX_ATTEMPTS entries, one every minute ----
    async def _window_lifecycle(self, snapshot: SignalPublicationSnapshot,
                                draft: SignalDraft, analysis: AnalysisResult) -> None:
        """One window = one published signal and one final result.

        Entry i happens at first_entry + (i-1)*step (step = expiry rounded up
        to whole minutes, so every entry is on the same second, e.g. :30).
        WIN on any entry closes the window as +1. All entries lost = -1.
        Every entry is stored in signal_attempts, so per-entry stats stay honest.
        """
        sid = snapshot.signal_id
        watcher = getattr(self.state.provider, "watch", None)
        if watcher:
            try:
                await watcher(snapshot.pair)   # live ticks = the price trades settle on
            except Exception as e:  # noqa: BLE001
                log.warning("live watch failed: %s", e)
        try:
            await self._window_body(snapshot, draft, analysis)
        finally:
            unw = getattr(self.state.provider, "unwatch", None)
            if unw:
                try:
                    await unw(snapshot.pair)
                except Exception:  # noqa: BLE001
                    pass

    async def _window_body(self, snapshot, draft, analysis) -> None:
        sid = snapshot.signal_id
        from app.services import main_channel
        self.main = main_channel.claim()
        self.main_mid = None
        if self.main:
            log.info("window id=%s is also published in the main channel", sid)
        step = 60 * max(1, -(-snapshot.expiry_seconds // 60))
        plan = formatter.window_plan(snapshot.entry_time, max(1, settings.max_attempts), step)

        if not settings.window_skip_service_posts:
            search_mid = await self._post(
                settings.signal_channel_id, "SEARCH",
                formatter.search_caption(snapshot.timeframe, pairs_count()))
            await asyncio.sleep(settings.search_temp_seconds)
            analysis_mid = await self._post(
                settings.signal_channel_id, "ANALYSIS",
                formatter.analysis_caption(snapshot.pair, snapshot.market, snapshot.timeframe))
            await asyncio.sleep(settings.analysis_temp_seconds)
            await self._delete(search_mid)
            await self._delete(analysis_mid)

        elif settings.window_analysis_card:
            # "АНАЛИЗ СИГНАЛА" card with pair + entry parameters; stays in the channel,
            # the signal card with direction follows after ANALYSIS_TEMP_SECONDS.
            from app.services.engine_control import delete_search_card
            await delete_search_card()
            await self._post_channel("ANALYSIS", formatter.analysis_caption(
                snapshot.pair, snapshot.market, snapshot.timeframe, snapshot.expiry_seconds,
                plan[0].second, len(plan)), sid, "analysis")
            await self._set_status(sid, SignalStatus.CONFIRMING)
            await asyncio.sleep(settings.analysis_temp_seconds)

        card_type = card_type_for(snapshot)
        expected = Direction.BUY.value if snapshot.is_buy else Direction.SELL.value
        caption = formatter.window_start_caption(
            snapshot, plan, analysis.indicators, analysis.score, analysis.engine)
        if snapshot.direction != expected or f"<b>{expected}</b>" not in caption:
            log.critical("CRITICAL_DIRECTION_MISMATCH id=%s — NOT sending", sid)
            await self._set_status(sid, SignalStatus.ERROR)
            return
        from app.services.engine_control import delete_search_card
        await delete_search_card()
        signal_mid = await self._post_channel(card_type, caption, sid, "signal")
        if signal_mid is not None and self.main:
            self.main_mid = await main_channel.post_signal(card_type, snapshot, plan, analysis)
        if signal_mid is None:
            log.error("failed to publish window id=%s; aborting", sid)
            await self._set_status(sid, SignalStatus.ERROR)
            return
        await self._set_status(sid, SignalStatus.PUBLISHED)

        # Payout re-check ~10 s before the first entry (Pocket Option only).
        if not await self._payout_guard(snapshot, analysis, plan[0], signal_mid):
            return
        log.info("WINDOW published id=%s %s %s plan=%s..%s", sid, snapshot.pair,
                 snapshot.direction, plan[0].isoformat(), plan[-1].isoformat())

        history = []
        for i, entry_time in enumerate(plan, start=1):
            if utc_now() > entry_time + timedelta(seconds=2):
                log.warning("window id=%s missed entry %d (late) — stopping", sid, i)
                break
            try:
                res = await self._run_attempt(snapshot, draft, entry_time, i)
            except DataUnavailableError as e:
                log.warning("DATA_UNAVAILABLE id=%s attempt %d: %s", sid, i, e)
                if not history:
                    await self._finalize_unavailable(snapshot, i)
                    return
                # Entries already played are real: close the window with them,
                # otherwise a data glitch would silently erase a losing window.
                break
            history.append((i, entry_time, res.value))
            if res == AttemptResult.WIN:
                break

        results = [r for _, _, r in history]
        if "WIN" in results:
            final = AttemptResult.WIN
        elif "LOSS" in results:
            final = AttemptResult.LOSS
        elif results:
            final = AttemptResult.DRAW
        else:
            await self._finalize_unavailable(snapshot, 1)
            return

        async with get_session() as s:
            sig = await SignalRepository(s).get(sid)
            sig.repeats = len(history) - 1
            sig.final_result = final.value
            sig.status = {AttemptResult.WIN: SignalStatus.WIN, AttemptResult.LOSS: SignalStatus.LOSS,
                          AttemptResult.DRAW: SignalStatus.DRAW}[final].value
            await s.commit()
        caption = formatter.window_result_caption(snapshot, final.value, history, plan)
        if final == AttemptResult.DRAW:
            # there is no DRAW card image — never show the WIN picture on a draw
            await self._post_text_channel(caption, sid, "result")
        else:
            card = "LOSS" if final == AttemptResult.LOSS else "WIN"
            await self._post_channel(card, caption, sid, "result")
        log.info("WINDOW RESULT %s id=%s entries=%d", final.value, sid, len(history))
        if self.main and self.main_mid:
            asyncio.create_task(main_channel.post_result(
                snapshot, final.value, history, plan, analysis, self.main_mid))
        from app.analytics.timing import timing
        await timing.record_window(snapshot.timeframe, snapshot.pair, snapshot.direction,
                                   plan[0].second, "".join(r[0] for r in results),
                                   (analysis.indicators or {}).get("atr_pct"), "live")

        from app.scheduler.engine_loop import _notify_admins
        from app.statistics import rolling
        try:
            await rolling.on_result(self.state.mode.value, snapshot.pair, notify=_notify_admins)
        except Exception as e:  # noqa: BLE001
            log.warning("rolling update failed: %s", e)

    async def _payout_guard(self, snapshot: SignalPublicationSnapshot, analysis: AnalysisResult,
                            entry_time, signal_mid: int) -> bool:
        """Re-check payout shortly before entry.

        below OTC_MIN_PAYOUT (or asset closed) -> cancel: SKIPPED card, status CANCELLED,
                                                   not counted in statistics
        dropped but still OK                    -> short warning as a reply to the signal
        unchanged / not available               -> nothing
        Returns False when the signal was cancelled.
        """
        getter = getattr(self.state.provider, "current_payout", None)
        was = (analysis.indicators or {}).get("payout")
        if not getter:
            return True
        delay = (entry_time - utc_now()).total_seconds() - 10
        if delay > 0:
            await asyncio.sleep(delay)
        now = await getter(snapshot.pair)
        if now is None:
            return True
        pair = formatter.pair_label(snapshot.pair)
        if now < settings.otc_min_payout or now == 0:
            reason = (f"выплата по <code>{pair}</code> упала до <b>{now}%</b>" if now
                      else f"пара <code>{pair}</code> закрыта брокером")
            await self._post_channel("SKIPPED", formatter.skipped_caption(
                snapshot.pair, reason + " — вход отменён"), snapshot.signal_id, "cancel")
            await self._set_status(snapshot.signal_id, SignalStatus.CANCELLED)
            log.info("CANCELLED id=%s: payout %s%% < %s%%", snapshot.signal_id, now,
                     settings.otc_min_payout)
            return False
        if was and now < was:
            try:
                await self.state.bot.send_message(
                    settings.signal_channel_id,
                    f"⚠️ <b>Выплата снизилась:</b> <code>{was}%</code> → <code>{now}%</code>\n"
                    "<i>Вход в силе — работаем по плану.</i>",
                    parse_mode="HTML", reply_to_message_id=signal_mid)
            except Exception as e:  # noqa: BLE001
                log.warning("payout warning failed: %s", e)
        return True

    async def _run_attempt(self, snapshot: SignalPublicationSnapshot, draft: SignalDraft,
                          entry_time, attempt_number: int) -> AttemptResult:
        st = self.state
        sid = snapshot.signal_id
        await self._set_status(sid, SignalStatus.WAITING_ENTRY)
        exit_time = entry_time + timedelta(seconds=snapshot.expiry_seconds)
        tape = None
        if settings.shadow_enabled and getattr(st.provider, "name", "") in ("pocketoption", "mock"):
            # price tape for shadow entry seconds (:25..:35); never published
            from app.analytics.shadow import PriceTape
            lead = max(0, entry_time.second - settings.shadow_seconds_from) + 1
            await wait_until(entry_time - timedelta(seconds=lead))
            from app.analytics.shadow import max_duration
            tape = PriceTape(st.provider, draft.symbol)
            tape.start(entry_time + timedelta(seconds=max(
                snapshot.expiry_seconds, max_duration(),
                settings.shadow_seconds_to - entry_time.second + snapshot.expiry_seconds) + 3))
        await wait_until(entry_time)

        # entry quote at entry_time from the SAME provider (not M1 close)
        entry = await capture_price(st.provider, draft.symbol)
        await self._set_status(sid, SignalStatus.WAITING_RESULT)

        # Keep the quote cache warm only for cheap streaming providers; REST-metered
        # providers (Twelve Data) are queried just at entry and exit.
        warm = getattr(st.provider, "name", "") in ("pocketoption", "mock")
        while utc_now() < exit_time:
            if warm:
                await st.provider.get_current_quote(draft.symbol)
            await asyncio.sleep(min(1.0, max(0.2, snapshot.expiry_seconds / 10)))

        exit_cap = await capture_price(st.provider, draft.symbol)
        result = resolve(snapshot.direction, entry.price, exit_cap.price)

        async with get_session() as s:
            await SignalRepository(s).add_attempt(
                sid, attempt_number, entry_time=entry_time, exit_time=exit_time,
                entry_price=entry.price, exit_price=exit_cap.price,
                entry_provider_ts=entry.provider_timestamp,
                exit_provider_ts=exit_cap.provider_timestamp, result=result.value)
            await s.commit()
        src = getattr(st.provider._quotes.get(draft.symbol), "source", "?") \
            if hasattr(st.provider, "_quotes") else "?"
        log.info("attempt %d id=%s %s entry=%.5f exit=%.5f src=%s", attempt_number, sid,
                 result.value, entry.price, exit_cap.price, src)
        from app.analytics.timing import timing
        await timing.record(entry_time, entry_time.second, snapshot.pair, snapshot.timeframe,
                            result.value, "live")
        if tape is not None:
            asyncio.create_task(self._shadow_seconds(tape, snapshot, entry_time))
        return result

    async def _shadow_seconds(self, tape, snapshot, entry_time) -> None:
        from app.analytics.shadow import evaluate_entry_seconds
        try:
            from app.analytics.shadow import evaluate_durations, max_duration
            end = entry_time + timedelta(seconds=max(
                snapshot.expiry_seconds, max_duration(),
                settings.shadow_seconds_to - entry_time.second + snapshot.expiry_seconds) + 3)
            await asyncio.sleep(max(0.0, (end - utc_now()).total_seconds()))
            await tape.stop()
            await evaluate_durations(tape, snapshot.direction, snapshot.pair,
                                     snapshot.timeframe, entry_time, "live")
            n = await evaluate_entry_seconds(tape, snapshot.direction, snapshot.pair,
                                             snapshot.timeframe, entry_time,
                                             snapshot.expiry_seconds)
            log.debug("shadow seconds recorded: %d", n)
        except Exception as e:  # noqa: BLE001
            log.warning("shadow seconds failed: %s", e)

    async def _finalize(self, snapshot: SignalPublicationSnapshot, result: AttemptResult,
                       attempt_number: int, repeats: int) -> None:
        status_map = {AttemptResult.WIN: SignalStatus.WIN,
                      AttemptResult.LOSS: SignalStatus.LOSS,
                      AttemptResult.DRAW: SignalStatus.DRAW}
        async with get_session() as s:
            repo = SignalRepository(s)
            sig = await repo.get(snapshot.signal_id)
            sig.repeats = repeats
            sig.final_result = result.value
            sig.status = status_map[result].value
            await s.commit()
        caption = formatter.result_caption(snapshot, result.value, attempt_number, repeats)
        if result.value in ("WIN", "LOSS"):
            await self._post_channel(result.value, caption, snapshot.signal_id, "result")
        else:
            await self._post_text_channel(caption, snapshot.signal_id, "result")
        log.info("RESULT %s id=%s repeats=%d", result.value, snapshot.signal_id, repeats)
        from app.scheduler.engine_loop import _notify_admins
        from app.statistics import rolling
        try:
            await rolling.on_result(self.state.mode.value, snapshot.pair, notify=_notify_admins)
        except Exception as e:  # noqa: BLE001
            log.warning("rolling update failed: %s", e)

    async def _finalize_unavailable(self, snapshot: SignalPublicationSnapshot,
                                   attempt_number: int) -> None:
        await self._set_status(snapshot.signal_id, SignalStatus.DATA_UNAVAILABLE)
        async with get_session() as s:
            sig = await SignalRepository(s).get(snapshot.signal_id)
            sig.final_result = None
            await s.commit()
        await self._post_channel(
            "SKIPPED",
            formatter.result_caption(snapshot, "DATA_UNAVAILABLE", attempt_number, 0),
            snapshot.signal_id, "result")

    async def _set_status(self, signal_id: int, status: SignalStatus) -> None:
        async with get_session() as s:
            await SignalRepository(s).update_status(signal_id, status.value)
            await s.commit()

    async def _save_message(self, signal_id: int, message_id: int, kind: str) -> None:
        async with get_session() as s:
            await TelegramMessageRepository(s).save(
                signal_id, settings.signal_channel_id, message_id, kind)
            await s.commit()
