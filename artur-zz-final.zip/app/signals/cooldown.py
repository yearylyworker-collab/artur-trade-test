"""Cooldown & concurrency tracking (in-memory, per mode)."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Dict

from app.config import settings


class CooldownManager:
    def __init__(self):
        self._pair_until: Dict[str, datetime] = {}
        self._global_until: datetime | None = None

    def _now(self) -> datetime:
        return datetime.now(timezone.utc)

    def pair_ready(self, symbol: str) -> bool:
        until = self._pair_until.get(symbol)
        return until is None or self._now() >= until

    def global_ready(self) -> bool:
        return self._global_until is None or self._now() >= self._global_until

    def ready(self, symbol: str) -> bool:
        return self.global_ready() and self.pair_ready(symbol)

    def arm(self, symbol: str) -> None:
        now = self._now()
        self._pair_until[symbol] = now + timedelta(minutes=settings.pair_cooldown_minutes)
        self._global_until = now + timedelta(seconds=settings.global_signal_cooldown_seconds)
