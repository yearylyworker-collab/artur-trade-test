"""Signal generator: turns an AnalysisResult into a SignalDraft."""
from __future__ import annotations

from datetime import datetime, timezone

from app.config import settings
from app.core.enums import MarketType, Mode
from app.core.models import AnalysisResult
from app.core.time_utils import next_entry_time, utc_now
from app.signals.models import SignalDraft


def resolve_expiry(provider_supports_short: bool) -> int:
    """Short expiry only if allowed AND provider has a fast quote stream."""
    if settings.allow_short_expiry and provider_supports_short:
        return settings.short_expiry_seconds
    return settings.default_expiry_seconds


def build_draft(analysis: AnalysisResult, mode: Mode, provider: str,
                provider_supports_short: bool) -> SignalDraft:
    now = utc_now()
    entry = next_entry_time(now, settings.entry_second, settings.min_seconds_before_entry)
    expiry = resolve_expiry(provider_supports_short)
    audit = {
        "score": analysis.score,
        "filters": [
            {"name": f.name, "passed": f.passed, "score": f.score, "reason": f.reason}
            for f in analysis.filters
        ],
        "ha": analysis.ha_snapshot,
        "candle_timestamp": analysis.candle_timestamp.isoformat() if analysis.candle_timestamp else None,
        "engine": analysis.engine,
        "regime": analysis.regime,
        "indicators": analysis.indicators,
        "ml_prob": analysis.ml_prob,
        "ml_features": analysis.ml_features,
    }
    return SignalDraft(
        mode=mode.value,
        symbol=analysis.symbol,
        market=(MarketType.OTC.value if analysis.symbol.lower().endswith("_otc")
                else MarketType.FOREX.value),
        direction=analysis.direction,
        score=analysis.score,
        timeframe=settings.default_timeframe,
        entry_time=entry,
        expiry_seconds=expiry,
        provider=provider,
        audit=audit,
    )


def seconds_until_entry(draft: SignalDraft) -> float:
    return (draft.entry_time - utc_now()).total_seconds()
