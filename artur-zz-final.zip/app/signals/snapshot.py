"""Immutable publication snapshot — the single source of truth for direction.

Both the static card selection and the caption formatter MUST read from this
snapshot, never from mutable/global market state, to avoid card/caption
direction mismatches (see 05_DIRECTION_SYNC_CRITICAL).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from app.core.enums import Direction


@dataclass(frozen=True)
class SignalPublicationSnapshot:
    signal_id: int
    pair: str
    direction: str  # "BUY" | "SELL"
    entry_time: datetime
    expiry_seconds: int
    timeframe: str
    market: str

    @property
    def is_buy(self) -> bool:
        return self.direction == Direction.BUY.value


DIRECTION_META = {
    Direction.BUY.value: {"card": "BUY", "text": "BUY", "emoji": "🟢", "arrow": "↑"},
    Direction.SELL.value: {"card": "SELL", "text": "SELL", "emoji": "🔴", "arrow": "↓"},
}


def card_type_for(snapshot: SignalPublicationSnapshot) -> str:
    return DIRECTION_META[snapshot.direction]["card"]
