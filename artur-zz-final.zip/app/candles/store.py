"""Per-symbol candle store with validation."""
from __future__ import annotations

from collections import deque
from datetime import datetime, timezone
from typing import Dict, List, Optional

from app.candles.models import Candle
from app.core.logging_config import get_logger

log = get_logger("candles.store")


class CandleStore:
    def __init__(self, limit: int = 200):
        self.limit = limit
        self._candles: Dict[str, deque] = {}
        self._last_processed: Dict[str, datetime] = {}

    def replace(self, symbol: str, candles: List[Candle]) -> None:
        clean = self._sanitize(candles)
        self._candles[symbol] = deque(clean, maxlen=self.limit)

    def add_or_update(self, symbol: str, candle: Candle) -> None:
        if not candle.is_valid():
            log.warning("invalid candle rejected %s %s", symbol, candle.timestamp)
            return
        dq = self._candles.setdefault(symbol, deque(maxlen=self.limit))
        if dq and dq[-1].timestamp == candle.timestamp:
            dq[-1] = candle  # update forming candle
        elif dq and candle.timestamp < dq[-1].timestamp:
            return  # out of order, ignore
        else:
            dq.append(candle)

    def get(self, symbol: str) -> List[Candle]:
        return list(self._candles.get(symbol, []))

    def count(self, symbol: str) -> int:
        return len(self._candles.get(symbol, []))

    def last(self, symbol: str) -> Optional[Candle]:
        dq = self._candles.get(symbol)
        return dq[-1] if dq else None

    def last_closed(self, symbol: str) -> Optional[Candle]:
        """Return the most recent fully-closed candle (second to last)."""
        dq = self._candles.get(symbol)
        if not dq or len(dq) < 2:
            return None
        return dq[-2]

    # --- last processed tracking ---
    def last_processed(self, symbol: str) -> Optional[datetime]:
        return self._last_processed.get(symbol)

    def mark_processed(self, symbol: str, ts: datetime) -> None:
        self._last_processed[symbol] = ts

    def _sanitize(self, candles: List[Candle]) -> List[Candle]:
        seen = set()
        out: List[Candle] = []
        for c in sorted(candles, key=lambda x: x.timestamp):
            if c.timestamp in seen:
                continue
            if not c.is_valid():
                continue
            seen.add(c.timestamp)
            out.append(c)
        return out
