"""Heikin Ashi calculation — the core of the system."""
from __future__ import annotations

from typing import List

from app.candles.models import Candle, HACandle
from app.core.enums import HADirection

# Bodies smaller than this fraction of the candle range are "neutral".
NEUTRAL_BODY_RATIO = 0.1


def _direction(ha_open: float, ha_close: float, rng: float) -> HADirection:
    body = abs(ha_close - ha_open)
    if rng > 0 and body / rng < NEUTRAL_BODY_RATIO:
        return HADirection.NEUTRAL
    if ha_close > ha_open:
        return HADirection.BULLISH
    if ha_close < ha_open:
        return HADirection.BEARISH
    return HADirection.NEUTRAL


def compute_heikin_ashi(candles: List[Candle]) -> List[HACandle]:
    """Compute HA candles locally from raw OHLC candles."""
    ha: List[HACandle] = []
    prev_ha_open = None
    prev_ha_close = None

    for c in candles:
        ha_close = (c.open + c.high + c.low + c.close) / 4.0
        if prev_ha_open is None:
            ha_open = (c.open + c.close) / 2.0
        else:
            ha_open = (prev_ha_open + prev_ha_close) / 2.0

        ha_high = max(c.high, ha_open, ha_close)
        ha_low = min(c.low, ha_open, ha_close)
        rng = ha_high - ha_low
        body = abs(ha_close - ha_open)
        upper_wick = ha_high - max(ha_open, ha_close)
        lower_wick = min(ha_open, ha_close) - ha_low

        ha.append(
            HACandle(
                timestamp=c.timestamp,
                ha_open=ha_open,
                ha_high=ha_high,
                ha_low=ha_low,
                ha_close=ha_close,
                direction=_direction(ha_open, ha_close, rng),
                body_size=body,
                upper_wick=max(0.0, upper_wick),
                lower_wick=max(0.0, lower_wick),
            )
        )
        prev_ha_open = ha_open
        prev_ha_close = ha_close

    return ha
