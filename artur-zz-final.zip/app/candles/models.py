"""Candle & Heikin-Ashi dataclasses."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from app.core.enums import HADirection


@dataclass
class Candle:
    symbol: str
    timestamp: datetime  # UTC, candle open time
    open: float
    high: float
    low: float
    close: float
    timeframe: str = "M1"
    source: str = "mock"
    volume: Optional[float] = None

    def is_valid(self) -> bool:
        if min(self.open, self.high, self.low, self.close) <= 0:
            return False
        if self.high < self.low:
            return False
        if self.high < max(self.open, self.close):
            return False
        if self.low > min(self.open, self.close):
            return False
        return True


@dataclass
class HACandle:
    timestamp: datetime
    ha_open: float
    ha_high: float
    ha_low: float
    ha_close: float
    direction: HADirection
    body_size: float
    upper_wick: float
    lower_wick: float

    @property
    def range(self) -> float:
        return self.ha_high - self.ha_low
