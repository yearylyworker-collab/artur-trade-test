"""Candle sub-package."""
