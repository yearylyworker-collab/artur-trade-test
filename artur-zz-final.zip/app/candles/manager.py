"""Candle manager: holds store + computes HA per symbol."""
from __future__ import annotations

from typing import Dict, List

from app.candles.heikin_ashi import compute_heikin_ashi
from app.candles.models import Candle, HACandle
from app.candles.store import CandleStore


class CandleManager:
    def __init__(self, limit: int = 200):
        self.store = CandleStore(limit=limit)

    def set_history(self, symbol: str, candles: List[Candle]) -> None:
        self.store.replace(symbol, candles)

    def update(self, symbol: str, candle: Candle) -> None:
        self.store.add_or_update(symbol, candle)

    def candles(self, symbol: str) -> List[Candle]:
        return self.store.get(symbol)

    def ha(self, symbol: str) -> List[HACandle]:
        return compute_heikin_ashi(self.store.get(symbol))

    def all_ha(self, symbols: List[str]) -> Dict[str, List[HACandle]]:
        return {s: self.ha(s) for s in symbols}
