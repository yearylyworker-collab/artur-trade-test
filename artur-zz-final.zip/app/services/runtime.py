"""Runtime trading parameters (timeframe, entry second, window length).

They start from environment settings, can be changed by the AdaptiveEngine or
by admin commands, and survive restarts (runtime/params.json).

The live values are written back into ``settings`` so every existing module
(signal manager, formatter, candle refresh) follows them automatically.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Optional

from app.config import settings
from app.core.logging_config import get_logger

log = get_logger("services.runtime")

PARAMS_FILE = Path("./runtime/params.json")

TF_SECONDS: Dict[str, int] = {"S30": 30, "M1": 60, "M5": 300}


def tf_seconds(tf: str) -> int:
    return TF_SECONDS.get(tf.upper(), 60)


def expiry_for(tf: str) -> int:
    """Trade duration: TRADE_SECONDS if set (e.g. 5 s on an M1 chart),
    otherwise equal to the timeframe (S30 -> 30 s, M1 -> 60 s, M5 -> 300 s)."""
    if settings.trade_seconds and settings.trade_seconds > 0:
        return int(settings.trade_seconds)
    if settings.trade_seconds_auto and tf.upper() in AUTO_DURATION:
        return AUTO_DURATION[tf.upper()]
    return tf_seconds(tf)


# timeframe -> trade length chosen from statistics (duration_stats)
AUTO_DURATION: Dict[str, int] = {}
DURATION_REASON: Dict[str, str] = {}


def apply_duration(tf: str, seconds: int, reason: str) -> None:
    tf = tf.upper()
    AUTO_DURATION[tf] = int(seconds)
    DURATION_REASON[tf] = reason
    if tf == settings.default_timeframe.upper():
        settings.default_expiry_seconds = expiry_for(tf)
    log.info("trade duration %s applied: %s s (%s)", tf, seconds, reason)
    save()


def choose_duration(tf: Optional[str] = None, apply_now: bool = True) -> Optional[tuple]:
    """Pick the trade length with the best winrate for the timeframe.

    Needs DURATION_MIN_SAMPLES per length; switches only when the new length is
    better than the current one by DURATION_SWITCH_MARGIN (no flapping).
    Returns (old, new, reason) when it changed, else None.
    """
    if not settings.trade_seconds_auto or settings.trade_seconds > 0:
        return None
    from app.analytics.timing import timing
    tf = (tf or settings.default_timeframe).upper()
    stats = [r for r in timing.duration_stats(tf) if r[2] >= settings.duration_min_samples]
    if not stats:
        return None
    best = max(stats, key=lambda r: (r[1], -r[0]))
    old = expiry_for(tf)
    cur = next((r for r in stats if r[0] == old), None)
    if best[0] == old or (cur and best[1] - cur[1] < settings.duration_switch_margin):
        return None
    reason = (f"{best[0]} сек: {best[1] * 100:.0f}% прибыльных ({best[2]} замеров)"
              + (f" против {cur[1] * 100:.0f}% на {old} сек" if cur else ""))
    if apply_now:
        apply_duration(tf, best[0], reason)
    return old, best[0], reason


def set_trade_seconds(seconds: int) -> None:
    settings.trade_seconds = max(0, int(seconds))
    settings.default_expiry_seconds = expiry_for(settings.default_timeframe)
    save()


def provider_timeframes() -> list:
    """Timeframes the current provider can serve (Twelve Data has no S30)."""
    tfs = [t.upper() for t in settings.timeframes_to_analyze if t.upper() in TF_SECONDS]
    if settings.market_provider.lower() != "pocket":
        tfs = [t for t in tfs if t != "S30"]
    return tfs or ["M1"]


def current() -> dict:
    return {
        "timeframe": settings.default_timeframe.upper(),
        "entry_second": int(settings.entry_second),
        "window_length": int(settings.max_attempts),
        "adaptive": bool(settings.adaptive_enabled),
        "trade_seconds": int(settings.trade_seconds),
        "auto_duration": dict(AUTO_DURATION),
    }


def apply(timeframe: Optional[str] = None, entry_second: Optional[int] = None,
          window_length: Optional[int] = None, adaptive: Optional[bool] = None,
          persist: bool = True) -> dict:
    """Change live parameters. Returns {name: (old, new)} of what changed."""
    before = current()
    tf_changed = False
    if timeframe:
        tf = timeframe.upper()
        if tf not in TF_SECONDS:
            raise ValueError(f"unknown timeframe {timeframe}")
        if tf != settings.default_timeframe.upper():
            tf_changed = True
        settings.default_timeframe = tf
        settings.default_expiry_seconds = expiry_for(tf)
    if entry_second is not None:
        if not 0 <= int(entry_second) <= 59:
            raise ValueError("entry second must be 0..59")
        settings.entry_second = int(entry_second)
    if window_length is not None:
        settings.max_attempts = max(1, min(5, int(window_length)))
    if adaptive is not None:
        settings.adaptive_enabled = bool(adaptive)
    settings.default_expiry_seconds = expiry_for(settings.default_timeframe)
    after = current()
    changed = {k: (before[k], after[k]) for k in after if before[k] != after[k]}
    if changed:
        log.info("runtime params changed: %s", changed)
    if tf_changed:
        try:
            from app.scheduler.engine_loop import reset_candles
            reset_candles()
        except Exception as e:  # noqa: BLE001
            log.warning("candle reset failed: %s", e)
    if persist and changed:
        save()
    return changed


def save() -> None:
    try:
        PARAMS_FILE.parent.mkdir(parents=True, exist_ok=True)
        PARAMS_FILE.write_text(json.dumps(current()), encoding="utf-8")
    except OSError as e:
        log.warning("params save failed: %s", e)


def load() -> None:
    """Restore last parameters (called on startup). Missing file = env defaults."""
    settings.default_expiry_seconds = expiry_for(settings.default_timeframe)
    if not PARAMS_FILE.exists():
        return
    try:
        data = json.loads(PARAMS_FILE.read_text(encoding="utf-8"))
        if data.get("trade_seconds") is not None:
            settings.trade_seconds = int(data["trade_seconds"])
        AUTO_DURATION.update({k: int(v) for k, v in (data.get("auto_duration") or {}).items()})
        tf = data.get("timeframe")
        if tf and tf.upper() not in provider_timeframes():
            tf = None
        apply(timeframe=tf, entry_second=data.get("entry_second"),
              window_length=data.get("window_length"), adaptive=data.get("adaptive"),
              persist=False)
        log.info("runtime params restored: %s", current())
    except Exception as e:  # noqa: BLE001
        log.warning("params load failed: %s", e)
