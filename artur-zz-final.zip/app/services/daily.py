"""Daily statistics: ONE card per day, right after midnight (Ukraine time),
covering the whole previous day 00:00–24:00. The sent date is remembered in
runtime/daily_stats_date, so restarts never send it twice."""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
from pathlib import Path

from app.analytics.timing import analytics_tz
from app.config import settings
from app.core.logging_config import get_logger
from app.services.state import state

log = get_logger("services.daily")
MARK = Path("./runtime/daily_stats_date")


def _targets() -> list:
    t = settings.daily_stats_target.lower()
    out = []
    if t in ("admin", "both"):
        out += list(settings.admin_ids)
    if t in ("channel", "both") and settings.signal_channel_id:
        out.append(settings.signal_channel_id)
    return out


async def send_daily(kind: str = "yesterday", chats: list | None = None) -> bool:
    from aiogram.types import FSInputFile
    from app.analytics.reports import daily_card
    if not state.bot:
        return False
    path, caption = await daily_card(kind)
    ok = False
    for chat in chats if chats is not None else _targets():
        try:
            # album: static "СТАТИСТИКА ЗА ДЕНЬ" card + card with the numbers drawn in
            from aiogram.types import InputMediaPhoto
            from app.cards.static_registry import CARDS_DIR, CARD_FILES
            await state.bot.send_media_group(chat, [
                InputMediaPhoto(media=FSInputFile(CARDS_DIR / CARD_FILES["STATISTICS"]),
                                caption=caption, parse_mode="HTML"),
                InputMediaPhoto(media=FSInputFile(path)),
            ])
            ok = True
        except Exception as e:  # noqa: BLE001
            log.warning("daily stats to %s failed: %s", chat, e)
    return ok


async def daily_stats_loop() -> None:
    log.info("daily stats loop started (target=%s)", settings.daily_stats_target)
    while True:
        try:
            tz = analytics_tz()
            now = datetime.now(tz)
            nxt = (now + timedelta(days=1)).replace(hour=0, minute=1, second=0, microsecond=0)
            await asyncio.sleep(max(30.0, (nxt - now).total_seconds()))
            if not settings.daily_stats:
                continue
            day = (datetime.now(tz) - timedelta(days=1)).strftime("%Y-%m-%d")
            try:
                if MARK.read_text().strip() == day:
                    continue
            except OSError:
                pass
            if await send_daily("yesterday"):
                MARK.parent.mkdir(parents=True, exist_ok=True)
                MARK.write_text(day)
                log.info("daily stats sent for %s", day)
        except asyncio.CancelledError:
            raise
        except Exception as e:  # noqa: BLE001
            log.warning("daily stats loop error: %s", e)
            await asyncio.sleep(60)
