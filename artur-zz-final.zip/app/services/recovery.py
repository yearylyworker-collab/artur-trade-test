"""Restart recovery: resolve or mark orphaned in-flight signals."""
from __future__ import annotations

from app.core.enums import SignalStatus
from app.core.logging_config import get_logger
from app.database.repositories.repos import SignalRepository
from app.database.session import get_session

log = get_logger("services.recovery")


async def recover_active_signals(mode: str) -> None:
    """On startup, any non-terminal signal from a previous run that we cannot
    resolve deterministically is marked DATA_UNAVAILABLE (never fabricated)."""
    async with get_session() as s:
        repo = SignalRepository(s)
        active = await repo.active_signals(mode)
        for sig in active:
            log.warning("recovering orphaned signal id=%s status=%s", sig.id, sig.status)
            sig.status = SignalStatus.DATA_UNAVAILABLE.value
            if not sig.final_result:
                sig.final_result = None
        if active:
            await s.commit()
        log.info("recovery complete: %d orphaned signal(s) handled", len(active))
