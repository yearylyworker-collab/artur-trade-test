"""Health snapshot for /status."""
from __future__ import annotations

from datetime import datetime, timezone

from app.services.state import state


async def snapshot() -> dict:
    provider = state.provider
    last_quote_age = None
    pairs = 0
    ws = False
    if provider:
        symbols = await provider.get_symbols()
        pairs = len(symbols)
        ages = [provider.get_quote_age(s) for s in symbols]
        ages = [a for a in ages if a is not None]
        if ages:
            last_quote_age = round(min(ages), 1)
        ws = bool(getattr(provider, "ws_connected", False))
    return {
        "mode": state.mode.value,
        "telegram": "ONLINE" if state.bot else "OFFLINE",
        "channel": "CONNECTED" if state.channel_ok else "NOT CONNECTED",
        "provider": "ONLINE" if state.provider_online else "OFFLINE",
        "websocket": "CONNECTED" if ws else "N/A",
        "pairs": pairs,
        "last_quote_age": last_quote_age,
        "engine": "ACTIVE" if state.engine_on else "STOPPED",
        "current_signal": state.active_signal_id or "NONE",
        "signals_today": state.signals_today,
        "server_time": datetime.now(timezone.utc).astimezone().strftime("%H:%M:%S"),
    }
