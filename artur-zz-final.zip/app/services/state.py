"""Global application state shared across bot handlers & scheduler."""
from __future__ import annotations

from typing import Optional

from aiogram import Bot

from app.analysis.engine import AnalysisEngine
from app.candles.manager import CandleManager
from app.cards.renderer import CardRenderer, get_renderer
from app.config import settings
from app.core.enums import Mode
from app.core.logging_config import get_logger
from app.market.base import MarketDataProvider
from app.market.manager import build_provider
from app.publisher.queue import TelegramPublicationQueue
from app.publisher.telegram import TelegramPublisher
from app.cards.static_registry import StaticCardRegistry
from app.signals.cooldown import CooldownManager
from app.engines.arbitrage import ArbitrageEngine

log = get_logger("services.state")


class AppState:
    def __init__(self):
        self.mode: Mode = Mode.LIVE if settings.is_live else Mode.DEMO
        self.engine_on: bool = False
        self.bot: Optional[Bot] = None
        self.provider: Optional[MarketDataProvider] = None
        self.candles = CandleManager(limit=settings.candle_history_limit)
        self.analysis = AnalysisEngine(min_score=settings.min_signal_score)
        self.renderer: CardRenderer = get_renderer()
        self.publisher: Optional[TelegramPublisher] = None
        self.queue: Optional[TelegramPublicationQueue] = None
        self.cards: Optional[StaticCardRegistry] = None
        self.cooldown = CooldownManager()
        self.arbitrage = ArbitrageEngine()
        self.channel_ok: bool = False
        self.provider_online: bool = False
        self.active_signal_id: Optional[int] = None
        self.auto_demo: bool = False
        self.signals_today: int = 0
        self.search_mid: Optional[int] = None   # current "bot is searching" post
        self.diag: dict = {}                     # last refresh / analysis cycle (for /diag)
        self.started_at: float = __import__("time").time()
        self.shadow = None                       # ShadowRunner (analytics.shadow)
        self.adaptive = None                     # AdaptiveEngine (engines.adaptive)
        self.counters: dict = {}                 # plus/minus totals for captions
        self.fallback_active: bool = False       # Pocket down -> Forex
        self.provider_error: str = ""

    def init_telegram(self, bot: Bot) -> None:
        self.bot = bot
        if settings.signal_channel_id:
            self.publisher = TelegramPublisher(bot, settings.signal_channel_id)
            self.queue = TelegramPublicationQueue(self.publisher)
            self.cards = StaticCardRegistry(bot, settings.signal_channel_id)

    async def build_and_connect_provider(self) -> bool:
        self.provider = build_provider(self.mode.value)
        try:
            await self.provider.connect()
            self.provider_online = True
            return True
        except Exception as e:  # noqa: BLE001
            log.error("Provider connect failed: %s", e)
            self.provider_online = False
            return False

    @property
    def is_busy(self) -> bool:
        return self.active_signal_id is not None


state = AppState()
