"""Forex fallback: Pocket Option unavailable -> Twelve Data, then back.

* On start-up (or a failed reconnect) with MARKET_PROVIDER=pocket, if Pocket
  Option cannot connect and FOREX_API_KEY is set, the bot switches to Forex so
  the channel keeps working. Admins get a DM.
* If Pocket Option goes offline for FALLBACK_AFTER_SECONDS while running, the
  same switch happens.
* Every FALLBACK_RETRY_MINUTES the bot tries Pocket Option again and returns
  to it (only between windows, never in the middle of a trade).
S30 does not exist on Forex, so the timeframe is temporarily M1 (not saved).
"""
from __future__ import annotations

import asyncio
import time

from app.config import settings
from app.core.logging_config import get_logger
from app.services.state import state

log = get_logger("services.fallback")

_saved_tf: str | None = None


def _eligible() -> bool:
    return (settings.fallback_enabled and settings.is_pocket and state.mode.value == "LIVE"
            and bool(settings.forex_api_key.strip()))


async def _notify(text: str) -> None:
    from app.scheduler.engine_loop import _notify_admins
    await _notify_admins(text)


async def try_fallback(reason: str) -> bool:
    """Switch to Forex. True if Forex is connected."""
    global _saved_tf
    if not _eligible():
        return False
    from app.market.manager import build_provider
    from app.services import runtime
    try:
        if state.provider:
            await state.provider.disconnect()
    except Exception:  # noqa: BLE001
        pass
    prov = build_provider("LIVE", override="forex")
    try:
        await prov.connect()
    except Exception as e:  # noqa: BLE001
        log.error("forex fallback connect failed: %s", e)
        return False
    if settings.default_timeframe.upper() == "S30":
        _saved_tf = "S30"
        runtime.apply(timeframe="M1", persist=False)
    state.provider = prov
    state.provider_online = True
    state.fallback_active = True
    log.warning("FALLBACK -> Forex (reason: %s)", reason)
    try:
        await prov.subscribe_quotes(await prov.get_symbols())
    except Exception as e:  # noqa: BLE001
        log.warning("forex subscribe failed: %s", e)
    await _notify("⚠️ Pocket Option недоступен — переключился на Forex (Twelve Data).\n"
                  f"Причина: {reason[:200]}\n"
                  f"Повторю попытку через {settings.fallback_retry_minutes} мин. "
                  "Если сессия истекла — обнови POCKET_SSID в Railway.")
    return True


async def _try_return() -> None:
    global _saved_tf
    from app.market.manager import build_provider
    from app.services import runtime
    prov = build_provider("LIVE")
    try:
        await prov.connect()
    except Exception as e:  # noqa: BLE001
        log.info("pocket still unavailable: %s", e)
        state.provider_error = str(e)[:200]
        try:
            await prov.disconnect()
        except Exception:  # noqa: BLE001
            pass
        return
    old = state.provider
    state.provider = prov
    state.provider_online = True
    state.fallback_active = False
    state.provider_error = ""
    if _saved_tf:
        runtime.apply(timeframe=_saved_tf, persist=False)
        _saved_tf = None
    try:
        await old.disconnect()
    except Exception:  # noqa: BLE001
        pass
    from app.scheduler.engine_loop import reset_candles
    reset_candles()
    log.warning("Pocket Option is back — fallback off")
    await _notify("✅ Pocket Option снова доступен — вернулся на OTC.")


async def fallback_loop() -> None:
    offline_since: float | None = None
    last_retry = time.monotonic()
    while True:
        await asyncio.sleep(15)
        try:
            if not _eligible():
                continue
            if state.fallback_active:
                if state.is_busy:
                    continue
                if time.monotonic() - last_retry >= settings.fallback_retry_minutes * 60:
                    last_retry = time.monotonic()
                    await _try_return()
                continue
            if state.provider_online:
                offline_since = None
                continue
            offline_since = offline_since or time.monotonic()
            if time.monotonic() - offline_since >= settings.fallback_after_seconds \
                    and not state.is_busy:
                if await try_fallback(state.provider_error or "нет связи с Pocket Option"):
                    from app.scheduler.engine_loop import reset_candles
                    reset_candles()
                    last_retry = time.monotonic()
                offline_since = None
        except Exception as e:  # noqa: BLE001
            log.warning("fallback loop error: %s", e)
