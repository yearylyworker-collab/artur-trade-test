"""Channel monitor: every Telegram API call to a channel is recorded.

A request middleware on the bot session sees ALL outgoing calls (cards, texts,
videos, deletes), so nothing needs to be wired per call site. For each channel:
posts today, last success, error count, last errors. Every 10 minutes the bot
also checks it is still an admin who can post. Problems are sent to admins
(at most once per 30 min per channel). /channels shows the report.
"""
from __future__ import annotations

import asyncio
import html
import json
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Any, Deque, Dict

from app.config import settings
from app.core.logging_config import get_logger

log = get_logger("services.chanmon")
FILE = Path("./runtime/chanmon.json")

_stats: Dict[str, Dict[str, Any]] = {}
_errors: Dict[str, Deque] = {}
_last_alert: Dict[str, float] = {}
_perm: Dict[str, str] = {}
_TRACKED = ("SendPhoto", "SendMessage", "SendAnimation", "SendMediaGroup", "SendVideo",
            "DeleteMessage", "EditMessageText", "EditMessageCaption")


def channels() -> Dict[str, str]:
    out = {}
    if settings.signal_channel_id:
        out[str(settings.signal_channel_id)] = "Сигнальный канал"
    if settings.main_channel_id:
        out[str(settings.main_channel_id)] = "Основной канал"
    return out


def _day() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def _st(cid: str) -> Dict[str, Any]:
    s = _stats.setdefault(cid, {"ok_total": 0, "err_total": 0, "day": _day(), "ok_today": 0,
                                "err_today": 0, "last_ok": 0, "last_err": 0})
    if s["day"] != _day():
        s.update(day=_day(), ok_today=0, err_today=0)
    return s


def load() -> None:
    try:
        data = json.loads(FILE.read_text())
        _stats.update(data.get("stats", {}))
        for k, v in data.get("errors", {}).items():
            _errors[k] = deque(v, maxlen=10)
    except (OSError, ValueError):
        pass


def _save() -> None:
    try:
        FILE.parent.mkdir(parents=True, exist_ok=True)
        FILE.write_text(json.dumps({"stats": _stats,
                                    "errors": {k: list(v) for k, v in _errors.items()}}))
    except OSError:
        pass


def record(cid: str, method: str, error: str | None) -> None:
    s = _st(cid)
    if error is None:
        s["ok_total"] += 1
        s["ok_today"] += 1
        s["last_ok"] = time.time()
    else:
        s["err_total"] += 1
        s["err_today"] += 1
        s["last_err"] = time.time()
        _errors.setdefault(cid, deque(maxlen=10)).append(
            [time.time(), method, error[:200]])
        asyncio.get_event_loop().create_task(_alert(cid, f"{method}: {error[:200]}"))
    _save()


async def _alert(cid: str, text: str) -> None:
    if time.time() - _last_alert.get(cid, 0) < 1800:
        return
    _last_alert[cid] = time.time()
    from app.scheduler.engine_loop import _notify_admins
    name = channels().get(cid, cid)
    await _notify_admins(f"⚠️ Сбой в канале «{name}»:\n{text}\nПодробно: /channels")


class ChannelMonitorMiddleware:
    """aiogram RequestMiddleware: wraps every API call."""

    async def __call__(self, make_request, bot, method):
        cid = str(getattr(method, "chat_id", "") or "")
        name = type(method).__name__
        tracked = cid in channels() and name in _TRACKED
        try:
            result = await make_request(bot, method)
        except Exception as e:  # noqa: BLE001
            if tracked:
                record(cid, name, f"{type(e).__name__}: {e}")
            raise
        if tracked:
            record(cid, name, None)
        return result


async def check_permissions(bot) -> Dict[str, str]:
    me = await bot.get_me()
    for cid, name in channels().items():
        try:
            m = await bot.get_chat_member(int(cid), me.id)
            status = getattr(m, "status", "?")
            status = getattr(status, "value", status)
            can_post = getattr(m, "can_post_messages", None)
            if status in ("administrator", "creator") and can_post is not False:
                _perm[cid] = "✅ админ, может публиковать"
            else:
                _perm[cid] = f"❌ статус {status}, публиковать не может"
                await _alert(cid, _perm[cid])
        except Exception as e:  # noqa: BLE001
            _perm[cid] = f"❌ нет доступа: {e}"[:150]
            await _alert(cid, _perm[cid])
    return dict(_perm)


async def monitor_loop(bot) -> None:
    load()
    while True:
        try:
            await check_permissions(bot)
        except Exception as e:  # noqa: BLE001
            log.warning("permission check failed: %s", e)
        await asyncio.sleep(600)


def _ago(ts: float) -> str:
    if not ts:
        return "—"
    s = int(time.time() - ts)
    return f"{s // 60} мин назад" if s < 3600 else f"{s // 3600} ч {s % 3600 // 60} мин назад"


def report() -> str:
    from app.services.state import state
    lines = ["<b>📡 КАНАЛЫ — МОНИТОРИНГ</b>", ""]
    if not channels():
        return "Каналы не заданы (SIGNAL_CHANNEL_ID / MAIN_CHANNEL_ID)."
    for cid, name in channels().items():
        s = _st(cid)
        lines.append(f"<b>{name}</b> <code>{cid}</code>")
        lines.append(f"<blockquote>Права: {html.escape(_perm.get(cid, 'проверка…'))}\n"
                     f"Постов сегодня: {s['ok_today']} · ошибок: {s['err_today']}\n"
                     f"Последний пост: {_ago(s['last_ok'])}\n"
                     f"Всего: {s['ok_total']} постов / {s['err_total']} ошибок</blockquote>")
        errs = list(_errors.get(cid, []))[-3:]
        if errs:
            lines.append("<i>Последние ошибки:</i>")
            for ts, m, e in errs:
                lines.append(f"• {datetime.fromtimestamp(ts):%d.%m %H:%M} {m}: <code>{html.escape(e[:120])}</code>")
        lines.append("")
    lines.append(f"⚙️ Движок: {'ON' if state.engine_on else 'OFF'} · провайдер "
                 f"{getattr(state.provider, 'name', '—')} "
                 f"{'ONLINE' if state.provider_online else 'OFFLINE'}"
                 + (" (резерв Forex)" if state.fallback_active else ""))
    return "\n".join(lines)
