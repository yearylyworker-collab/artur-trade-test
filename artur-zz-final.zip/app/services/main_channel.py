"""Main (public) channel: one showcase signal every MAIN_CHANNEL_EVERY_HOURS.

Flow
  1. timer due  -> "ГОТОВИМСЯ К СДЕЛКАМ" card + "сигнал в течение 5–35 минут"
  2. first real signal found >= MAIN_PREPARE_MIN_MINUTES later -> signal card with
     the main-channel caption (pair, direction, trade time • TF, entry window in
     Ukraine time, expandable "how to trade" with the CURRENT system and stakes)
  3. window result -> result card as a REPLY to that signal (win AND loss —
     showing only wins would be dishonest and people notice fast)
  4. optional: private-channel promo video (MAIN_PROMO_VIDEO_TEXT)

Links are optional settings; while empty the posts only mention MAIN_CONTACT.
State survives restarts: runtime/main_channel.json
"""
from __future__ import annotations

import asyncio
import json
import time
from datetime import timedelta
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

from app.config import settings
from app.core.logging_config import get_logger
from app.services.state import state

log = get_logger("services.main_channel")
STATE_FILE = Path("./runtime/main_channel.json")
PROMO_VIDEO = Path(__file__).resolve().parents[2] / "assets" / "media" / "private_promo.mp4"


def _load() -> dict:
    try:
        return json.loads(STATE_FILE.read_text())
    except (OSError, ValueError):
        return {}


def _save(d: dict) -> None:
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(d))
    except OSError as e:
        log.warning("main channel state save failed: %s", e)


def enabled() -> bool:
    return bool(settings.main_channel_id)


def _now_local():
    from datetime import datetime
    from app.analytics.timing import analytics_tz
    return datetime.now(analytics_tz())


def interval_seconds() -> float:
    if settings.main_channel_every_hours > 0:
        return settings.main_channel_every_hours * 3600
    hours = (settings.main_hours_end - settings.main_hours_start) % 24 or 24
    return hours * 3600 / max(1, settings.main_signals_per_day)


def in_hours() -> bool:
    now = _now_local()
    once = settings.main_start_once.strip()
    if once and once[:10] == now.strftime("%Y-%m-%d"):
        try:
            hh, mm = (int(x) for x in once[11:16].split(":"))
            if (now.hour, now.minute) < (hh, mm):
                return False
        except ValueError:
            pass
    h = now.hour
    a, b = settings.main_hours_start, settings.main_hours_end
    return a <= h < b if a < b else (h >= a or h < b)


def today_count(d: dict) -> int:
    return d.get("count", 0) if d.get("day") == _now_local().strftime("%Y-%m-%d") else 0


def due() -> bool:
    """Inside active hours, under the daily limit and the spacing interval passed."""
    d = _load()
    if not in_hours() or today_count(d) >= settings.main_signals_per_day:
        return False
    # leave room for the 5–35 min wait so the last signal still fits before the end hour
    return time.time() - d.get("last_signal", 0) >= interval_seconds() - settings.main_prepare_max_minutes * 60


def armed_ready() -> bool:
    """A prepare post is out and the minimum lead has passed -> next signal is public."""
    d = _load()
    armed = d.get("armed_at")
    return bool(armed) and time.time() - armed >= settings.main_prepare_min_minutes * 60


def claim() -> bool:
    """Called by the signal manager when a window starts. True = publish it in main."""
    if not enabled() or not armed_ready():
        return False
    d = _load()
    d.pop("armed_at", None)
    d["last_signal"] = time.time()
    day = _now_local().strftime("%Y-%m-%d")
    d["count"] = today_count(d) + 1
    d["day"] = day
    d["total"] = d.get("total", 0) + 1
    _save(d)
    return True


def promo_due() -> bool:
    """Private-channel promo after every MAIN_PROMO_EVERY-th main signal."""
    every = max(1, settings.main_promo_every)
    return _load().get("total", 0) % every == 0


def force_next() -> None:
    d = _load()
    d["armed_at"] = time.time() - settings.main_prepare_min_minutes * 60
    d["last_signal"] = 0
    _save(d)


# ------------------------------------------------------------------ texts ----
def _contact_line() -> str:
    return f"<i>✍️ По всем вопросам:</i> {settings.main_contact}"


def _links() -> str:
    out = ""
    if settings.main_register_url:
        out += f"➡️ <b>Торгую тут:</b> {settings.main_register_url} 📎\n"
    if settings.main_promo_text:
        out += f"<blockquote><b>🎁 {settings.main_promo_text}</b></blockquote>\n"
    return out


def prepare_caption() -> str:
    lo, hi = settings.main_prepare_min_minutes, settings.main_prepare_max_minutes
    return (
        f"🚨 <b>СИГНАЛ В ТЕЧЕНИЕ {lo}–{hi} МИНУТ</b>\n"
        "<blockquote><b>📊 Приготовьтесь — вход будет совсем скоро.</b></blockquote>\n\n"
        "➡️ <b>Проверь заранее:</b>\n"
        "<blockquote><b> • 📲 Доступ к платформе\n"
        " • 💴 Баланс для торговли\n"
        " • 📶 Стабильное соединение</b></blockquote>\n\n"
        + _links() + _contact_line() + "\n\n" + _counters()
    )


def _counters() -> str:
    from app.publisher.formatter import counters_block
    return counters_block()


def _hm(dt, tz: str) -> str:
    from app.publisher.formatter import _in_zone
    return _in_zone(dt, tz, "%H:%M")


def _pair_txt(symbol: str) -> str:
    from app.publisher.formatter import pair_label
    pair = pair_label(symbol).replace(" OTC", "")
    return (f"{pair[:3]}/{pair[3:]}" if len(pair) == 6 else pair) + " OTC"


def _stakes(analysis, n: int):
    from app.publisher.formatter import overlap_ladder
    payout = (analysis.indicators or {}).get("payout") or settings.otc_min_payout or 85
    base = settings.main_first_stake_usd
    overlap = settings.howto_stake_mode.lower() == "overlap" and n > 1
    return (overlap_ladder(base, payout / 100, n) if overlap else [base] * n), overlap, payout, base


def signal_caption(snapshot, plan: Sequence, analysis) -> str:
    from app.publisher.formatter import _in_zone, _zones, trade_tag
    label, tz = _zones()[0]
    pair_txt = _pair_txt(snapshot.pair)
    buy = snapshot.direction == "BUY"
    tag = trade_tag(snapshot.expiry_seconds, snapshot.timeframe)
    n = len(plan)
    stakes, overlap, _payout, base = _stakes(analysis, n)
    steps = "\n".join(f" • {i + 1}-й вход: {_in_zone(t, tz)} → ${stakes[i]:g}"
                      for i, t in enumerate(plan))
    risk = ""
    return (
        "➡️ <b>💸 БЫСТРЫЙ ПРОФИТ 💸</b>\n"
        f"{'🟢' if buy else '🔴'} <b>СИГНАЛ ПО {pair_txt}</b>\n"
        f"<blockquote><b>⚡️ Сегодняшний вход:\n{label} — {_hm(plan[0], tz)} до ({_hm(plan[-1], tz)})"
        "</b></blockquote>\n\n"
        "➡️ <b>Детали сигнала:</b>\n"
        f"<blockquote><b> • 📈 Пара: {pair_txt}\n"
        f" • 🎯 Сделка: {snapshot.direction} ({'вверх' if buy else 'вниз'}) {'📈' if buy else '📉'}\n"
        f" • ⏳ Время сделки: {tag}\n"
        f" • 💰 Ставка: {settings.howto_stake_percent:g}% от депозита"
        + (" — первая, дальше с перекрытием" if overlap else "") + "</b></blockquote>\n\n"
        "➡️ <b>Как делать сделки с нами</b> <i>(разверни 👇)</i>\n"
        f"<blockquote expandable><b>Система: Heikin Ashi {snapshot.timeframe} · вход на "
        f"{plan[0].second}-й секунде · {tag}</b>\n"
        f"Окно с {_hm(plan[0], tz)} до {_hm(plan[-1], tz)}. Входим ровно на {plan[0].second}-й "
        "секунде, не в начале минуты.\n\n"
        + (f"<b>📍 Порядок действий (первая ставка ${base:g}):</b>\n" if overlap else
           f"<b>📍 Порядок действий (депозит 100$ → ${base:g} на каждый вход):</b>\n")
        + f"{steps}\n"
        "✅ Любая сделка в плюс — останавливаемся и ждём следующий сигнал."
        f"{risk}</blockquote>\n\n"
        + _links() + _contact_line()
    )


def result_caption(snapshot, final: str, history: Sequence[Tuple[int, object, str]],
                   plan: Sequence, analysis) -> str:
    from app.publisher.formatter import trade_tag
    buy = snapshot.direction == "BUY"
    tag = trade_tag(snapshot.expiry_seconds, snapshot.timeframe)
    n_done = len(history)
    stakes, overlap, payout, base = _stakes(analysis, len(plan))
    head = (f" • 📈 {_pair_txt(snapshot.pair)} — {snapshot.direction} "
            f"({'вверх' if buy else 'вниз'}) {'📈' if buy else '📉'}")
    tail = "\n\n" + _links() + _contact_line()
    from app.publisher.formatter import _in_zone, _zones
    _lbl, tz = _zones()[0]
    work = "<blockquote><b>" + "\n".join(
        f"Время отработки: {_in_zone(t, tz)}/{snapshot.timeframe}"
        + {"WIN": "☑️", "LOSS": "🚫", "DRAW": "➖"}.get(r, "")
        for _i, t, r in history) + "</b></blockquote>\n"
    if final == "WIN":
        losses_before = sum(1 for _, _, r in history if r == "LOSS")
        k = n_done - 1
        trade = stakes[k] * payout / 100 if k < len(stakes) else base * payout / 100
        profit = trade - sum(stakes[:k])
        return (
            "✅ <b>СИГНАЛ ОТРАБОТАЛ В ПЛЮС</b>\n"
            f"<blockquote><b>{head}\n • ⏳ {tag} — сделка закрылась в профит 💸"
            + (f" (вход {n_done})" if n_done > 1 else "") + "</b></blockquote>\n"
            + work
            + f"<blockquote><b>💰 Прибыль сделки = +{trade:.2f}$</b> <i>({'первая ставка' if overlap else 'ставка'} ${base:g})</i>"
            + (f"\n<i>итог окна с учётом прошлых входов: {profit:+.2f}$</i>" if losses_before and profit < 0 else "")
            + "</blockquote>\n"
            "<b>Кто успел войти — поздравляю 🎉</b>" + tail
        )
    if final == "LOSS":
        lost = sum(stakes[:n_done]) if overlap else base * n_done
        return (
            "❌ <b>СИГНАЛ НЕ ЗАШЁЛ</b>\n"
            f"<blockquote><b>{head}\n • ⏳ {tag} — все входы в минус ({n_done})</b></blockquote>\n"
            + work +
            f"<blockquote><b>📉 Минус = {lost:.2f}$</b> <i>({'первая ставка' if overlap else 'ставка'} ${base:g})</i>"
            "</blockquote>\n"
            "<b>Такое бывает — не отыгрываемся, ждём следующий сигнал.</b>" + tail
        )
    return ("➖ <b>СИГНАЛ ЗАКРЫЛСЯ В НОЛЬ</b>\n"
            f"<blockquote><b>{head}\n • ⏳ {tag} — ставка вернулась</b></blockquote>" + tail)


# ------------------------------------------------------------------ posting --
async def post_prepare() -> None:
    if not (state.cards and enabled()):
        return
    try:
        from app.analytics.reports import refresh_counters
        await refresh_counters()
    except Exception as e:  # noqa: BLE001
        log.debug("counters failed: %s", e)
    await state.cards.send(settings.main_channel_id, "PREPARE", prepare_caption())
    d = _load()
    d["armed_at"] = time.time()
    _save(d)
    log.info("main channel: prepare post sent")


async def post_signal(card_type: str, snapshot, plan, analysis) -> Optional[int]:
    try:
        return await state.cards.send(settings.main_channel_id, card_type,
                                      signal_caption(snapshot, plan, analysis))
    except Exception as e:  # noqa: BLE001
        log.warning("main channel signal failed: %s", e)
        return None


async def post_result(snapshot, final: str, history, plan, analysis,
                      reply_to: Optional[int]) -> None:
    cap = result_caption(snapshot, final, history, plan, analysis)
    try:
        if final in ("WIN", "LOSS"):
            fid = await state.cards._cached_file_id(final)
            from aiogram.types import FSInputFile
            photo = fid or FSInputFile(state.cards.path(final))
            await state.bot.send_photo(settings.main_channel_id, photo, caption=cap,
                                       parse_mode="HTML", reply_to_message_id=reply_to)
        else:
            await state.bot.send_message(settings.main_channel_id, cap, parse_mode="HTML",
                                         reply_to_message_id=reply_to)
    except Exception as e:  # noqa: BLE001
        log.warning("main channel result failed: %s", e)
    if settings.main_promo_video_text and PROMO_VIDEO.exists() and promo_due():
        await asyncio.sleep(settings.main_promo_delay_seconds)
        await post_promo()


async def post_promo() -> None:
    from aiogram.types import FSInputFile
    try:
        await state.bot.send_animation(settings.main_channel_id, FSInputFile(PROMO_VIDEO),
                                       caption=settings.main_promo_video_text.replace("\\n", "\n"),
                                       parse_mode="HTML")
    except Exception as e:  # noqa: BLE001
        log.warning("promo video failed: %s", e)


def morning_caption() -> str:
    from app.publisher.formatter import trade_tag
    n = settings.main_signals_per_day
    return (
        "☀️ <b>ДОБРОЕ УТРО, КОМАНДА!</b>\n"
        "<blockquote><b>Начинаем торговый день — готовимся к сделкам 💪</b></blockquote>\n\n"
        "➡️ <b>План на сегодня:</b>\n"
        f"<blockquote><b> • 📊 Около {n} сигналов с {settings.main_hours_start:02d}:00 до "
        f"{settings.main_hours_end:02d}:00 (🇺🇦 Украина)\n"
        f" • ⏳ Время сделки: {trade_tag(settings.default_expiry_seconds, settings.default_timeframe)}\n"
        f" • 🎯 Вход на {settings.entry_second}-й секунде, до {settings.max_attempts} входов\n"
        " • 🚨 Перед каждым сигналом — предупреждение за 5–35 минут</b></blockquote>\n\n"
        "➡️ <b>Проверь заранее:</b>\n"
        "<blockquote><b> • 📲 Доступ к платформе\n • 💴 Баланс\n • 📶 Соединение</b></blockquote>\n\n"
        + _contact_line()
    )


def evening_caption(c: dict) -> str:
    return (
        "🌙 <b>ТОРГОВЫЙ ДЕНЬ ЗАВЕРШЁН</b>\n"
        f"<blockquote><b>📊 Сигналов сегодня: {c.get('main_today', 0)}\n"
        f"Итог всех сигналов бота за день: {c.get('win_today', 0)}➕ "
        f"{c.get('loss_today', 0)}➖</b></blockquote>\n\n"
        "<b>Спасибо всем, кто торговал с нами! Завтра с "
        f"{settings.main_hours_start:02d}:00 — снова в работу 💪</b>\n"
        + (f"\n🌙 <b>Ночью сигналы идут в приватке</b> 👉 <a href=\"{settings.private_channel_url}\"><b>ПОЛУЧИТЬ ПРИВАТКУ</b></a>\n"
           if settings.private_channel_url else "")
        + _contact_line()
    )


async def post_morning() -> None:
    await state.cards.send(settings.main_channel_id, "PREPARE", morning_caption())
    log.info("main channel: morning greeting sent")


async def post_evening() -> None:
    from app.analytics.reports import refresh_counters
    c = dict(await refresh_counters())
    c["main_today"] = today_count(_load())
    await state.bot.send_message(settings.main_channel_id, evening_caption(c), parse_mode="HTML")
    log.info("main channel: evening post sent")


async def main_channel_loop() -> None:
    log.info("main channel loop started (channel=%s, every %sh)",
             settings.main_channel_id, settings.main_channel_every_hours)
    while True:
        await asyncio.sleep(30)
        try:
            if not enabled() or not state.engine_on or not state.provider_online:
                continue
            d = _load()
            today = _now_local().strftime("%Y-%m-%d")
            if in_hours() and d.get("morning") != today:
                await post_morning()
                d = _load()
                d["morning"] = today
                d["last_signal"] = time.time()   # first prepare MAIN_GREETING_GAP_MINUTES later
                # due() fires MAIN_PREPARE_MAX_MINUTES before the interval ends, so shift by it too
                d["last_signal"] -= (interval_seconds() - settings.main_prepare_max_minutes * 60
                                     - settings.main_greeting_gap_minutes * 60)
                _save(d)
                continue
            if not in_hours() and d.get("morning") == today and d.get("evening") != today \
                    and _now_local().hour >= settings.main_hours_end:
                await post_evening()
                d = _load()
                d["evening"] = today
                _save(d)
                continue
            if d.get("armed_at"):
                continue
            if due():
                await post_prepare()
        except Exception as e:  # noqa: BLE001
            log.warning("main channel loop error: %s", e)
