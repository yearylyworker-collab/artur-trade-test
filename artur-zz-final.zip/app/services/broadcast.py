"""DM broadcast about the private channel, every BROADCAST_EVERY_HOURS.

Telegram lets a bot DM only people who pressed /start in the bot — channel
members cannot be messaged directly. So every /start is saved as a subscriber
(/stop unsubscribes, blocked users are removed automatically).

The message shows the REAL result of the private channel for the period
(windows, plus, minus, winrate) and what a 50$ deposit would have made with
the channel's stake plan (first stake % + overlap) — computed from actual
entries, positive or negative. Picking only good periods would be misleading.
"""
from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Tuple

from sqlalchemy import select

from app.config import settings
from app.core.logging_config import get_logger
from app.database.models import Signal, SignalAttempt
from app.database.session import get_session
from app.services.state import state

log = get_logger("services.broadcast")
SUBS = Path("./runtime/subscribers.json")
MARK = Path("./runtime/broadcast_last")


# ------------------------------------------------------------ subscribers --
def _subs() -> Dict[str, dict]:
    try:
        return json.loads(SUBS.read_text())
    except (OSError, ValueError):
        return {}


def _save_subs(d: Dict[str, dict]) -> None:
    SUBS.parent.mkdir(parents=True, exist_ok=True)
    SUBS.write_text(json.dumps(d))


def add_subscriber(user_id: int, username: str | None) -> None:
    d = _subs()
    d[str(user_id)] = {"u": username or "", "t": int(time.time())}
    _save_subs(d)


def remove_subscriber(user_id: int) -> None:
    d = _subs()
    if d.pop(str(user_id), None) is not None:
        _save_subs(d)


def count() -> int:
    return len(_subs())


# ------------------------------------------------------------------ stats --
async def period_pnl(hours: float) -> dict:
    """Real windows of the last N hours + P&L of a 50$ deposit with the stake plan."""
    from app.publisher.formatter import overlap_ladder
    until = datetime.now(timezone.utc)
    since = until - timedelta(hours=hours)
    async with get_session() as s:
        sigs = (await s.execute(
            select(Signal.id, Signal.final_result, Signal.audit)
            .where(Signal.mode == state.mode.value, Signal.entry_time >= since,
                   Signal.entry_time < until, Signal.final_result.in_(("WIN", "LOSS", "DRAW")))
            .order_by(Signal.entry_time))).all()
        ids = [r[0] for r in sigs]
        att: Dict[int, list] = {}
        if ids:
            for sid, n, res in (await s.execute(
                    select(SignalAttempt.signal_id, SignalAttempt.attempt_number,
                           SignalAttempt.result)
                    .where(SignalAttempt.signal_id.in_(ids))
                    .order_by(SignalAttempt.signal_id, SignalAttempt.attempt_number))).all():
                att.setdefault(sid, []).append(res)
    deposit = settings.broadcast_deposit_usd
    base = deposit * settings.howto_stake_percent / 100
    overlap = settings.howto_stake_mode.lower() == "overlap"
    balance = deposit
    wins = losses = 0
    for sid, final, audit in sigs:
        payout = ((audit or {}).get("indicators") or {}).get("payout") or \
            settings.otc_min_payout or int(settings.payout_percent)
        p = payout / 100
        seq = att.get(sid, [])
        stakes = overlap_ladder(base, p, max(1, len(seq))) if overlap else [base] * len(seq)
        for k, r in enumerate(seq):
            if r == "WIN":
                balance += stakes[k] * p
                break
            if r == "LOSS":
                balance -= stakes[k]
        wins += final == "WIN"
        losses += final == "LOSS"
    dec = wins + losses
    return {"windows": len(sigs), "wins": wins, "losses": losses,
            "winrate": wins / dec if dec else 0.0, "deposit": deposit, "base": base,
            "balance": balance, "profit": balance - deposit, "hours": hours}


def message(st: dict) -> str:
    sign = "+" if st["profit"] >= 0 else "−"
    pct = abs(st["profit"]) / st["deposit"] * 100 if st["deposit"] else 0
    return (
        "➡️ <b>PRIVAT CHANNEL — итоги за последние "
        f"{st['hours']:g} ч</b> 🤖\n"
        "<blockquote><b>"
        f"📊 Сигналов (окон): {st['windows']}\n"
        f"✅ В плюс: {st['wins']}\n"
        f"❌ В минус: {st['losses']}\n"
        f"🎯 Винрейт окон: {st['winrate'] * 100:.0f}%</b></blockquote>\n\n"
        f"➡️ <b>С депозитом {st['deposit']:g}$ ты бы получил:</b>\n"
        f"<blockquote><b>💰 {sign}{abs(st['profit']):.2f}$ ({sign}{pct:.1f}%)\n"
        f"Баланс: {st['balance']:.2f}$</b>\n"
        f"<i>первая ставка {st['base']:g}$"
        + (", дальше с перекрытием" if settings.howto_stake_mode.lower() == "overlap" else "")
        + " — по реальным итогам сигналов</i></blockquote>\n\n"
        "➡️ <b>В приватке сигналы 24/7 — 120–150 в сутки</b>\n"
        + (f"👉 <a href=\"{settings.private_channel_url}\"><b>ПОЛУЧИТЬ ПРИВАТКУ</b></a>\n" if settings.private_channel_url
           else "") +
        f"<blockquote><b>✍️ Доступ и вопросы: {settings.main_contact}</b></blockquote>\n\n"
        "<i>Прошлые результаты не гарантируют будущих. Отписаться: /stop</i>"
    )


# --------------------------------------------------------------- sending ----
async def send_all() -> Tuple[int, int]:
    st = await period_pnl(settings.broadcast_every_hours)
    if st["windows"] == 0:
        log.info("broadcast skipped: no closed windows in period")
        return 0, 0
    text = message(st)
    ok = fail = 0
    for uid in list(_subs().keys()):
        try:
            await state.bot.send_message(int(uid), text, parse_mode="HTML")
            ok += 1
        except Exception as e:  # noqa: BLE001
            fail += 1
            if "blocked" in str(e).lower() or "deactivated" in str(e).lower() \
                    or "chat not found" in str(e).lower():
                remove_subscriber(int(uid))
        await asyncio.sleep(0.05)   # ~20 msg/s, below Telegram limits
    MARK.parent.mkdir(parents=True, exist_ok=True)
    MARK.write_text(str(time.time()))
    log.info("broadcast sent: ok=%d fail=%d", ok, fail)
    return ok, fail


async def broadcast_loop() -> None:
    log.info("broadcast loop started (every %sh, enabled=%s)",
             settings.broadcast_every_hours, settings.broadcast_enabled)
    while True:
        await asyncio.sleep(300)
        try:
            if not settings.broadcast_enabled or not state.bot or count() == 0:
                continue
            try:
                last = float(MARK.read_text())
            except (OSError, ValueError):
                MARK.parent.mkdir(parents=True, exist_ok=True)
                MARK.write_text(str(time.time()))   # first run: wait a full period
                continue
            if time.time() - last >= settings.broadcast_every_hours * 3600:
                ok, fail = await send_all()
                from app.scheduler.engine_loop import _notify_admins
                if ok or fail:
                    await _notify_admins(f"📨 Рассылка: доставлено {ok}, не доставлено {fail}")
        except Exception as e:  # noqa: BLE001
            log.warning("broadcast loop error: %s", e)
