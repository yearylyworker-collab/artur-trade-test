"""High-level engine control used by admin panel & startup."""
from __future__ import annotations

from app.config import settings
from app.core.enums import Mode
from app.core.logging_config import get_logger
from app.market.manager import build_provider
from app.scheduler.engine_loop import analysis_cycle, refresh_candles
from app.services.state import state

log = get_logger("services.engine_control")


async def _connect_provider() -> bool:
    if state.provider:
        try:
            await state.provider.disconnect()
        except Exception:  # noqa: BLE001
            pass
    state.provider = build_provider(state.mode.value)
    state.fallback_active = False
    try:
        await state.provider.connect()
        state.provider_online = True
        state.provider_error = ""
    except Exception as e:  # noqa: BLE001
        log.error("provider connect failed: %s", e)
        state.provider_online = False
        state.provider_error = str(e)[:200]
        from app.services.fallback import try_fallback
        if not await try_fallback(str(e)):
            return False
    # subscribe live quotes (WS) if supported
    try:
        symbols = await state.provider.get_symbols()
        await state.provider.subscribe_quotes(symbols)
    except Exception as e:  # noqa: BLE001
        log.warning("subscribe failed: %s", e)
    await refresh_candles()
    return True


async def switch_mode(mode: Mode) -> bool:
    state.mode = mode
    state.auto_demo = False
    state.engine_on = False
    ok = await _connect_provider()
    log.info("mode switched -> %s (provider_online=%s)", mode.value, ok)
    return ok


async def start_engine() -> bool:
    if not state.provider_online:
        ok = await _connect_provider()
        if not ok:
            return False
    if state.mode == Mode.LIVE and not state.channel_ok:
        log.warning("cannot start LIVE engine: channel not verified")
        return False
    state.engine_on = True
    log.info("ENGINE ON (mode=%s)", state.mode.value)
    await _announce_engine_started()
    return True


async def _announce_engine_started() -> None:
    if not state.cards or not settings.signal_channel_id:
        return
    try:
        from app.publisher import formatter
        await state.cards.send(
            settings.signal_channel_id, "ENGINE_STARTED",
            formatter.engine_caption(settings.default_timeframe, pairs_count()))
        await state.cards.send(
            settings.signal_channel_id, "PLATFORM",
            formatter.platform_caption(settings.default_timeframe,
                                       settings.default_expiry_seconds))
        await post_howto()
        await post_search_card()
    except Exception as e:  # noqa: BLE001
        log.warning("engine_started announce failed: %s", e)


_last_howto = 0.0


async def post_howto(force: bool = False) -> None:
    """Instruction for subscribers (current mode). At most once per 6 h unless forced,
    so restarts do not spam the channel."""
    global _last_howto
    import time
    if not state.bot or not settings.signal_channel_id:
        return
    from pathlib import Path
    mark = Path("./runtime/howto_posted")
    try:
        _last_howto = max(_last_howto, float(mark.read_text()))
    except (OSError, ValueError):
        pass
    if not force and time.time() - _last_howto < 6 * 3600:
        return
    from app.publisher import formatter
    try:
        await state.bot.send_message(settings.signal_channel_id, formatter.howto_caption(),
                                     parse_mode="HTML")
        _last_howto = time.time()
        try:
            mark.parent.mkdir(parents=True, exist_ok=True)
            mark.write_text(str(_last_howto))
        except OSError:
            pass
    except Exception as e:  # noqa: BLE001
        log.warning("howto post failed: %s", e)


def pairs_count() -> int:
    """Number of pairs actually analysed (auto OTC list lives in the provider)."""
    syms = getattr(state.provider, "symbols", None)
    return len(syms) if syms else len(settings.active_symbols)


async def post_search_card() -> None:
    """'Bot is searching' card. Only one lives in the channel: the previous one
    is deleted, and the current one is removed when a signal is published."""
    if not state.cards or not settings.signal_channel_id:
        return
    try:
        from app.publisher import formatter
        from app.analytics.reports import refresh_counters
        try:
            await refresh_counters()
        except Exception as e:  # noqa: BLE001
            log.debug("counters failed: %s", e)
        await delete_search_card()
        state.search_mid = await state.cards.send(
            settings.signal_channel_id, "SEARCH",
            formatter.search_caption(settings.default_timeframe, pairs_count()))
    except Exception as e:  # noqa: BLE001
        log.warning("search card failed: %s", e)


async def delete_search_card() -> None:
    mid, state.search_mid = getattr(state, "search_mid", None), None
    if mid and state.publisher:
        try:
            await state.publisher.delete_message(mid)
        except Exception as e:  # noqa: BLE001
            log.debug("search card delete failed: %s", e)


async def stop_engine() -> None:
    state.engine_on = False
    state.auto_demo = False
    log.info("ENGINE OFF")


async def start_auto_demo() -> bool:
    await switch_mode(Mode.DEMO)
    if not state.provider_online:
        return False
    state.auto_demo = True
    state.engine_on = True
    log.info("AUTO DEMO started")
    await _announce_engine_started()
    return True


async def stop_auto_demo() -> None:
    state.auto_demo = False
    state.engine_on = False
    log.info("AUTO DEMO stopped")


async def analyze_now() -> None:
    await analysis_cycle()
