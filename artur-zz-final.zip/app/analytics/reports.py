"""Admin reports: today / night / week, timing, assets, health, adaptive."""
from __future__ import annotations

import asyncio
import time
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple

from sqlalchemy import func, select

from app.analytics.timing import WEEKDAYS, analytics_tz, timing
from app.config import settings
from app.database.models import Signal, SignalAttempt
from app.database.session import get_session
from app.publisher.formatter import pair_label
from app.services import runtime
from app.services.state import state


def period(kind: str, now: Optional[datetime] = None) -> Tuple[datetime, datetime, str]:
    """(since_utc, until_utc, label) in the analytics timezone.
    kind: today | night | week | yesterday."""
    tz = analytics_tz()
    now = (now or datetime.now(tz)).astimezone(tz)
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if kind == "night":
        start = midnight
        end = min(now, midnight + timedelta(hours=8))
        if now.hour < 1:   # just after midnight: show the previous night
            start, end = midnight - timedelta(days=1), midnight - timedelta(hours=16)
        label = f"{start:%d.%m} 00:00 – 08:00"
    elif kind == "yesterday":
        start, end = midnight - timedelta(days=1), midnight
        label = f"{start:%d.%m.%Y} 00:00 – 24:00"
    elif kind == "week":
        start, end = now - timedelta(days=7), now
        label = f"{start:%d.%m} – {end:%d.%m}"
    else:
        start, end = midnight, now
        label = f"{start:%d.%m} 00:00 – {now:%H:%M}"
    return start.astimezone(timezone.utc), end.astimezone(timezone.utc), label


def _pct(x: float) -> str:
    return f"{x * 100:.0f}%"


async def window_summary(since: datetime, until: datetime) -> dict:
    async with get_session() as s:
        rows = (await s.execute(
            select(Signal.id, Signal.final_result, Signal.direction)
            .where(Signal.mode == state.mode.value, Signal.entry_time >= since,
                   Signal.entry_time < until, Signal.final_result.in_(("WIN", "LOSS", "DRAW")))
        )).all()
        ids = [r[0] for r in rows]
        att = {}
        entries = {"WIN": 0, "LOSS": 0, "DRAW": 0}
        if ids:
            for sid, res, n in (await s.execute(
                    select(SignalAttempt.signal_id, SignalAttempt.result, func.count())
                    .where(SignalAttempt.signal_id.in_(ids))
                    .group_by(SignalAttempt.signal_id, SignalAttempt.result))).all():
                att[sid] = att.get(sid, 0) + n
                if res in entries:
                    entries[res] += n
    wins = sum(1 for r in rows if r[1] == "WIN")
    losses = sum(1 for r in rows if r[1] == "LOSS")
    counts = [att.get(i, 0) for i in ids if att.get(i)]
    return {"buys": sum(1 for r in rows if r[2] == "BUY"),
            "sells": sum(1 for r in rows if r[2] == "SELL"),
            "repeats": sum(max(0, c - 1) for c in counts),
            "windows": len(rows), "wins": wins, "losses": losses,
            "draws": len(rows) - wins - losses,
            "avg_attempts": sum(counts) / len(counts) if counts else 0.0,
            "max_attempts": max(counts) if counts else 0, "entries": entries}


async def period_report(kind: str) -> str:
    since, until, label = period(kind)
    title = {"night": "🌙 СТАТИСТИКА ЗА НОЧЬ", "week": "📅 СТАТИСТИКА ЗА НЕДЕЛЮ"}.get(
        kind, "📊 СТАТИСТИКА ЗА СЕГОДНЯ")
    w = await window_summary(since, until)
    s_ts, u_ts = int(since.timestamp()), int(until.timestamp())
    rep = await timing.areport(s_ts, u_ts)
    decided = w["wins"] + w["losses"]
    e = w["entries"]
    e_dec = e["WIN"] + e["LOSS"]
    lines = [f"<b>{title}</b>", f"Период: {label}", "", "<b>📊 ОБЩИЕ:</b>",
             f"• Окон открыто: {w['windows']}"]
    if decided:
        lines += [f"• ✅ Плюсовых: {w['wins']} ({_pct(w['wins'] / decided)})",
                  f"• ❌ Минусовых: {w['losses']} ({_pct(w['losses'] / decided)})"]
    if w["draws"]:
        lines.append(f"• ➖ Возвратов: {w['draws']}")
    lines += [f"• Всего сигналов: {w['windows']}",
              f"• Среднее попыток: {w['avg_attempts']:.1f}",
              f"• Максимум попыток: {w['max_attempts']}"]
    if e_dec:
        lines.append(f"• Входов: {e_dec} · прибыльных {_pct(e['WIN'] / e_dec)}")
    # best second: live+shadow over the period (shadow = same prices, other second)
    sec_rows = [r for r in rep["seconds"] if r[2] >= 5]
    lines += ["", "<b>⏱ ЛУЧШАЯ СЕКУНДА ВХОДА:</b>"]
    if sec_rows:
        k, wr, n = sec_rows[0]
        lines.append(f"• :{int(k):02d} — {_pct(wr)} ({n} замеров)")
    else:
        lines.append("• мало данных")
    hours = [r for r in timing.stats("hour", s_ts, u_ts) if r[2] >= 3]
    best_h = hours[:3]
    weak_h = sorted([r for r in hours if r[1] < settings.timing_weak_threshold],
                    key=lambda r: r[1])[:3]
    lines += ["", "<b>📈 ЛУЧШИЕ ЧАСЫ:</b>"] + (
        [f"• {int(h):02d}:00 — {_pct(wr)} ({n} вх.)" for h, wr, n in best_h] or ["• мало данных"])
    lines += ["", "<b>📉 СЛАБЫЕ ЧАСЫ:</b>"] + (
        [f"• {int(h):02d}:00 — {_pct(wr)} ({n} вх.)" for h, wr, n in weak_h] or ["• нет"])
    assets = [r for r in timing.stats("asset", s_ts, u_ts) if r[2] >= 3]
    top = assets[:3]
    worst = sorted([r for r in assets if r[1] < settings.timing_weak_threshold],
                   key=lambda r: r[1])[:3]
    lines += ["", "<b>💰 АКТИВЫ:</b>", "Топ-3:"] + (
        [f"• {pair_label(a)} — {_pct(wr)} ({n} вх.)" for a, wr, n in top] or ["• мало данных"])
    lines += ["Худшие:"] + (
        [f"• {pair_label(a)} — {_pct(wr)} ({n} вх.)" for a, wr, n in worst] or ["• нет"])
    rec = []
    if sec_rows and sec_rows[0][2] >= settings.timing_min_samples_second:
        rec.append(f"• Вход на :{int(sec_rows[0][0]):02d} показывает лучший результат")
    for h, _wr, _n in weak_h[:2]:
        rec.append(f"• Избегать {int(h):02d}:00")
    for a, _wr, n in worst[:2]:
        if n >= settings.timing_min_samples_asset:
            rec.append(f"• {pair_label(a)} временно исключить")
    lines += ["", "<b>💡 РЕКОМЕНДАЦИИ:</b>"] + (rec or ["• данных пока мало для выводов"])
    lines += ["", "<i>Часы — по времени Украины. Входы считаются отдельно: окно «+1» может "
                  "включать минусовые входы.</i>"]
    return "\n".join(lines)


def timing_report() -> str:
    rep = timing.get_full_report()
    c = timing.counts()
    lines = ["<b>⏱ ЛУЧШЕЕ ВРЕМЯ ВХОДА</b>",
             f"Замеров: реальных {c['live']}, теневых {c['shadow']}", ""]
    b = rep["best_second"]
    lines.append(f"🎯 Лучшая секунда: :{b[0]:02d} — {_pct(b[1])} ({b[2]})" if b else
                 f"🎯 Лучшая секунда: нужно ≥{settings.timing_min_samples_second} замеров")
    secs = sorted(rep["seconds"], key=lambda r: int(r[0]))
    if secs:
        lines.append("<code>" + "\n".join(f":{int(k):02d}  {wr * 100:5.1f}%  n={n}"
                                          for k, wr, n in secs) + "</code>")
    lines += ["", "<b>📈 Лучшие часы:</b>"] + (
        [f"• {int(h):02d}:00 — {_pct(wr)} ({n})" for h, wr, n in rep["best_hours"]] or
        [f"• нужно ≥{settings.timing_min_samples_hour} входов в час"])
    lines += ["<b>📉 Слабые часы:</b>"] + (
        [f"• {int(h):02d}:00 — {_pct(wr)} ({n})" for h, wr, n in rep["weak_hours"]] or ["• нет"])
    wd = sorted(rep["weekdays"], key=lambda r: int(r[0]))
    if wd:
        lines += ["<b>📅 Дни недели:</b>"] + [f"• {WEEKDAYS[int(d)]} — {_pct(wr)} ({n})"
                                             for d, wr, n in wd]
    from app.services import runtime as _rt
    tf = settings.default_timeframe
    dst = timing.duration_stats(tf)
    if any(n for _d, _w, n in dst):
        lines += ["", f"<b>⏱ Время сделки ({tf}), прибыльных:</b>", "<code>" + "\n".join(
            f"{d:>4} сек  {wr * 100:5.1f}%  n={n}" for d, wr, n in dst) + "</code>"]
    lines.append(f"Сейчас: {settings.default_expiry_seconds} сек · "
                 f"{'авто (нужно ≥' + str(settings.duration_min_samples) + ' замеров)' if settings.trade_seconds_auto and not settings.trade_seconds else 'фиксировано'}"
                 + (f"\n{_rt.DURATION_REASON[tf]}" if tf in _rt.DURATION_REASON else ""))
    lines.append(f"\nENTRY_SECOND_AUTO: {'ON' if settings.entry_second_auto else 'OFF'} · "
                 f"сейчас вход на :{settings.entry_second:02d}")
    return "\n".join(lines)


def assets_report() -> str:
    rep = timing.get_full_report()
    lines = ["<b>💰 АКТИВЫ</b>", "", "<b>Лучшие:</b>"]
    lines += [f"• {pair_label(a)} — {_pct(wr)} ({n} вх.)" for a, wr, n in rep["best_assets"]] or \
        [f"• нужно ≥{settings.timing_min_samples_asset} входов на актив"]
    lines += ["", "<b>Худшие:</b>"]
    lines += [f"• {pair_label(a)} — {_pct(wr)} ({n} вх.)" for a, wr, n in rep["worst_assets"]] or \
        ["• нет данных"]
    allrows = [r for r in timing.stats("asset") if r[2] >= 3][:15]
    if allrows:
        lines += ["", "<b>Все (≥3 входов):</b>", "<code>" + "\n".join(
            f"{pair_label(a)[:12]:12} {wr * 100:5.1f}% n={n}" for a, wr, n in allrows) + "</code>"]
    return "\n".join(lines)


def _pairs_line() -> str:
    from app.publisher.formatter import pair_summary
    from app.services.engine_control import pairs_count
    s = pair_summary(pairs_count())
    if s["low"]:
        return (f"🌐 Пар всего: {s['total']} · невыгодных (выплата &lt; {s['min_payout']}%): "
                f"{s['low']} ({s['low'] * 100 // max(1, s['total'])}%) · торгуем: {s['tradeable']}")
    return f"🌐 Пар в торговле: {s['tradeable']}"


def _main_line() -> str:
    from app.services import main_channel as mc
    if not settings.main_channel_id:
        return "📣 Основной канал: не подключён (MAIN_CHANNEL_ID)"
    d = mc._load()
    return (f"📣 Основной канал: сегодня {mc.today_count(d)}/{settings.main_signals_per_day} · "
            f"с {settings.main_hours_start:02d}:00 до {settings.main_hours_end:02d}:00 · "
            f"раз в ~{mc.interval_seconds() / 60:.0f} мин · видео каждые {settings.main_promo_every}"
            + (" · ждём сигнал после «Готовимся»" if d.get("armed_at") else ""))


def _uptime() -> str:
    s = int(time.time() - state.started_at)
    return f"{s // 86400}д {s % 86400 // 3600}ч {s % 3600 // 60}м"


def health_report() -> str:
    p = state.provider
    cur = runtime.current()
    prov = getattr(p, "name", "—")
    if state.fallback_active:
        prov += " (РЕЗЕРВ: Pocket недоступен)"
    ssid = "задан" if settings.pocket_ssid.strip() else "НЕ задан"
    diag = state.diag.get("cycle", {})
    ad = state.adaptive
    pending = ad.pending if ad else None
    shadow = state.shadow
    lines = [
        "<b>❤️ СОСТОЯНИЕ БОТА</b>", "",
        f"⏱ Аптайм: {_uptime()}",
        f"⚙️ Движок: {'ON' if state.engine_on else 'OFF'} · режим {state.mode.value}",
        f"📡 Провайдер: {prov} · {'ONLINE' if state.provider_online else 'OFFLINE'}",
        f"🔑 POCKET_SSID: {ssid}" + (f"\n⚠️ Ошибка: {state.provider_error}"
                                     if state.provider_error else ""),
        f"📢 Канал: {'OK' if state.channel_ok else 'НЕТ ДОСТУПА'}",
        f"🪟 Активное окно: {'да (#%s)' % state.active_signal_id if state.is_busy else 'нет'}",
        _pairs_line(),
        f"📊 Прошли фильтры в последнем цикле: {diag.get('passed', '—')}",
        "",
        f"🎛 Таймфрейм {cur['timeframe']} · экспирация {settings.default_expiry_seconds}с · "
        f"вход :{cur['entry_second']:02d} · окно {cur['window_length']}",
        f"🤖 Адаптивный: {'ON' if cur['adaptive'] else 'OFF'}"
        + (f" · смена в {pending['at']:%H:%M} UTC → {pending['timeframe']}" if pending else ""),
        f"👻 Теневых окон в работе: {shadow.running if shadow else 0}",
        _main_line(),
    ]
    return "\n".join(lines)


def adaptive_report() -> str:
    ad = state.adaptive
    if not ad:
        return "Адаптивный движок ещё не запущен."
    rep = ad.analyze()
    lines = ["<b>🤖 АДАПТИВНЫЙ ДВИЖОК</b>",
             f"Статус: {'ON' if settings.adaptive_enabled else 'OFF'} · выплата ≈"
             f"{rep['payout'] * 100:.0f}%", ""]
    for tf, i in rep["timeframes"].items():
        mark = " ◀ сейчас" if tf == settings.default_timeframe else ""
        lines.append(f"<b>{tf}</b>{mark}: окон {i['samples']}, лучшая длина {i['best_len']}")
        for n, st in i["by_len"].items():
            lines.append(f"  {n} вх.: winrate {_pct(st['winrate'])}, ср. попыток "
                         f"{st['avg_attempts']:.1f}, итог {st['ev']:+.2f} ставки/окно")
        if i.get("atr_pct"):
            lines.append(f"  ATR ≈ {i['atr_pct'] * 100:.3f}%")
    prop = ad.proposal()
    lines += ["", f"Предложение: {prop['timeframe']} · :{prop['entry_second']:02d} · "
                  f"{prop['window_length']} вх. — {prop['reason']}" if prop else
              f"Предложение: оставить как есть (нужно ≥{settings.adaptive_min_samples} окон и "
              f"перевес ≥{settings.adaptive_improvement_threshold * 100:.0f}%)"]
    return "\n".join(lines)


def startup_report(ok: bool) -> str:
    cur = runtime.current()
    p = state.provider
    return "\n".join([
        "🚀 <b>ARTUR TRADE запущен</b>",
        f"Режим: {state.mode.value} · провайдер: {getattr(p, 'name', '—')} "
        f"{'✅' if ok and state.provider_online else '❌'}"
        + (" (резерв Forex)" if state.fallback_active else ""),
        (f"⚠️ {state.provider_error}" if state.provider_error and not state.provider_online
         else ""),
        f"Канал: {'✅' if state.channel_ok else '❌ нет прав'}",
        _pairs_line(),
        f"Параметры: {cur['timeframe']} · вход :{cur['entry_second']:02d} · окно "
        f"{cur['window_length']} · адаптив {'ON' if cur['adaptive'] else 'OFF'}",
        f"Движок: {'ON' if state.engine_on else 'OFF (включи /panel → ENGINE ON)'}",
        "Команды: /start — панель, /health, /stats_night",
    ]).replace("\n\n", "\n")



async def daily_card(kind: str = "yesterday") -> Tuple[str, str]:
    """(png_path, caption) of the day's statistics card with the numbers drawn in."""
    from app.cards.renderer import get_renderer
    since, until, label = period(kind)
    w = await window_summary(since, until)
    dec = w["wins"] + w["losses"]
    e = w["entries"]
    e_dec = e["WIN"] + e["LOSS"]
    wr = f"{w['wins'] * 100 // dec}%" if dec else "—"
    ewr = f"{e['WIN'] * 100 // e_dec}%" if e_dec else "—"
    data = {"mode": f"OTC {settings.default_timeframe}" if settings.is_pocket
            else f"Forex {settings.default_timeframe}",
            "signals": w["windows"], "wins": w["wins"], "losses": w["losses"],
            "draws": w["draws"], "buys": w["buys"], "sells": w["sells"],
            "repeats": w["repeats"],
            "win_rate": f"окна {wr} · входы {ewr}" if settings.max_attempts > 1 else ewr}
    path = await asyncio.to_thread(get_renderer().render, "stats", data)
    payout = settings.otc_min_payout or int(settings.payout_percent)
    caption = (
        "<b>📊 СТАТИСТИКА ЗА ДЕНЬ. ИТОГИ СЕССИИ</b>\n"
        f"<i>{label} (время Украины)</i>\n\n"
        "<blockquote>"
        f"🪟 <b>Окон:</b> <code>{w['windows']}</code> · ✅ <code>{w['wins']}</code> · "
        f"❌ <code>{w['losses']}</code>" + (f" · ➖ <code>{w['draws']}</code>" if w["draws"] else "")
        + f"\n🎯 <b>Входов:</b> <code>{e_dec + e['DRAW']}</code> · прибыльных "
        f"<code>{e['WIN']}</code> ({ewr})\n"
        f"🔁 <b>Среднее входов в окне:</b> <code>{w['avg_attempts']:.1f}</code>"
        "</blockquote>\n\n"
        f"<i>Безубыточность по входам при выплате {payout}%: "
        f"{100 / (1 + payout / 100):.0f}%. Соблюдаем мани-менеджмент!</i>"
    )
    return path, caption



async def refresh_counters() -> dict:
    """Windows plus/minus: all-time and today (Ukraine day). Cached on state."""
    since_today, until, _ = period("today")
    async with get_session() as s:
        rows = (await s.execute(
            select(Signal.final_result, func.count())
            .where(Signal.mode == state.mode.value, Signal.final_result.in_(("WIN", "LOSS")))
            .group_by(Signal.final_result))).all()
        today = (await s.execute(
            select(Signal.final_result, func.count())
            .where(Signal.mode == state.mode.value, Signal.final_result.in_(("WIN", "LOSS")),
                   Signal.entry_time >= since_today)
            .group_by(Signal.final_result))).all()
    tot, td = dict(rows), dict(today)
    c = {"win": tot.get("WIN", 0), "loss": tot.get("LOSS", 0),
         "win_today": td.get("WIN", 0), "loss_today": td.get("LOSS", 0)}
    state.counters = c
    return c


async def entries_report() -> str:
    """Per-ENTRY winrate (every single trade), not windows."""
    from app.publisher.formatter import pair_label
    tz = analytics_tz()
    now = datetime.now(timezone.utc)   # DB times are UTC
    out = ["<b>🎯 ВИНРЕЙТ ПО ВХОДАМ</b> <i>(каждая сделка отдельно)</i>", ""]
    periods = [("Сегодня", period("today")[0]), ("24 часа", now - timedelta(hours=24)),
               ("7 дней", now - timedelta(days=7))]
    payout = settings.otc_min_payout or int(settings.payout_percent)
    be = 100 / (1 + payout / 100)
    async with get_session() as s:
        for name, since in periods:
            rows = (await s.execute(
                select(SignalAttempt.result, func.count())
                .join(Signal, Signal.id == SignalAttempt.signal_id)
                .where(Signal.mode == state.mode.value, SignalAttempt.entry_time >= since,
                       SignalAttempt.result.in_(("WIN", "LOSS", "DRAW")))
                .group_by(SignalAttempt.result))).all()
            d = dict(rows)
            w, l, dr = d.get("WIN", 0), d.get("LOSS", 0), d.get("DRAW", 0)
            wr = w / (w + l) * 100 if w + l else 0
            mark = "✅" if wr >= be else "⚠️"
            out.append(f"<b>{name}:</b> {w}➕ {l}➖" + (f" {dr}➖➕" if dr else "")
                       + f" → <b>{wr:.1f}%</b> {mark if w + l else ''}")
        out.append(f"<i>Безубыточность при выплате {payout}%: {be:.1f}%</i>")
        # by entry number (24h)
        rows = (await s.execute(
            select(SignalAttempt.attempt_number, SignalAttempt.result, func.count())
            .join(Signal, Signal.id == SignalAttempt.signal_id)
            .where(Signal.mode == state.mode.value,
                   SignalAttempt.entry_time >= now - timedelta(hours=24),
                   SignalAttempt.result.in_(("WIN", "LOSS")))
            .group_by(SignalAttempt.attempt_number, SignalAttempt.result))).all()
        by: dict = {}
        for n, r, c in rows:
            by.setdefault(n, {"WIN": 0, "LOSS": 0})[r] = c
        if by:
            out += ["", "<b>По номеру входа в окне (24 ч):</b>"]
            for n in sorted(by):
                w, l = by[n]["WIN"], by[n]["LOSS"]
                out.append(f"• {n}-й вход: {w}➕ {l}➖ → {w / (w + l) * 100:.0f}%")
        last = (await s.execute(
            select(Signal.symbol, Signal.direction, SignalAttempt.attempt_number,
                   SignalAttempt.entry_time, SignalAttempt.entry_price,
                   SignalAttempt.exit_price, SignalAttempt.result, Signal.expiry_seconds)
            .join(Signal, Signal.id == SignalAttempt.signal_id)
            .where(Signal.mode == state.mode.value)
            .order_by(SignalAttempt.id.desc()).limit(8))).all()
    if last:
        out += ["", "<b>Последние входы (как их видит бот):</b>"]
        for sym, d, n, et, ep, xp, r, exp in last:
            icon = {"WIN": "☑️", "LOSS": "🚫", "DRAW": "➖"}.get(r, "•")
            t = et.astimezone(tz).strftime("%H:%M:%S") if et and et.tzinfo else (
                et.replace(tzinfo=timezone.utc).astimezone(tz).strftime("%H:%M:%S") if et else "—")
            arrow = "↑" if d == "BUY" else "↓"
            out.append(f"{icon} <code>{t}</code> {pair_label(sym)} {d}{arrow} #{n} · "
                       f"<code>{ep}</code> → <code>{xp}</code> ({exp}с)")
    out += ["", "<i>Плюс: BUY — цена закрытия выше цены входа, SELL — ниже. "
                "Цены берутся с Pocket Option в секунду входа и в секунду закрытия.</i>"]
    return "\n".join(out)
