"""Shadow evaluation — research data that is NEVER published.

1. PriceTape: while a real entry is running, the price is sampled every
   second from (entry-6s) to (exit+6s). From that tape we evaluate what the
   same trade would have given if entered at :25 … :35 (same expiry). These
   rows go to timing_stats with source='shadow' and let TimingAnalyzer pick
   the best entry second from hundreds of samples instead of a handful.

2. Shadow windows per timeframe: every SHADOW_INTERVAL_SECONDS the same
   HA/EMA/RSI analysis (unchanged) runs on S30 / M1 / M5 candles for
   SHADOW_PAIRS assets. A passing setup starts a virtual window of up to
   max(WINDOW_LENGTHS) entries, played on real quotes. The per-entry results
   ("LLW") are stored, so the AdaptiveEngine can compare timeframes and window
   lengths on equal terms.

Only cheap streaming providers (Pocket Option, mock) are used — Twelve Data
credits are never spent on research.
"""
from __future__ import annotations

import asyncio
import bisect
import random
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from app.analytics.timing import timing
from app.candles.heikin_ashi import compute_heikin_ashi
from app.config import settings
from app.core.logging_config import get_logger
from app.core.time_utils import next_entry_time, utc_now
from app.results.resolver import resolve

log = get_logger("analytics.shadow")

MAX_RUNNING_WINDOWS = 3


def _cheap(provider) -> bool:
    return getattr(provider, "name", "") in ("pocketoption", "mock")


class PriceTape:
    """Samples one symbol's price roughly every second in the background."""

    def __init__(self, provider, symbol: str):
        self.provider = provider
        self.symbol = symbol
        self.ts: List[float] = []
        self.px: List[float] = []
        self._task: Optional[asyncio.Task] = None

    def start(self, until: datetime) -> None:
        self._task = asyncio.create_task(self._run(until))

    async def _run(self, until: datetime) -> None:
        while utc_now() < until:
            try:
                q = await self.provider.get_current_quote(self.symbol)
                if q is not None:
                    t = time.time()
                    if not self.ts or t > self.ts[-1]:
                        self.ts.append(t)
                        self.px.append(float(q.price))
            except Exception:  # noqa: BLE001
                pass
            await asyncio.sleep(1.0)

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass

    def price_at(self, when: datetime, tolerance: float = 2.5) -> Optional[float]:
        """Last sampled price at or before ``when`` (None if the tape has a gap)."""
        t = when.timestamp()
        i = bisect.bisect_right(self.ts, t) - 1
        if i < 0 or t - self.ts[i] > tolerance:
            return None
        return self.px[i]


async def evaluate_entry_seconds(tape: PriceTape, direction: str, asset: str, timeframe: str,
                                 base_entry: datetime, expiry: int) -> int:
    """Virtual entries at SHADOW_SECONDS_FROM..TO of the same minute -> timing_stats."""
    rows = []
    minute = base_entry.replace(second=0, microsecond=0)
    for sec in range(settings.shadow_seconds_from, settings.shadow_seconds_to + 1):
        entry_t = minute + timedelta(seconds=sec)
        p0 = tape.price_at(entry_t)
        p1 = tape.price_at(entry_t + timedelta(seconds=expiry))
        if p0 is None or p1 is None:
            continue
        res = resolve(direction, p0, p1).value
        rows.append((entry_t, sec, asset, timeframe, res, "shadow"))
    await timing.record_many(rows)
    return len(rows)


def max_duration() -> int:
    return max([int(d) for d in settings.trade_durations] or [60])


async def evaluate_durations(tape: PriceTape, direction: str, asset: str, timeframe: str,
                             entry: datetime, source: str = "shadow") -> int:
    """Same entry, every candidate trade length (5 s … 3 min) -> duration_stats."""
    p0 = tape.price_at(entry)
    if p0 is None:
        return 0
    rows = []
    for d in settings.trade_durations:
        p1 = tape.price_at(entry + timedelta(seconds=int(d)))
        if p1 is not None:
            rows.append((entry, timeframe, asset, int(d), resolve(direction, p0, p1).value, source))
    await timing.record_durations(rows)
    return len(rows)


# ------------------------------------------------------------ shadow windows --
class ShadowRunner:
    def __init__(self, state):
        self.state = state
        self.running = 0
        self._last_tf: Dict[str, float] = {}
        self.started: Dict[str, int] = {}

    async def _candles(self, sym: str, tf: str):
        if tf == settings.default_timeframe.upper():
            c = self.state.candles.candles(sym)
            if c:
                return c
        return await self.state.provider.get_candles(sym, tf, settings.candle_history_limit)

    async def scan_timeframe(self, tf: str) -> None:
        provider = self.state.provider
        symbols = list(await provider.get_symbols())
        random.shuffle(symbols)
        best = None
        for sym in symbols[: max(1, settings.shadow_pairs)]:
            try:
                candles = await self._candles(sym, tf)
            except Exception as e:  # noqa: BLE001
                log.debug("shadow candles %s %s: %s", sym, tf, e)
                continue
            if not candles or len(candles) < 30:
                continue
            res = self.state.analysis.analyze_symbol(sym, candles, compute_heikin_ashi(candles))
            if res.passed and res.direction and (best is None or res.score > best.score):
                best = res
        if best is None:
            return
        self._last_tf[tf] = time.monotonic()
        self.running += 1
        self.started[tf] = self.started.get(tf, 0) + 1
        asyncio.create_task(self._play(tf, best))

    async def _play(self, tf: str, a) -> None:
        from app.services.runtime import expiry_for
        try:
            expiry = expiry_for(tf)
            step = 60 * max(1, -(-expiry // 60))
            length = max(settings.window_lengths or [5])
            entry = next_entry_time(utc_now(), settings.entry_second, 5)
            out = ""
            for _ in range(length):
                r = await self._one(a.symbol, a.direction, entry, expiry, tf, durations=not out)
                if r is None:
                    break
                out += r[0]
                if r == "WIN":
                    break
                entry = entry + timedelta(seconds=step)
            if out:
                atr = (a.indicators or {}).get("atr_pct")
                await timing.record_window(tf, a.symbol, a.direction, settings.entry_second,
                                           out, atr, "shadow")
                log.info("shadow window %s %s %s -> %s", tf, a.symbol, a.direction, out)
        except Exception as e:  # noqa: BLE001
            log.warning("shadow window failed: %s", e)
        finally:
            self.running -= 1

    async def _one(self, sym: str, direction: str, entry: datetime, expiry: int,
                   tf: str = "M1", durations: bool = False) -> Optional[str]:
        provider = self.state.provider
        d = (entry - utc_now()).total_seconds()
        if d < -2:
            return None
        await asyncio.sleep(max(0.0, d - 2))
        tape = PriceTape(provider, sym)
        horizon = max(expiry, max_duration() if durations else expiry)
        tape.start(entry + timedelta(seconds=horizon + 2))
        try:
            await asyncio.sleep(max(0.0, (entry + timedelta(seconds=horizon + 2)
                                          - utc_now()).total_seconds()))
        finally:
            await tape.stop()
        if durations:
            await evaluate_durations(tape, direction, sym, tf, entry)
        p0 = tape.price_at(entry)
        p1 = tape.price_at(entry + timedelta(seconds=expiry))
        if p0 is None or p1 is None:
            return None
        return resolve(direction, p0, p1).value

    async def cycle(self) -> None:
        from app.services.runtime import provider_timeframes
        st = self.state
        if not (settings.shadow_enabled and st.engine_on and st.provider_online
                and st.provider and _cheap(st.provider)):
            return
        for tf in provider_timeframes():
            if self.running >= MAX_RUNNING_WINDOWS:
                return
            if time.monotonic() - self._last_tf.get(tf, 0) < settings.shadow_tf_cooldown_seconds:
                continue
            try:
                await self.scan_timeframe(tf)
            except Exception as e:  # noqa: BLE001
                log.warning("shadow scan %s failed: %s", tf, e)


async def shadow_loop(state) -> None:
    runner = ShadowRunner(state)
    state.shadow = runner
    log.info("shadow evaluation loop started")
    while True:
        await asyncio.sleep(max(15, settings.shadow_interval_seconds))
        try:
            await runner.cycle()
        except Exception as e:  # noqa: BLE001
            log.warning("shadow cycle error: %s", e)


def window_stats(results: List[Tuple[str, Optional[float]]], length: int,
                 payout: float) -> dict:
    """Stats of windows truncated to ``length`` entries (fixed stake per entry).

    ev = average profit per window in stakes: WIN on entry k -> payout-(k-1),
    all lost -> -length. DRAW entries count as 0 and continue.
    """
    n = wins = 0
    attempts_to_win = []
    profit = 0.0
    atrs = []
    for res, atr in results:
        seq = res[:length]
        if not seq:
            continue
        # a window stopped early (data gap) without W and shorter than length: skip
        if "W" not in seq and len(seq) < length:
            continue
        n += 1
        if atr:
            atrs.append(atr)
        if "W" in seq:
            k = seq.index("W") + 1
            wins += 1
            attempts_to_win.append(k)
            profit += payout - seq[:k - 1].count("L")
        else:
            profit -= seq.count("L")
    return {
        "samples": n,
        "winrate": wins / n if n else 0.0,
        "avg_attempts": sum(attempts_to_win) / len(attempts_to_win) if attempts_to_win else 0.0,
        "ev": profit / n if n else 0.0,
        "atr_pct": sum(atrs) / len(atrs) if atrs else None,
    }
