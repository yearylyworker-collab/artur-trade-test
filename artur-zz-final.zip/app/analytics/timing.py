"""TimingAnalyzer — win/loss statistics by entry second, hour, asset and weekday.

Storage: SQLite ``timing_stats`` in ./runtime/analytics.db (WAL mode,
parameterised queries). A separate file keeps these high-frequency writes away
from the main aiosqlite database. Every call runs in a worker thread behind a
lock, so the asyncio loop is never blocked.

Rows have a ``source``:
  * ``live``   — a real published entry (what subscribers traded);
  * ``shadow`` — a virtual entry on another second (:25..:35) evaluated on the
                 same price stream; never published, used only for research.

Hours/weekdays are stored in the analytics timezone (first DISPLAY_ZONES entry,
Ukraine by default) so "night 00:00–08:00" means the subscribers' night.

Also stores ``shadow_windows``: complete virtual windows per timeframe used by
the AdaptiveEngine to compare S30 / M1 / M5 honestly on equal terms.
"""
from __future__ import annotations

import asyncio
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple
from zoneinfo import ZoneInfo

from app.config import settings
from app.core.logging_config import get_logger

log = get_logger("analytics.timing")

DB_PATH = Path("./runtime/analytics.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS timing_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,             -- unix seconds (UTC) of the entry
    entry_second INTEGER NOT NULL,
    hour INTEGER NOT NULL,           -- analytics timezone
    weekday INTEGER NOT NULL,        -- 0 = Monday
    asset TEXT NOT NULL,
    timeframe TEXT NOT NULL,
    is_win INTEGER NOT NULL,         -- 1 win, 0 loss (draws are not stored)
    source TEXT NOT NULL DEFAULT 'live'
);
CREATE INDEX IF NOT EXISTS ix_timing_ts ON timing_stats(ts);
CREATE INDEX IF NOT EXISTS ix_timing_src ON timing_stats(source, ts);

CREATE TABLE IF NOT EXISTS shadow_windows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    timeframe TEXT NOT NULL,
    asset TEXT NOT NULL,
    direction TEXT NOT NULL,
    entry_second INTEGER NOT NULL,
    results TEXT NOT NULL,           -- e.g. "LLW" : entry results in order (W/L/D)
    atr_pct REAL,
    source TEXT NOT NULL DEFAULT 'shadow'
);
CREATE INDEX IF NOT EXISTS ix_shadow_tf ON shadow_windows(timeframe, ts);

CREATE TABLE IF NOT EXISTS duration_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    timeframe TEXT NOT NULL,
    asset TEXT NOT NULL,
    duration INTEGER NOT NULL,       -- trade length in seconds
    is_win INTEGER NOT NULL,
    source TEXT NOT NULL DEFAULT 'shadow'
);
CREATE INDEX IF NOT EXISTS ix_dur_tf ON duration_stats(timeframe, duration, id);
"""

WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]


def analytics_tz() -> ZoneInfo:
    for item in settings.display_zones:
        if ":" in item:
            try:
                return ZoneInfo(item.rsplit(":", 1)[1].strip())
            except Exception:  # noqa: BLE001
                continue
    try:
        return ZoneInfo(settings.timezone)
    except Exception:  # noqa: BLE001
        return ZoneInfo("UTC")


def _wr(w: int, n: int) -> float:
    return w / n if n else 0.0


class TimingAnalyzer:
    """Aggregated timing statistics. Dict attributes mirror the ТЗ and are
    filled by :meth:`load` for quick access; the source of truth is SQLite."""

    def __init__(self, path: Path = DB_PATH):
        self.path = Path(path)
        self._lock = threading.Lock()
        self._conn: Optional[sqlite3.Connection] = None
        self.entry_stats: Dict[int, Dict[str, int]] = {}
        self.hour_stats: Dict[int, Dict[str, int]] = {}
        self.asset_stats: Dict[str, Dict[str, int]] = {}
        self.weekday_stats: Dict[int, Dict[str, int]] = {}

    # ------------------------------------------------------------ plumbing --
    def _db(self) -> sqlite3.Connection:
        if self._conn is None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=10)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.executescript(_SCHEMA)
            self._conn = conn
        return self._conn

    def _exec(self, sql: str, params: Sequence = (), many: bool = False) -> List[tuple]:
        with self._lock:
            db = self._db()
            if many:
                db.executemany(sql, params)
                db.commit()
                return []
            cur = db.execute(sql, params)
            rows = cur.fetchall()
            if not sql.lstrip().upper().startswith("SELECT"):
                db.commit()
            return rows

    async def _run(self, fn, *args):
        return await asyncio.to_thread(fn, *args)

    # ------------------------------------------------------------- writes ---
    def _row(self, when: datetime, entry_second: int, asset: str, timeframe: str,
             is_win: bool, source: str) -> tuple:
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        local = when.astimezone(analytics_tz())
        return (int(when.timestamp()), int(entry_second), local.hour, local.weekday(),
                asset, timeframe, 1 if is_win else 0, source)

    def record_entry(self, entry_second: int, hour: int, asset: str, weekday: int,
                     is_win: bool, timeframe: str = "M1", source: str = "live",
                     ts: Optional[int] = None) -> None:
        """ТЗ signature: store one finished entry (sync, thread-safe)."""
        self._exec(
            "INSERT INTO timing_stats(ts, entry_second, hour, weekday, asset, timeframe,"
            " is_win, source) VALUES (?,?,?,?,?,?,?,?)",
            (ts or int(datetime.now(timezone.utc).timestamp()), int(entry_second), int(hour),
             int(weekday), asset, timeframe, 1 if is_win else 0, source))

    async def record(self, when: datetime, entry_second: int, asset: str, timeframe: str,
                     result: str, source: str = "live") -> None:
        """Async helper used by the signal manager. DRAW is ignored."""
        if result not in ("WIN", "LOSS"):
            return
        row = self._row(when, entry_second, asset, timeframe, result == "WIN", source)
        try:
            await self._run(self._exec,
                            "INSERT INTO timing_stats(ts, entry_second, hour, weekday, asset,"
                            " timeframe, is_win, source) VALUES (?,?,?,?,?,?,?,?)", row)
        except Exception as e:  # noqa: BLE001
            log.warning("timing record failed: %s", e)

    async def record_many(self, rows: List[tuple]) -> None:
        """rows: (when, entry_second, asset, timeframe, result, source)."""
        data = [self._row(w, s, a, tf, r == "WIN", src)
                for (w, s, a, tf, r, src) in rows if r in ("WIN", "LOSS")]
        if not data:
            return
        try:
            await self._run(self._exec,
                            "INSERT INTO timing_stats(ts, entry_second, hour, weekday, asset,"
                            " timeframe, is_win, source) VALUES (?,?,?,?,?,?,?,?)", data, True)
        except Exception as e:  # noqa: BLE001
            log.warning("timing record_many failed: %s", e)

    async def record_window(self, timeframe: str, asset: str, direction: str,
                            entry_second: int, results: str, atr_pct: Optional[float],
                            source: str = "shadow") -> None:
        try:
            await self._run(self._exec,
                            "INSERT INTO shadow_windows(ts, timeframe, asset, direction,"
                            " entry_second, results, atr_pct, source) VALUES (?,?,?,?,?,?,?,?)",
                            (int(datetime.now(timezone.utc).timestamp()), timeframe, asset,
                             direction, int(entry_second), results, atr_pct, source))
        except Exception as e:  # noqa: BLE001
            log.warning("window record failed: %s", e)

    async def record_durations(self, rows: List[tuple]) -> None:
        """rows: (when, timeframe, asset, duration, result, source)."""
        data = [(int(w.timestamp()), tf, a, int(d), 1 if r == "WIN" else 0, src)
                for (w, tf, a, d, r, src) in rows if r in ("WIN", "LOSS")]
        if not data:
            return
        try:
            await self._run(self._exec,
                            "INSERT INTO duration_stats(ts, timeframe, asset, duration, is_win,"
                            " source) VALUES (?,?,?,?,?,?)", data, True)
        except Exception as e:  # noqa: BLE001
            log.warning("duration record failed: %s", e)

    def duration_stats(self, timeframe: str) -> List[Tuple[int, float, int]]:
        """[(duration, winrate, samples)] over the last DURATION_LOOKBACK rows each."""
        out = []
        for d in settings.trade_durations:
            rows = self._exec(
                "SELECT is_win FROM duration_stats WHERE timeframe = ? AND duration = ? "
                "ORDER BY id DESC LIMIT ?", (timeframe, int(d), settings.duration_lookback))
            n = len(rows)
            out.append((int(d), _wr(sum(r[0] for r in rows), n), n))
        return out

    # -------------------------------------------------------------- reads ---
    def _group(self, col: str, since: Optional[int], until: Optional[int],
               source: Optional[str], hours: Optional[Tuple[int, int]] = None) -> List[tuple]:
        assert col in ("entry_second", "hour", "asset", "weekday")
        where, params = ["1=1"], []
        if since is not None:
            where.append("ts >= ?"); params.append(since)
        if until is not None:
            where.append("ts < ?"); params.append(until)
        if source:
            where.append("source = ?"); params.append(source)
        sql = (f"SELECT {col}, SUM(is_win), COUNT(*) FROM timing_stats "
               f"WHERE {' AND '.join(where)} GROUP BY {col}")
        return [(k, int(w), int(n)) for k, w, n in self._exec(sql, params)]

    def stats(self, col: str, since: Optional[int] = None, until: Optional[int] = None,
              source: Optional[str] = "live") -> List[Tuple[object, float, int]]:
        """[(key, winrate, samples)] sorted by winrate desc."""
        rows = [(k, _wr(w, n), n) for k, w, n in self._group(col, since, until, source)]
        return sorted(rows, key=lambda r: (r[1], r[2]), reverse=True)

    def get_best_entry_second(self, min_samples: Optional[int] = None,
                              since: Optional[int] = None, source: Optional[str] = None
                              ) -> Optional[Tuple[int, float, int]]:
        """Best entry second over live+shadow data -> (second, winrate, samples)."""
        m = settings.timing_min_samples_second if min_samples is None else min_samples
        rows = [r for r in self.stats("entry_second", since, None, source) if r[2] >= m]
        return (int(rows[0][0]), rows[0][1], rows[0][2]) if rows else None

    def get_weak_hours(self, threshold: Optional[float] = None, min_samples: Optional[int] = None,
                       since: Optional[int] = None, until: Optional[int] = None
                       ) -> List[Tuple[int, float, int]]:
        t = settings.timing_weak_threshold if threshold is None else threshold
        m = settings.timing_min_samples_hour if min_samples is None else min_samples
        rows = [r for r in self.stats("hour", since, until) if r[2] >= m and r[1] < t]
        return sorted(rows, key=lambda r: r[1])

    def get_best_hours(self, min_samples: Optional[int] = None, since: Optional[int] = None,
                       until: Optional[int] = None, top: int = 3) -> List[Tuple[int, float, int]]:
        m = settings.timing_min_samples_hour if min_samples is None else min_samples
        return [r for r in self.stats("hour", since, until) if r[2] >= m][:top]

    def get_best_assets(self, min_samples: Optional[int] = None, since: Optional[int] = None,
                        until: Optional[int] = None, top: int = 3) -> List[Tuple[str, float, int]]:
        m = settings.timing_min_samples_asset if min_samples is None else min_samples
        return [r for r in self.stats("asset", since, until) if r[2] >= m][:top]

    def get_worst_assets(self, min_samples: Optional[int] = None, since: Optional[int] = None,
                         until: Optional[int] = None, top: int = 3) -> List[Tuple[str, float, int]]:
        m = settings.timing_min_samples_asset if min_samples is None else min_samples
        rows = [r for r in self.stats("asset", since, until) if r[2] >= m]
        return sorted(rows, key=lambda r: (r[1], -r[2]))[:top]

    def get_full_report(self, since: Optional[int] = None, until: Optional[int] = None) -> dict:
        return {
            "best_second": self.get_best_entry_second(since=since),
            "seconds": self.stats("entry_second", since, until, None),
            "best_hours": self.get_best_hours(since=since, until=until),
            "weak_hours": self.get_weak_hours(since=since, until=until),
            "best_assets": self.get_best_assets(since=since, until=until),
            "worst_assets": self.get_worst_assets(since=since, until=until),
            "weekdays": self.stats("weekday", since, until),
        }

    def load(self) -> None:
        """Fill the in-memory dicts (live data) — convenience for debugging."""
        for col, target in (("entry_second", self.entry_stats), ("hour", self.hour_stats),
                            ("asset", self.asset_stats), ("weekday", self.weekday_stats)):
            target.clear()
            for k, w, n in self._group(col, None, None, "live"):
                target[k] = {"wins": w, "losses": n - w}

    def windows(self, timeframe: str, limit: int, source: str = "shadow"
                ) -> List[Tuple[str, Optional[float]]]:
        """Last N windows of a timeframe: [(results, atr_pct)] (shadow = equal terms)."""
        return [(r, a) for r, a in self._exec(
            "SELECT results, atr_pct FROM shadow_windows WHERE timeframe = ? AND source = ? "
            "ORDER BY id DESC LIMIT ?", (timeframe, source, int(limit)))]

    def counts(self) -> dict:
        live = self._exec("SELECT COUNT(*) FROM timing_stats WHERE source='live'")[0][0]
        shadow = self._exec("SELECT COUNT(*) FROM timing_stats WHERE source='shadow'")[0][0]
        win = self._exec("SELECT timeframe, COUNT(*) FROM shadow_windows GROUP BY timeframe")
        return {"live": live, "shadow": shadow, "windows": dict(win)}

    async def areport(self, since=None, until=None) -> dict:
        return await self._run(self.get_full_report, since, until)


timing = TimingAnalyzer()
