"""Application settings loaded from environment (pydantic-settings)."""
from __future__ import annotations

from typing import List, Optional
from typing_extensions import Annotated

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict, NoDecode


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # --- Telegram ---
    bot_token: str = ""
    admin_ids: Annotated[List[int], NoDecode] = []
    signal_channel_id: Optional[int] = None

    # --- Database ---
    database_url: str = "sqlite+aiosqlite:///./runtime/artur_trade.db"

    # --- General ---
    timezone: str = "Europe/Prague"
    bot_mode: str = "demo"  # demo | live
    engine_auto_start: bool = False

    # --- Market provider ---
    market_provider: str = "mock"  # mock | forex | pocket
    forex_api_key: str = ""
    forex_rest_url: str = "https://api.twelvedata.com"
    forex_ws_url: str = "wss://ws.twelvedata.com/v1/quotes/price"
    forex_symbols: Annotated[List[str], NoDecode] = [
        "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "EUR/GBP",
    ]
    # Twelve Data free plan: 800 credits/day (reset 00:00 UTC). Guard stays below it.
    forex_daily_credit_limit: int = 780

    # --- Pocket Option OTC (MARKET_PROVIDER=pocket) ---
    # SSID из cookies Pocket Option. Хранить ТОЛЬКО в переменных окружения.
    pocket_ssid: str = ""
    otc_assets: Annotated[List[str], NoDecode] = [
        "EURUSD_otc", "GBPUSD_otc", "USDJPY_otc", "AUDUSD_otc", "USDCAD_otc",
        "NZDUSD_otc", "USDCHF_otc", "EURJPY_otc", "GBPJPY_otc", "EURGBP_otc",
    ]
    # OTC_ASSETS=auto -> все активные OTC-активы из Pocket Option (обновляется каждые 10 мин)
    otc_asset_types: Annotated[List[str], NoDecode] = ["currency"]  # currency,commodity,cryptocurrency,stock,index
    otc_min_payout: int = 0               # не брать активы с выплатой ниже (0 = любые)
    otc_assets_refresh_minutes: int = 2   # список пар + выплаты обновляются каждые N минут
    pocket_max_parallel: int = 4          # одновременных запросов к Pocket Option
    pocket_candle_refresh_seconds: int = 15
    pocket_quote_ttl_seconds: float = 1.0  # кэш котировки
    pocket_connect_timeout: float = 60.0

    # --- Candles / analysis ---
    default_timeframe: str = "M1"
    candle_history_limit: int = 120   # хватает для EMA25/MACD/ATR50, быстрее грузится
    analysis_interval_seconds: int = 5
    min_signal_score: int = 80

    # --- Indicators (Движок 2: HA + EMA + RSI + MACD) ---
    ema_rsi_required: bool = True   # EMA/RSI/MACD — обязательный фильтр направления
    ema_fast: int = 3
    ema_medium: int = 8
    ema_slow: int = 25
    rsi_period: int = 14
    rsi_call: float = 55.0
    rsi_put: float = 45.0
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9
    atr_period: int = 14
    atr_multiplier: float = 2.0     # тело HA > ATR*mult → VOLATILE
    atr_min_pct: float = 0.0001     # ATR/цена ниже → флэт, сигнала нет (0.01%)
    bb_period: int = 20
    bb_std: float = 2.0

    # --- Market regime ---
    regime_enabled: bool = True
    regime_trend_ema: int = 20
    regime_trend_slope_atr: float = 0.3   # |EMA20[-1]-EMA20[-4]| / ATR
    regime_bb_squeeze_atr: float = 2.5    # ширина BB < ATR*k → сужение
    regime_volatile_atr_ratio: float = 1.3  # ATR > среднего за 50 на 30%
    regime_volatile_lookback: int = 50

    # --- Arbitrage (Движок 1) ---
    arb_mode: str = "log"   # off | log (только запись) | signal (публиковать)
    arb_pairs: Annotated[List[str], NoDecode] = ["EURUSD:EURUSD_otc"]
    gap_threshold: float = 0.00130
    arb_max_gap: float = 0.01     # больше — OTC не следует за реалом, игнор
    arb_cooldown: int = 60
    arb_check_seconds: int = 60   # через сколько сек проверять исход гэпа

    # --- ML filter ---
    ml_enabled: bool = True
    ml_prob_threshold: float = 0.65
    ml_min_samples: int = 200
    ml_model_path: str = "./runtime/ml/model.json"  # + features.json рядом

    # --- Rolling winrate ---
    rolling_enabled: bool = True
    rolling_basis: str = "attempts"   # attempts | windows
    rolling_asset_n: int = 10
    rolling_block_50_minutes: int = 30
    rolling_block_40_minutes: int = 120
    rolling_global_n: int = 20
    rolling_global_warn: float = 55.0

    # --- Trading window ---
    window_mode: bool = True
    max_attempts: int = 5           # входов в торговом окне (плюс — стоп)
    window_skip_service_posts: bool = True   # только СТАРТ и ИТОГ окна
    window_analysis_card: bool = True        # карточка «АНАЛИЗ СИГНАЛА» перед сигналом (остаётся)

    # --- Adaptive engine (S30 / M1 / M5, секунда входа, длина окна) ---
    adaptive_enabled: bool = True
    adaptive_switch_cooldown: int = 3600          # не чаще раза в час
    adaptive_min_samples: int = 30                # сигналов на режиме для решения
    adaptive_improvement_threshold: float = 0.05  # новый режим лучше на 5%+
    adaptive_warning_lead: int = 120              # предупреждение за 2 минуты
    adaptive_check_seconds: int = 60
    adaptive_lookback: int = 50                   # последних теневых окон на режим
    timeframes_to_analyze: Annotated[List[str], NoDecode] = ["S30", "M1", "M5"]
    window_lengths: Annotated[List[int], NoDecode] = [3, 4, 5]
    trade_seconds: int = 0                        # фикс. время сделки; 0 = авто/как таймфрейм
    trade_seconds_auto: bool = True               # время сделки выбирает статистика
    trade_durations: Annotated[List[int], NoDecode] = [5, 15, 30, 60, 120, 180]
    duration_min_samples: int = 40               # замеров на длительность для выбора
    duration_lookback: int = 400                 # последних замеров на длительность
    duration_switch_margin: float = 0.03         # новая длительность лучше на 3 п.п.
    entry_second_auto: bool = False               # True — секунду входа выбирает статистика

    # --- Shadow evaluation (виртуальные сигналы/входы, не публикуются) ---
    shadow_enabled: bool = True
    shadow_seconds_from: int = 25                 # проверяем входы :25..:35
    shadow_seconds_to: int = 35
    shadow_pairs: int = 10                        # пар на каждый альтернативный ТФ
    shadow_interval_seconds: int = 60
    shadow_tf_cooldown_seconds: int = 180         # один теневой сигнал на ТФ раз в 3 мин

    # --- Timing analytics ---
    timing_min_samples_second: int = 50
    timing_min_samples_hour: int = 20
    timing_min_samples_asset: int = 30
    timing_weak_threshold: float = 0.50

    # --- Instruction for subscribers (/howto) ---
    howto_stake_mode: str = "overlap"     # overlap (перекрытие) | fixed (одна ставка на все входы)
    howto_stake_percent: float = 1.0      # первая (или фиксированная) ставка, % депозита
    howto_daily_stop_windows: int = 3     # после N минусовых окон за день — стоп
    display_zones: Annotated[List[str], NoDecode] = ["🇺🇦 Украина:Europe/Kyiv"]

    # --- Reliability ---
    fallback_enabled: bool = True         # Pocket недоступен -> Forex (нужен FOREX_API_KEY)
    fallback_after_seconds: int = 300
    fallback_retry_minutes: int = 10
    startup_report: bool = True
    main_channel_id: Optional[int] = None  # основной канал: сюда уходит 1 сигнал раз в N часов
    main_channel_every_hours: float = 0.0   # 0 = считать из MAIN_SIGNALS_PER_DAY и часов
    main_signals_per_day: int = 10
    main_hours_start: int = 9               # по Украине: публикуем с 09:00
    main_start_once: str = ""              # разовый старт на дату: "2026-09-24 10:30" (Украина)
    main_hours_end: int = 23                # … до 23:00 (ночью основной канал отдыхает)
    main_promo_every: int = 3
    main_greeting_gap_minutes: int = 10     # после «Доброе утро» первый сигнал через ~10 мин               # видео приватки после каждого 3-го сигнала
    main_prepare_min_minutes: int = 5       # «сигнал в течение 5–35 минут»
    main_prepare_max_minutes: int = 35
    main_contact: str = "@ArturTreider"
    main_register_url: str = ""             # пока пусто — ссылок нет
    main_promo_text: str = ""               # напр. "Промокод: 50START — 200$"
    main_first_stake_usd: float = 5.0       # пример первой ставки в сигнале
    main_promo_video_text: str = ""         # подпись к видео-рекламе приватки (пусто = не слать)
    main_promo_delay_seconds: int = 60
    private_channel_url: str = ""          # ссылка-приглашение в приватку
    broadcast_enabled: bool = True         # рассылка в личку о приватке
    broadcast_every_hours: float = 8.0
    broadcast_deposit_usd: float = 50.0
    daily_stats: bool = True              # итог дня раз в сутки (после полуночи по Украине)
    daily_stats_target: str = "admin"     # admin | channel | both

    # --- Money display (для статистики «% к депозиту»; 0 = не показывать) ---
    stake_percent: float = 0.0
    payout_percent: float = 80.0

    # --- Entry / expiry ---
    entry_second: int = 30
    min_seconds_before_entry: int = 8
    default_expiry_seconds: int = 60
    allow_short_expiry: bool = False
    short_expiry_seconds: int = 5
    fallback_expiry_seconds: int = 60

    # --- Concurrency / cooldown ---
    max_concurrent_signals: int = 1
    pair_cooldown_minutes: int = 5
    global_signal_cooldown_seconds: int = 120

    # --- Repeat ---
    repeat_mode: bool = False
    max_repeats: int = 2

    # --- Freshness ---
    stale_quote_seconds: int = 5
    stale_candle_seconds: int = 150

    # --- Session (local TIMEZONE, "HH:MM"; empty = 24/7). Weekends are skipped for forex. ---
    trading_session_start: str = ""
    trading_session_end: str = ""

    # --- Presentation timing (sequential posts; engine never blocked) ---
    search_temp_seconds: int = 6
    analysis_temp_seconds: int = 6
    min_signal_lead_seconds: int = 40
    post_result_cooldown_seconds: int = 15
    max_concurrent_signals: int = 1
    # legacy (unused in sequential model, kept for compatibility)
    search_min_visible_seconds: int = 30
    analysis_min_visible_seconds: int = 20
    confirmation_min_visible_seconds: int = 15
    countdown_visible_seconds: int = 15
    skipped_min_visible_seconds: int = 12
    result_final: bool = True
    telegram_min_edit_interval_seconds: int = 8

    # --- Telegram heartbeat ---
    telegram_heartbeat_minutes: int = 30

    # --- Demo ---
    demo_random_seed: int = 42

    # --- Logging ---
    log_level: str = "INFO"

    @field_validator("admin_ids", mode="before")
    @classmethod
    def _parse_admin_ids(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        return v

    @field_validator("window_lengths", "trade_durations", mode="before")
    @classmethod
    def _parse_ints(cls, v):
        if isinstance(v, str):
            return [int(x) for x in v.split(",") if x.strip()]
        return v

    @field_validator("forex_symbols", "otc_assets", "arb_pairs", "otc_asset_types",
                     "timeframes_to_analyze", "display_zones", mode="before")
    @classmethod
    def _parse_symbols(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(",") if x.strip()]
        return v

    @property
    def is_pocket(self) -> bool:
        return self.market_provider.lower() == "pocket"

    @property
    def otc_auto(self) -> bool:
        return [a.lower() for a in self.otc_assets] == ["auto"]

    @property
    def active_symbols(self) -> List[str]:
        """Symbols of the configured provider (OTC for pocket, forex otherwise)."""
        return self.otc_assets if self.is_pocket else self.forex_symbols

    @property
    def arb_pair_map(self) -> List[tuple]:
        """[("EURUSD", "EURUSD_otc"), ...] parsed from ARB_PAIRS."""
        out = []
        for item in self.arb_pairs:
            if ":" in item:
                real, otc = item.split(":", 1)
                out.append((real.strip(), otc.strip()))
        return out

    def validate_runtime(self) -> None:
        """Fail fast on missing critical config."""
        if self.is_live and self.is_pocket and not self.pocket_ssid.strip():
            raise RuntimeError("POCKET_SSID is empty — set it in environment variables")
        if self.is_live and self.market_provider.lower() == "forex" and not self.forex_api_key.strip():
            raise RuntimeError("FOREX_API_KEY is empty — get a free key at twelvedata.com")

    @property
    def is_live(self) -> bool:
        return self.bot_mode.lower() == "live"

    @property
    def sync_database_url(self) -> str:
        """Sync URL used by Alembic."""
        return (
            self.database_url
            .replace("+aiosqlite", "")
            .replace("+asyncpg", "")
        )


settings = Settings()
