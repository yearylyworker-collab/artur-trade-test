"""Result checker: capture entry & exit quotes from the SAME provider."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from app.config import settings
from app.core.exceptions import DataUnavailableError
from app.core.logging_config import get_logger
from app.core.models import Quote
from app.market.base import MarketDataProvider

log = get_logger("results.checker")


@dataclass
class PriceCapture:
    price: float
    provider_timestamp: datetime


async def capture_price(provider: MarketDataProvider, symbol: str) -> PriceCapture:
    """Grab the current quote; ensure it is not stale."""
    quote: Optional[Quote] = await provider.get_current_quote(symbol)
    if quote is None:
        raise DataUnavailableError(f"no quote for {symbol}")
    age = provider.get_quote_age(symbol)
    if age is not None and age > settings.stale_quote_seconds * 6:
        raise DataUnavailableError(f"stale quote for {symbol} age={age:.1f}s")
    return PriceCapture(price=quote.price, provider_timestamp=quote.provider_timestamp)


async def wait_until(target: datetime) -> None:
    from app.core.time_utils import utc_now
    delay = (target - utc_now()).total_seconds()
    if delay > 0:
        await asyncio.sleep(delay)
