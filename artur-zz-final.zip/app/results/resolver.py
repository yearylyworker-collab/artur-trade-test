"""Resolve WIN / LOSS / DRAW from entry & exit prices."""
from __future__ import annotations

from app.core.enums import AttemptResult, Direction


def resolve(direction: str, entry_price: float, exit_price: float) -> AttemptResult:
    if entry_price == exit_price:
        return AttemptResult.DRAW
    if direction == Direction.BUY.value:
        return AttemptResult.WIN if exit_price > entry_price else AttemptResult.LOSS
    # SELL
    return AttemptResult.WIN if exit_price < entry_price else AttemptResult.LOSS
