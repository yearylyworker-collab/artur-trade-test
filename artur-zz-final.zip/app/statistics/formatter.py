"""Statistics caption — values straight from the database.

Always shows BOTH views:
  * windows  — "+1 / −1" per trading window (what the channel advertises);
  * entries  — every 60s entry separately (the real betting result).
A 5-entry window wins ~97% of the time even on random entries, so the
window winrate alone would be misleading.
"""
from __future__ import annotations

from app.config import settings


def _pct(a: int, b: int) -> str:
    return f"{100.0 * a / b:.1f}" if b else "0.0"


def stats_caption(stats: dict) -> str:
    w, l = stats.get("wins", 0), stats.get("losses", 0)
    aw, al = stats.get("attempt_wins", 0), stats.get("attempt_losses", 0)
    ad = stats.get("attempt_draws", 0)
    breakeven = 100.0 / (1.0 + settings.payout_percent / 100.0)
    money = ""
    if settings.stake_percent > 0 and (aw + al):
        res = settings.stake_percent * (aw * settings.payout_percent / 100.0 - al)
        money = f"\n💰 <b>Результат по входам:</b> <code>{res:+.2f}%</code> к депозиту"
    windows = "" if settings.max_attempts <= 1 else (
        "<blockquote>"
        f"🪟 <b>Окон:</b> <code>{w + l}</code>\n"
        f"🟢 <b>Плюс:</b> <code>{w}</code> ({_pct(w, w + l)}%)\n"
        f"🔴 <b>Минус:</b> <code>{l}</code> ({_pct(l, w + l)}%)"
        "</blockquote>\n")
    return (
        "<b>📊 СТАТИСТИКА. ИТОГИ СЕССИИ</b>\n\n"
        "Друзья, делимся результатами!\n\n"
        f"{windows}"
        "<blockquote>"
        f"✅ <b>Сделок:</b> <code>{aw + al + ad}</code>\n"
        f"✅ <b>Прибыльных:</b> <code>{aw}</code> ({_pct(aw, aw + al)}%)\n"
        f"❌ <b>Убыточных:</b> <code>{al}</code> ({_pct(al, aw + al)}%)"
        f"{money}"
        "</blockquote>\n\n"
        f"<i>Безубыточность по входам при выплате {settings.payout_percent:.0f}%: "
        f"{breakeven:.1f}%. Соблюдаем мани-менеджмент!</i>"
    )
