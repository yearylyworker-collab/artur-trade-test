"""Rolling winrate guard — protection against a market phase change.

Per asset, over the last ROLLING_ASSET_N closed results:
  winrate < 50%  -> asset blocked for ROLLING_BLOCK_50_MINUTES (30)
  winrate < 40%  -> asset blocked for ROLLING_BLOCK_40_MINUTES (120)
Globally, over the last ROLLING_GLOBAL_N results:
  winrate < ROLLING_GLOBAL_WARN (55%) -> warning to admins (max once per hour)

ROLLING_BASIS:
  "attempts" (default) — every 60s entry counts. This is the honest metric:
      a 5-attempt window wins ~97% of the time even on coin-flips, so a
      window-based guard would practically never trigger.
  "windows" — one result per trading window (as in the original spec).

Blocks are persisted in the ``system_state`` table, so they survive restarts.
DRAW results are ignored in the winrate.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import List, Optional

from sqlalchemy import and_, desc, select

from app.config import settings
from app.core.logging_config import get_logger
from app.database.models import Signal, SignalAttempt
from app.database.repositories.repos import SystemStateRepository
from app.database.session import get_session

log = get_logger("statistics.rolling")


def _winrate(results: List[str]) -> Optional[float]:
    decided = [r for r in results if r in ("WIN", "LOSS")]
    if not decided:
        return None
    return 100.0 * sum(1 for r in decided if r == "WIN") / len(decided)


async def _last_results(mode: str, n: int, asset: Optional[str] = None) -> List[str]:
    """Newest-first WIN/LOSS results (attempts or windows, per settings)."""
    async with get_session() as s:
        if settings.rolling_basis == "windows":
            cond = [Signal.mode == mode, Signal.final_result.in_(("WIN", "LOSS"))]
            if asset:
                cond.append(Signal.symbol == asset)
            q = select(Signal.final_result).where(and_(*cond)).order_by(desc(Signal.id)).limit(n)
        else:
            cond = [Signal.mode == mode, SignalAttempt.result.in_(("WIN", "LOSS"))]
            if asset:
                cond.append(Signal.symbol == asset)
            q = (select(SignalAttempt.result)
                 .join(Signal, Signal.id == SignalAttempt.signal_id)
                 .where(and_(*cond)).order_by(desc(SignalAttempt.id)).limit(n))
        rows = await s.execute(q)
        return [r for (r,) in rows.all()]


async def recent_winrate(mode: str, n: int, asset: Optional[str] = None) -> Optional[float]:
    """Winrate of the last n CLOSED results (used as an ML feature — no look-ahead)."""
    return _winrate(await _last_results(mode, n, asset))


def _block_key(mode: str, asset: str) -> str:
    return f"block:{mode}:{asset}"


async def blocked_reason(mode: str, asset: str) -> Optional[str]:
    """None if the asset may be traded, else a human-readable reason."""
    if not settings.rolling_enabled:
        return None
    async with get_session() as s:
        raw = await SystemStateRepository(s).get(_block_key(mode, asset))
    if not raw:
        return None
    try:
        until = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if datetime.now(timezone.utc) < until:
        return f"rolling block until {until.astimezone().strftime('%H:%M')}"
    return None


async def on_result(mode: str, asset: str, notify=None) -> None:
    """Call after a window is closed. ``notify`` is an async fn(text) for admins."""
    if not settings.rolling_enabled:
        return
    n = settings.rolling_asset_n
    res = await _last_results(mode, n, asset)
    wr = _winrate(res)
    if wr is not None and len([r for r in res if r in ("WIN", "LOSS")]) >= n:
        minutes = 0
        if wr < 40.0:
            minutes = settings.rolling_block_40_minutes
        elif wr < 50.0:
            minutes = settings.rolling_block_50_minutes
        if minutes:
            until = datetime.now(timezone.utc) + timedelta(minutes=minutes)
            async with get_session() as s:
                await SystemStateRepository(s).set(_block_key(mode, asset), until.isoformat())
                await s.commit()
            log.warning("ROLLING BLOCK %s wr=%.0f%% for %d min", asset, wr, minutes)
            if notify:
                await notify(f"⛔️ {asset}: winrate {wr:.0f}% за {n} → блок на {minutes} мин")

    g_n = settings.rolling_global_n
    g_res = await _last_results(mode, g_n)
    g_wr = _winrate(g_res)
    if g_wr is not None and len(g_res) >= g_n and g_wr < settings.rolling_global_warn and notify:
        key = f"warn:{mode}:global"
        now = datetime.now(timezone.utc)
        async with get_session() as s:
            repo = SystemStateRepository(s)
            last = await repo.get(key)
            if last and now - datetime.fromisoformat(last) < timedelta(hours=1):
                return
            await repo.set(key, now.isoformat())
            await s.commit()
        await notify(f"⚠️ Общий winrate за {g_n}: {g_wr:.0f}% (< {settings.rolling_global_warn:.0f}%)."
                     " Ниже безубыточности при пейауте 80% (55.6%).")
