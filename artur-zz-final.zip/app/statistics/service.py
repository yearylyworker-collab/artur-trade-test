"""Statistics service (DB-only): windows + per-entry numbers."""
from __future__ import annotations

from app.database.repositories.repos import StatsRepository
from app.database.session import get_session


async def get_stats(mode: str) -> dict:
    async with get_session() as s:
        repo = StatsRepository(s)
        stats = await repo.summary(mode)
        stats.update(await repo.attempt_summary(mode))
        return stats
