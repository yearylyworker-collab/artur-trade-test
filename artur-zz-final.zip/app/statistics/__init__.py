"""Statistics sub-package."""
