"""Core analysis cycle + orchestration."""
from __future__ import annotations

import asyncio
import random
from datetime import datetime, timezone
from typing import List

from app.config import settings
from app.core.logging_config import get_logger
from app.core.models import AnalysisResult
from app.core.time_utils import in_trading_session, utc_now
from app.ml.features import build_features
from app.ml.filter import ml_filter
from app.statistics import rolling
from app.market.mock.provider import MockMarketDataProvider
from app.services.state import state
from app.signals.manager import SignalManager

log = get_logger("scheduler.engine")

_last_candle_refresh = 0.0
_demo_symbol_cycle = 0


async def refresh_candles() -> None:
    """Fetch latest candles for all symbols in parallel (provider limits concurrency)."""
    provider = state.provider
    if not provider:
        return
    symbols = await provider.get_symbols()
    t0 = asyncio.get_event_loop().time()

    async def one(sym: str) -> bool:
        try:
            candles = await provider.get_candles(
                sym, settings.default_timeframe, settings.candle_history_limit)
            if candles:
                state.candles.set_history(sym, candles)
                return True
        except Exception as e:  # noqa: BLE001
            log.warning("candle refresh failed %s: %s", sym, e)
        return False

    log.info("refreshing candles for %d pairs (%s)...", len(symbols), settings.default_timeframe)
    results = await asyncio.gather(*(one(s) for s in symbols))
    took = asyncio.get_event_loop().time() - t0
    state.diag["refresh"] = {"pairs": len(symbols), "ok": sum(results), "seconds": round(took, 1),
                             "at": utc_now().isoformat()}
    log.info("candles refreshed: %d/%d pairs in %.1fs", sum(results), len(symbols), took)


def stale_limit_seconds() -> float:
    """Closed-candle age limit scales with the timeframe (M5 candles are older)."""
    from app.services.runtime import tf_seconds
    return max(settings.stale_candle_seconds, tf_seconds(settings.default_timeframe) * 2 + 30)


def reset_candles() -> None:
    """Timeframe changed: drop cached candles and force a refresh next cycle."""
    global _last_candle_refresh
    state.candles = type(state.candles)(limit=settings.candle_history_limit)
    _last_candle_refresh = 0.0


def _refresh_interval() -> float:
    # Mock is free; live is rate-limited -> refresh less often.
    if isinstance(state.provider, MockMarketDataProvider):
        return 3.0
    if getattr(state.provider, "name", "") == "pocketoption":
        return float(settings.pocket_candle_refresh_seconds)
    return 60.0


def _launch(candidate: AnalysisResult) -> None:
    log.info("candidate[%s]: %s %s score=%s ml=%s regime=%s", candidate.engine,
             candidate.symbol, candidate.direction, candidate.score,
             candidate.ml_prob, candidate.regime)
    state.active_signal_id = -1  # claim the single publication slot immediately
    manager = SignalManager(state)
    asyncio.create_task(manager.run(candidate))


async def _notify_admins(text: str) -> None:
    if not state.bot:
        return
    for admin_id in settings.admin_ids:
        try:
            await state.bot.send_message(admin_id, text)
        except Exception as e:  # noqa: BLE001
            log.warning("admin notify failed %s: %s", admin_id, e)


async def _pick_ha_candidate(analyses: List[AnalysisResult]) -> AnalysisResult | None:
    """Rules passed -> rolling guard -> ML filter. Best score first."""
    mode = state.mode.value
    valid = sorted((a for a in analyses if a.passed and a.direction),
                   key=lambda a: a.score, reverse=True)
    for a in valid:
        getter = getattr(state.provider, "current_payout", None)
        if getter:
            payout = await getter(a.symbol)
            if payout is not None:
                a.indicators["payout"] = payout
                if payout < settings.otc_min_payout or payout == 0:
                    log.info("skip %s: payout %s%% < %s%%", a.symbol, payout,
                             settings.otc_min_payout)
                    continue
        reason = await rolling.blocked_reason(mode, a.symbol)
        if reason:
            log.info("skip %s: %s", a.symbol, reason)
            continue
        rwr = await rolling.recent_winrate(mode, settings.rolling_asset_n, a.symbol)
        a.ml_features = build_features(a, rwr, utc_now())
        a.ml_prob = ml_filter.predict(a.ml_features)
        if a.ml_prob is None:
            log.info("ML %s %s: no model -> TAKE by rules (score=%.0f)",
                     a.symbol, a.direction, a.score)
        elif not ml_filter.allows(a.ml_prob):
            log.info("ML %s %s: prob=%.3f < %.2f -> SKIP", a.symbol, a.direction,
                     a.ml_prob, settings.ml_prob_threshold)
            continue
        else:
            log.info("ML %s %s: prob=%.3f >= %.2f -> TAKE", a.symbol, a.direction,
                     a.ml_prob, settings.ml_prob_threshold)
        return a
    return None


async def analysis_cycle() -> None:
    global _last_candle_refresh, _demo_symbol_cycle
    if not state.engine_on or not state.provider_online:
        return

    # 1. Arbitrage gaps are observed even while a window is running (evidence).
    try:
        arb = await state.arbitrage.check(state.provider)
    except Exception as e:  # noqa: BLE001
        log.warning("arbitrage check failed: %s", e)
        arb = None
    if state.is_busy:
        return
    if arb is not None and state.cooldown.ready(arb.symbol):
        _launch(arb)
        return

    is_forex = getattr(state.provider, "name", "") == "twelvedata"
    if not in_trading_session(skip_weekends=is_forex):
        return  # outside hours: no analysis and no API credits spent

    now = asyncio.get_event_loop().time()
    if now - _last_candle_refresh >= _refresh_interval() or _last_candle_refresh == 0:
        await refresh_candles()
        _last_candle_refresh = now

    provider = state.provider
    symbols = await provider.get_symbols()

    # DEMO: bias a rotating symbol so the mock market trends cleanly.
    if state.auto_demo and isinstance(provider, MockMarketDataProvider):
        sym = symbols[_demo_symbol_cycle % len(symbols)]
        _demo_symbol_cycle += 1
        provider.bias(sym, random.choice(["BUY", "SELL"]))
        candles = await provider.get_candles(sym, settings.default_timeframe,
                                             settings.candle_history_limit)
        state.candles.set_history(sym, candles)

    analyses: List[AnalysisResult] = []
    cooldown = no_data = stale = 0
    for sym in symbols:
        if not state.cooldown.ready(sym):
            cooldown += 1
            continue
        candles = state.candles.candles(sym)
        ha = state.candles.ha(sym)
        if not candles:
            no_data += 1
            continue
        # stale candle guard
        age = (datetime.now(timezone.utc) - candles[-1].timestamp).total_seconds()
        if age > stale_limit_seconds() and not isinstance(
                provider, MockMarketDataProvider):
            stale += 1
            continue
        res = state.analysis.analyze_symbol(sym, candles, ha)
        analyses.append(res)
        log.debug("pair score %s=%s dir=%s", sym, res.score, res.direction)

    # --- diagnostics for /diag: why there is (no) signal ---
    fail_counts: dict = {}
    for a in analyses:
        if a.passed:
            continue
        failed = [f.name for f in a.filters if not f.passed] or [a.reason.split(";")[0][:30]]
        for name in failed:
            fail_counts[name] = fail_counts.get(name, 0) + 1
    top = sorted(analyses, key=lambda a: a.score, reverse=True)[:5]
    state.diag["cycle"] = {
        "at": utc_now().isoformat(), "symbols": len(symbols), "analyzed": len(analyses),
        "cooldown": cooldown, "no_data": no_data, "stale": stale,
        "passed": sum(1 for a in analyses if a.passed), "fails": fail_counts,
        "top": [(a.symbol, round(a.score), a.direction or "-",
                 ",".join(f.name for f in a.filters if not f.passed) or "ok") for a in top],
    }

    best = await _pick_ha_candidate(analyses)
    if best is None:
        log.info("NO SIGNAL this cycle (%d analysed, %d passed rules, stale %d, no data %d)",
                 len(analyses), state.diag["cycle"]["passed"], stale, no_data)
        return
    _launch(best)


async def market_analysis_loop() -> None:
    log.info("analysis loop started")
    while True:
        try:
            await analysis_cycle()
        except Exception as e:  # noqa: BLE001
            log.exception("analysis cycle error: %s", e)
        await asyncio.sleep(settings.analysis_interval_seconds)
