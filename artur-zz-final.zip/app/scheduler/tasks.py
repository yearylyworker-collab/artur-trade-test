"""Background workers: health, reconnect, cleanup, heartbeat."""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from app.config import settings
from app.core.logging_config import get_logger
from app.database.repositories.repos import ProviderHealthRepository
from app.database.session import get_session
from app.services.state import state

log = get_logger("scheduler.tasks")


async def health_monitor_loop() -> None:
    log.info("health monitor started")
    while True:
        await asyncio.sleep(45)
        try:
            provider = state.provider
            if provider:
                online = await provider.health_check()
                if online != state.provider_online:
                    log.warning("provider online -> %s", online)
                state.provider_online = online
                async with get_session() as s:
                    await ProviderHealthRepository(s).record(provider.name, online)
                    await s.commit()
        except Exception as e:  # noqa: BLE001
            log.warning("health check error: %s", e)


async def provider_reconnect_loop() -> None:
    backoffs = [1, 2, 5, 10, 30]
    idx = 0
    while True:
        await asyncio.sleep(5)
        if state.provider and not state.provider_online:
            delay = backoffs[min(idx, len(backoffs) - 1)]
            log.warning("provider offline; reconnect attempt in %ss", delay)
            await asyncio.sleep(delay)
            try:
                await state.provider.connect()
                state.provider_online = True
                idx = 0
                log.info("provider reconnected")
            except Exception as e:  # noqa: BLE001
                idx += 1
                log.warning("reconnect failed: %s", e)
        else:
            idx = 0


async def heartbeat_loop() -> None:
    interval = max(5, settings.telegram_heartbeat_minutes) * 60
    while True:
        await asyncio.sleep(interval)
        log.info("heartbeat: engine=%s mode=%s provider_online=%s busy=%s",
                 state.engine_on, state.mode.value, state.provider_online, state.is_busy)


async def cleanup_loop() -> None:
    """Remove stale generated card PNGs."""
    from pathlib import Path
    gen = Path(__file__).resolve().parents[2] / "runtime" / "generated"
    while True:
        await asyncio.sleep(3600)
        try:
            now = datetime.now(timezone.utc).timestamp()
            for p in gen.glob("*.png"):
                if now - p.stat().st_mtime > 6 * 3600:
                    p.unlink(missing_ok=True)
        except Exception as e:  # noqa: BLE001
            log.warning("cleanup error: %s", e)
