# Test Credentials — ARTUR TRADE

## Telegram (provided by user)
- BOT: @arturprivate_bot
- BOT_TOKEN: in /app/.env (BOT_TOKEN)
- ADMIN_IDS: 8608297320
- SIGNAL_CHANNEL_ID: -1004389140667 (bot is administrator, can post — verified)

## Market provider (LIVE)
- Twelve Data FOREX_API_KEY: in /app/.env
- STATUS: returns 401 Unauthorized (key rejected by Twelve Data). LIVE needs a valid key.
- DEMO mode uses MockMarketDataProvider (no key needed) and works fully.

## App
- No user login/auth (Telegram-only). Admin access = ADMIN_IDS.
- DB: SQLite at ./runtime/artur_trade.db (dev). Auto-created on startup.

## How to demo
- Telegram: /start → /panel → press ▶️ AUTO DEMO → watch the private channel.
- Fast one-shot lifecycle: `python -m scripts.demo_once` (posts a full series quickly).
