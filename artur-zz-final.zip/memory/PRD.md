# ARTUR TRADE — PRD

## Problem statement
Build from zero a 24/7 Telegram Heikin Ashi signal engine (ARTUR TRADE): live/mock
Forex data → M1 candles → Heikin Ashi → filters → scored BUY/SELL candidate →
publish dynamic card to a private channel → wait exact entry → capture real entry
price → wait expiry → capture exit → WIN/LOSS/DRAW → edit card → statistics →
repeat. The bot never trades; it only analyzes/signals/tracks/reports.

## Tech stack
Python 3.12 (runs on 3.11 here), aiogram 3.x, asyncio, httpx, websockets,
pydantic-settings, SQLAlchemy 2 async, Alembic, SQLite (dev) / PostgreSQL (prod),
Pillow, pytest/pytest-asyncio, Docker, Railway. Timezone Europe/Prague.

## Architecture
Modular: market (mock + Twelve Data REST/WS), candles + Heikin Ashi, analysis
engine + 8 filters + scoring, signals (generator/cooldown/lifecycle manager),
results (checker/resolver), publisher (telegram/queue/formatter), cards
(renderer/manifest/autofit from user master templates), statistics, database
(models/session/repositories), scheduler loops, services (state/health/recovery/
engine_control), bot handlers + admin panel. Entry in app/main.py.

## What's implemented (2026-06)
- Full DEMO mode end-to-end verified against the real channel: search → confirmation
  → BUY/SELL → wait entry → entry/exit capture → WIN/LOSS/DRAW result card → stats.
- Heikin Ashi computed locally; 8 filters; internal score 0-100; min score 75.
- 4 master templates wired (signal_buy, signal_skipped, analysis, result_win) +
  derived signal_sell / result_loss / result_draw via red/neutral action overlays.
  Dynamic text auto-fits inside every field (verified by rendering + screenshots).
- SQLAlchemy async models + repositories; Alembic initial migration generated.
- Idempotent publication queue (duplicate protection); restart recovery marks
  orphaned signals DATA_UNAVAILABLE (never fabricates results).
- Async scheduler: analysis loop, health monitor, provider reconnect (1/2/5/10/30s
  backoff), heartbeat, cleanup.
- Telegram: /start /panel /status /stats /templates /preview_cards + full admin
  inline panel. Channel permission check on startup (verified: admin, can_post).
- 25 pytest tests passing. Replay/backtest script.
- Docker + railway.toml + .env.example + README.

## Known limitations
- LIVE Twelve Data key provided by user returns 401 Unauthorized (not a valid
  Twelve Data key format). LIVE code path is complete and swappable; needs a valid
  key. DEMO unaffected.
- Short (3-5s) expiry auto-falls back to 60s unless a fast WS quote stream is active.
- OTC only in DEMO (no trustworthy broker OTC feed).

## Changelog

### 2026-06 — Card calibration + timing fix
- Replaced 5 masters with new clean empty-box versions (all 1672×941): search_signal,
  wait_confirmation, stats (9 fields), signal_sell (NEW file), result_win.
- Rebuilt CardRenderer: draw_text_autofit (fit by width+height), 12/6px safe-area padding,
  centered mm anchor, NO image resize (native res), no black plate for empty boxes.
- Precisely calibrated `config/templates.yaml` via programmatic box detection
  (`scripts/detectboxes.py`) + verified renders. All values now sit inside their panels.
- Formatter field names updated: search={market,timeframe,asset,status};
  wait={pair,market,timeframe,comment}; result adds `result`; stats adds mode/draws/repeats.
- Presentation timing (anti-flicker): added ENV SEARCH/ANALYSIS/CONFIRMATION_MIN_VISIBLE,
  COUNTDOWN_VISIBLE, SKIPPED_MIN_VISIBLE, MIN_SIGNAL_LEAD, TELEGRAM_MIN_EDIT_INTERVAL.
  Lifecycle now: SEARCH(≥30s) → WAIT CONFIRMATION(≥15s) → BUY/SELL(stable, ≥20s lead
  before entry) → RESULT (final, stays forever). Entry auto-scheduled with full lead.
  Removed per-second countdown card / intermediate flicker.
- /preview_cards command renders all cards with sample data to admin.
- TEMP: signal_buy uses SELL master, result_loss/result_draw use WIN master (same coords)
  until real BUY/LOSS/DRAW masters are provided — swap-in = drop PNG, no recalibration.
- Utilities added: scripts/gridoverlay.py, scripts/cropgrid.py, scripts/detectboxes.py.

## Changelog

### 2026-06 — STATIC-CARD ARCHITECTURE PIVOT (major)
Superseded the dynamic CardRenderer approach. Cards are now ready-made static
PNGs; ALL dynamic data lives in the Telegram caption.
- 10 static cards installed in `assets/cards/01..10_*.png` (1672×941).
- `StaticCardRegistry` (`app/cards/static_registry.py`) + `telegram_card_assets`
  table: each PNG uploaded once, `file_id` cached in DB and reused (survives restart).
  Admin: `/cards_status`, `/register_cards`, `/replace_card <TYPE>`, `/preview_cards`.
- CardRenderer/Pillow/templates.yaml removed from the LIVE publish path.
- Sequential posts (`app/signals/manager.py`): SEARCH(temp) → ANALYSIS(temp) →
  delete temps → BUY/SELL (permanent) → [REENTRY (permanent)] → RESULT (permanent)
  → cooldown. No editMessageMedia; nothing edited into another card.
- `SignalPublicationSnapshot` (immutable) is the single source of truth for
  direction; card + caption both read it; assert before send, else
  CRITICAL_DIRECTION_MISMATCH and no send (fixes SELL-card/BUY-text bug).
- New vivid captions (`publisher/formatter.py`) — blockquotes + bold + emoji,
  unique accent per state.
- Result checker: entry/exit from SAME provider quotes around exact timestamps
  (NOT M1 close); DEMO polls mock quotes; missing quote → DATA_UNAVAILABLE.
- Timing: MIN_SIGNAL_LEAD_SECONDS=40, ENTRY_SECOND=30, EXPIRY=60,
  POST_RESULT_COOLDOWN_SECONDS=15; entry auto-scheduled with full lead; engine
  never blocked by presentation; MAX_CONCURRENT_SIGNALS=1 (single publication slot).
- Statistics audit: DB-derived & global (no LIMIT/date filters), series vs
  attempts separated; `/stats_debug` (totals, by-status, series+attempts,
  oldest/newest per LIVE/DEMO) and `/signal_debug [id]` (raw entry/exit quotes).
  Startup uses create_all only — never wipes history.
- Verified offline end-to-end: SELL→WIN series posts SEARCH,ANALYSIS,(delete),
  SELL,WIN in order; DB records correct; /stats_debug reconciliation returns
  global counts (124 signals, 65W/51L).

## Backlog / next
- P1: DRAW currently shown on WIN card frame (no dedicated DRAW asset) — provide
  a DRAW card if desired (DRAW is rare on 60s forex).
- P1: live channel run — /register_cards then start engine / AUTO DEMO to watch flow.
- P1: valid LIVE Forex provider key + LIVE acceptance run.
- P1: session windows (TRADING_SESSION_START/END) enforcement in engine loop.
- P1: richer signal audit viewer command.
- P2: per-symbol candle incremental updates via WS to reduce REST calls under rate limits.
