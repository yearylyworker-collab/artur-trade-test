# ARTUR TRADE — Heikin Ashi Signal Engine

24/7 Telegram система, которая анализирует Forex-рынок по Heikin Ashi, находит
качественные BUY/SELL сетапы, публикует динамические карточки в приватный канал,
ждёт точное время входа, фиксирует реальный результат (WIN/LOSS/DRAW) и ведёт
статистику. **Бот НЕ торгует** — только ANALYZE → SIGNAL → PUBLISH → TRACK →
RESULT → STATISTICS.

## Возможности
- **DEMO** (mock provider) и **LIVE FOREX** (Twelve Data REST + WebSocket) — статистика раздельная.
- Локальный расчёт Heikin Ashi + 8 фильтров (trend, body, wicks, momentum, volatility, structure, noise, confirmation).
- Внутренний QUALITY SCORE 0–100 (НЕ вероятность выигрыша).
- Точное время входа (`ENTRY_SECOND`), экспирация 60с (короткая 3–5с только при быстром quote-стриме, иначе fallback 60с).
- Реальные entry/exit цены с одного и того же провайдера. Restart-recovery без выдумывания результатов.
- Динамические карточки из ваших мастер-шаблонов ARTUR TRADE (Pillow + автоподгонка текста).
- Идемпотентная очередь публикаций (защита от дублей после рестарта).
- Async-планировщик: анализ, health-watchdog, reconnect, heartbeat, cleanup.


## Pocket Option OTC + два движка (обновление 2026-09)

**Бот не торгует.** Он только читает котировки OTC и публикует сигналы.

### Порядок проверки перед сигналом
1. **Движок 1 — арбитраж** (`app/engines/arbitrage.py`): гэп между реальной парой и OTC > `GAP_THRESHOLD`.
   По умолчанию `ARB_MODE=log`: гэпы только **записываются** вместе с исходом через 60 с. Команда `/arb` показывает попадание.
   Включайте `ARB_MODE=signal` только если попадание стабильно выше безубыточности (55.6% при выплате 80%).
2. **Движок 2**: Heikin Ashi (существующие 8 фильтров, без изменений) + обязательный фильтр EMA 3/8/25, RSI 14, MACD 12/26/9 и ATR-флэт (`app/analysis/filters/ema_rsi_macd.py`).
3. **Режим рынка** (`app/analysis/regime.py`): в `RANGE` сигналы запрещены.
4. **Rolling winrate** (`app/statistics/rolling.py`): блок актива на 30 мин (<50%) / 2 ч (<40%), предупреждение админам, если общий < 55%.
   По умолчанию считается **по входам** (`ROLLING_BASIS=attempts`), см. ниже почему.
5. **ML-фильтр** (`app/ml/`): XGBoost meta-labeling. Пока нет обученной модели — выключен, сигналы идут по правилам.

### Торговое окно
До `MAX_ATTEMPTS=5` входов, строго на `:30` каждой минуты, экспирация 60 с. WIN на любом входе = окно +1; все входы в минус = −1.
В канал уходят только 2 поста: **СТАРТ окна** и **ИТОГ окна**. Каждый вход хранится в `signal_attempts`.

> ⚠️ Статистика окна почти всегда выглядит высокой: даже при случайных входах 50/50 шанс проиграть все 5 подряд ≈ 3%, значит «плюсов» ≈ 97%.
> Поэтому `/stats` и итог окна всегда показывают и **винрейт по отдельным входам** — это реальный результат ставок.
> Реалистичный винрейт по входам — 55–65%. ML-фильтр только отсекает слабые сигналы и ничего не гарантирует.

### ML: обучение
Когда накопится ≥ 200 закрытых сигналов:
```
python -m scripts.train_ml          # на Railway: railway ssh → эта команда
```
Модель сохраняется, только если на **более поздних** данных (не участвовавших в обучении) отобранные сигналы дали winrate выше, чем все сигналы.
Потом `/ml reload` в боте.

### Настройки
Все пороги — переменные окружения, полный список в `.env.example` (значения по умолчанию — в `app/config/settings.py`).

### Запуск на Railway
1. Сервис из этого репозитория (Dockerfile уже есть).
2. **Volume** с точкой монтирования `/app/runtime` — там база SQLite (WAL) и ML-модель, переживают перезапуски.
3. Переменные: `BOT_TOKEN`, `ADMIN_IDS`, `SIGNAL_CHANNEL_ID`, `POCKET_SSID`, `BOT_MODE=live`, `MARKET_PROVIDER=pocket`, `ENGINE_AUTO_START=true`.
4. `POCKET_SSID` — cookie `ssid` **отдельного пустого** аккаунта Pocket Option (F12 → Application → Cookies → ssid). Только в переменных Railway, никогда в коде/GitHub.

### VPS Ubuntu
```
sudo apt update && sudo apt install -y python3.12 python3.12-venv git
git clone <repo> artur && cd artur
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env && nano .env      # заполнить токены
python -m app.main                      # или systemd-сервис / docker compose
```

### Termux (Android)
Не поддерживается: у `BinaryOptionsToolsV2` нет сборок под Android (есть linux-glibc/musl, macOS, Windows). Используйте Railway или VPS.

### Библиотека BinaryOptionsToolsV2
Неофициальная. Pocket Option её не поддерживает, может сломать обновлением или заблокировать аккаунт. Используется только чтение котировок; `buy()/sell()` в проекте не вызываются.

## Архитектура
```
app/
  main.py                энтрипоинт (aiogram polling + фоновые задачи)
  config/settings.py     pydantic-settings из ENV
  core/                  enums, models, exceptions, time, logging
  market/                base + mock + forex(rest/ws/provider) + manager
  candles/               models, store, manager, heikin_ashi
  analysis/              engine, scoring, filters/*
  signals/               generator, cooldown, manager (lifecycle)
  results/               checker, resolver
  publisher/             telegram, queue, formatter
  cards/                 renderer, manifest, autofit, registry
  statistics/            service, formatter
  database/              models (SQLAlchemy 2 async), session, repositories
  scheduler/             engine_loop, tasks
  services/              state, health, recovery, engine_control
assets/templates/        мастер-карточки ARTUR TRADE (PNG)
assets/fonts/            DejaVuSans (кириллица)
config/templates.yaml    манифест текстовых полей (x/y/w/h/font/autofit)
migrations/              Alembic
tests/                   pytest
scripts/replay.py        backtest/replay движка
```

## Запуск (локально)
```bash
pip install -r requirements.txt
cp .env.example .env           # заполнить BOT_TOKEN, ADMIN_IDS, SIGNAL_CHANNEL_ID и т.д.
python -m app.main
```
SQLite создаётся автоматически. Для продакшена — PostgreSQL (`DATABASE_URL=postgresql+asyncpg://...`).

## Telegram
Команды: `/start`, `/panel` (admin), `/status`, `/stats`, `/templates`, `/preview_cards`.
Панель админа: ENGINE ON/OFF, LIVE/DEMO, AUTO DEMO / STOP DEMO, ANALYZE NOW,
STATISTICS, TEMPLATES, PREVIEW CARDS, PROVIDER STATUS, LAST SIGNALS, SETTINGS.

Бот должен быть **администратором** приватного канала (`SIGNAL_CHANNEL_ID=-100...`).

## Тесты
```bash
pytest -q
```

## Backtest / Replay
```bash
python -m scripts.replay EUR/USD          # mock
python -m scripts.replay --live EUR/USD   # live history (нужен валидный FOREX_API_KEY)
```

## Deployment (Railway)
- `Dockerfile` (python:3.12-slim + fonts-dejavu-core), `railway.toml`.
- Переменные окружения задаются в Railway (секреты **не** коммитятся).
- Для LIVE: `BOT_MODE=live`, `MARKET_PROVIDER=forex`, валидный `FOREX_API_KEY`, `ENGINE_AUTO_START=true`.

## Критические правила
Никаких фейковых сигналов, MOCK ≠ LIVE, LOSS не скрывается, score ≠ вероятность,
никаких обещаний точности, M1-close не используется для фиктивного 5-сек результата,
обычный Forex-фид не используется для OTC-результата, секреты не коммитятся, никакой авто-торговли.
